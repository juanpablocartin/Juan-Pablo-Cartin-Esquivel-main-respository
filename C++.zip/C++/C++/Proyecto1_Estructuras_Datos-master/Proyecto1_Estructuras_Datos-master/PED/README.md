# Juego de Sokoban: Manejo de Memoria y Listas Enlazadas

**Integrantes:**

- Anner Andrés Angulo Gutiérrez
- Juan Pablo Cartín Esquivel
- Marcos Emilio Vásquez Díaz

## Descripción

Este proyecto tiene como objetivo desarrollar un juego de Sokoban en C++, centrado en el manejo de memoria y listas enlazadas para el almacenamiento y manipulación de niveles y movimientos del jugador.

## Funcionalidades

1. **Interfaz de usuario**: Implementación de una interfaz gráfica de usuario para que los jugadores puedan interactuar con el juego de manera intuitiva.

2. **Manejo de niveles**: Carga y almacenamiento de niveles del juego utilizando listas enlazadas para representar la estructura de cada nivel y las posiciones de los objetos.

3. **Movimientos del jugador**: Registro y gestión de los movimientos del jugador utilizando memoria dinámica para almacenar la secuencia de movimientos realizados.

4. **Validación de movimientos**: Implementación de reglas de validación para verificar la legalidad de los movimientos del jugador, considerando obstáculos y restricciones de movimiento.

5. **Reinicio y deshacer movimientos**: Funcionalidad para reiniciar el nivel actual y para deshacer movimientos previos del jugador, utilizando listas enlazadas para manejar el historial de movimientos.

6. **Gestión de puntajes**: Registro y almacenamiento de puntajes de los jugadores en cada nivel, utilizando memoria dinámica para mantener una lista de puntajes ordenada.

7. **Guardado y carga de partidas**: Implementación de funcionalidades para guardar y cargar partidas en curso, utilizando listas enlazadas para almacenar el estado actual del juego.

8. **Gráficos y animaciones**: Incorporación de gráficos y animaciones para mejorar la experiencia visual del jugador durante el juego.

## Instalación y Uso


1. Importa el proyecto en tu IDE de preferencia(recomendacion para garantizar compativilidad visual studio 2022).
2. Ejecuta la aplicación C++, espesificamnete el archivo main, que se encuentra en Source Files.
3. Disfruta del juego de Sokoban