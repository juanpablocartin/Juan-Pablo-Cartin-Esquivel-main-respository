#pragma once
#include "Interfaz.h"
class Controladora
{
private:
	Tabla* tabla;

public:
	Controladora();
	~Controladora();
	void Iniciar();
	void Menu();
	void Control1();
	void control2();
	void control3();
	void control4();
	void control5();
	void control6();
	void control7();
};

