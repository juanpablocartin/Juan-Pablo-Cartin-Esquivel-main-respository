
package Controladora_Servidor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class HiloCliente implements Runnable {
    //Socket
    private Socket clientPERSONAL;
    private Servidor server;
    //
    private DataInputStream Din;
    private DataOutputStream Dout;
    private ObjectOutputStream Oout;
    private ObjectInputStream Oin;
    //Socket

    
    public HiloCliente(Socket c, Servidor s) throws IOException{
        this.clientPERSONAL = c;
        this.server = s;
        this.Din = new DataInputStream(clientPERSONAL.getInputStream());
        this.Dout = new DataOutputStream(clientPERSONAL.getOutputStream());
    }
    @Override
    public void run() {
        try {
        //-------------------------------------------------------------------------------
            this.Oout = new ObjectOutputStream(clientPERSONAL.getOutputStream());
            Oout.writeObject(server.lis);
            System.out.println("Server manda lista");
            while(true){
                System.out.println("Esperando por mensaje de Clienete");
                String code=Din.readUTF();
                this.Oin = new ObjectInputStream(clientPERSONAL.getInputStream());
                Object o=Oin.readObject();
                System.out.println("Tengo un Mensaje");
                //if(code!="" && o!=null){
                    if(code.equals("11")){
                        server.borraID(code,o);
                    }
                    else if (code.equals("22")){
                        server.seDEVOLVIO(code,o);
                    }
                //}
                
            }
            
         } catch (IOException ex) {
            Logger.getLogger(HiloCliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(HiloCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
//When you implements Runnable, you can save space for your class to extend any other class in the future or now.

//        Object obj = Oin.readObject();
//        Oout.writeObject(obj);
//        this.Dout.writeUTF("example");
//        String exa=this.Din.readUTF();
