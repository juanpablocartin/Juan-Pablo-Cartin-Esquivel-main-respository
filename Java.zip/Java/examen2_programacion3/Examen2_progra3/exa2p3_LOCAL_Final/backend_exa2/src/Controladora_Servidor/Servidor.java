package Controladora_Servidor;

import entidades.Producto;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import modelo.ListaObjeto;

public class Servidor implements Runnable {
    
    public ListaObjeto lis;
    
    private int PUERTO;
    private ArrayList<Socket> clientes;
    private ArrayList<HiloCliente> all_hilos;
    private ServerSocket serverSocket;
    private Socket cliente_de_S;
    // ---------------------------- Cone SQL ---------------------------
    //------------------------------------------------------------------
    public Servidor(int puerto) {
        this.lis=new ListaObjeto();
        lis.add(new Producto(001,"",111,"Reloj","Rolex"));
        lis.add(new Producto(002,"",222,"Reloj","Timemex"));
        lis.add(new Producto(003,"",333,"Reloj","Casio"));
        lis.add(new Producto(004,"",444,"Reloj","AP"));
        lis.add(new Producto(005,"",555,"Automovil","Nissan"));
        lis.add(new Producto(006,"",666,"Automovil","Toyota"));
        lis.add(new Producto(007,"",777,"Automovil","Jeep"));
        this.PUERTO = puerto;
        this.clientes = new ArrayList();
        this.all_hilos = new ArrayList();
    }
        
    public void borraID(String code, Object o) throws IOException{
        int id=(int) o;
        lis.eliminarElemento_X_id(id);
        for (Socket realC : this.clientes) {
            DataOutputStream Dout = new DataOutputStream(realC.getOutputStream());
            Dout.writeUTF(code);
            
            ObjectOutputStream objOutput = new ObjectOutputStream(realC.getOutputStream());
            objOutput.writeObject(id);
        }
    }
    public void seDEVOLVIO(String code, Object o) throws IOException{
        lis.add((Producto) o);
        for (Socket realC : this.clientes) {

            DataOutputStream mejOutput = new DataOutputStream(realC.getOutputStream());
            mejOutput.writeUTF(code);
            
            ObjectOutputStream objOutput = new ObjectOutputStream(realC.getOutputStream());
            objOutput.writeObject(o);
        }
    }
    @Override
    public void run() {
        serverSocket = null;
        cliente_de_S = null;
        try {
            serverSocket = new ServerSocket(this.PUERTO);
            System.out.println("servidor en P= " + this.PUERTO);
            while (true) {
                cliente_de_S = serverSocket.accept();


                clientes.add(cliente_de_S);

                HiloCliente HC = new HiloCliente(cliente_de_S, this);
                all_hilos.add(HC);
                Thread commsThread = new Thread(HC);
                commsThread.start();
            }
        } catch (IOException ex) {
        }
    }


}
