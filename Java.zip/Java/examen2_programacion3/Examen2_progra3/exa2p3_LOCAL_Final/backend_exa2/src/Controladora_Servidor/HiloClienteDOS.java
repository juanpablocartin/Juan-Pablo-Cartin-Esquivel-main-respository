package Controladora_Servidor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class HiloClienteDOS extends Thread{
    //Socket
    private Socket clientPERSONAL;
    private Servidor server;
    //
    private DataInputStream Din;
    private DataOutputStream Dout;
    private ObjectOutputStream Oout;
    private ObjectInputStream Oin;
    //Socket


    
    public HiloClienteDOS(Socket c, Servidor s) throws IOException{
        this.clientPERSONAL = c;
        this.server = s;
        this.Din = new DataInputStream(clientPERSONAL.getInputStream());
        this.Dout = new DataOutputStream(clientPERSONAL.getOutputStream());
        this.Oin = new ObjectInputStream(clientPERSONAL.getInputStream());
        this.Oout = new ObjectOutputStream(clientPERSONAL.getOutputStream());
    }
    @Override
    public void run() {
    }
}
//However, the significant difference is.
//
//When you extends Thread class, each of your thread creates a unique object and associate with it.
//When you implements Runnable, it shares the same object to multiple threads.

//        Object obj = Oin.readObject();
//        Oout.writeObject(obj);
//        this.Dout.writeUTF("example");
//        String exa=this.Din.readUTF();
