
package entidades;

import java.io.IOException;
import java.io.Serializable;

/**
 *
 * @author jpcar
 */
public class Producto  implements Serializable{
    private int id;
    private String nombre;
    private int precio;
    private String tipo;
    private String espisificacion_de_tipo;

    public Producto(int id, String nombre, int precio, String tipo, String espisificacion_de_tipo) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.tipo = tipo;
        this.espisificacion_de_tipo = espisificacion_de_tipo;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String Nombre) {
        this.nombre = Nombre;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getEspisificacion_de_tipo() {
        return espisificacion_de_tipo;
    }

    public void setEspisificacion_de_tipo(String espisificacion_de_tipo) {
        this.espisificacion_de_tipo = espisificacion_de_tipo;
    }
        private void writeObject(java.io.ObjectOutputStream out) throws IOException {
        out.writeInt(this.id);
        out.writeUTF(this.nombre);
        out.writeInt(this.precio);
        out.writeUTF(this.tipo);
        out.writeUTF(this.espisificacion_de_tipo);

    }

    private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException {
        this.id=in.readInt();
        this.nombre=in.readUTF();
        this.precio=in.readInt();
        this.tipo=in.readUTF();
        this.espisificacion_de_tipo=in.readUTF();
    }

    @Override
    public String toString() {
        return "Producto{" + "id=" + id + ", nombre=" + nombre + ", precio=" + precio + ", tipo=" + tipo + ", espisificacion_de_tipo=" + espisificacion_de_tipo + '}';
    }
    
    
}
