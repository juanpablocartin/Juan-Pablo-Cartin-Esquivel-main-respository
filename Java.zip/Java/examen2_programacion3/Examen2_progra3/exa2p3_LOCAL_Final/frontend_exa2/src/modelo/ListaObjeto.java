package modelo;

/**
 *
 * @author jpcar
 */
import entidades.Producto;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

public class ListaObjeto implements Serializable {

    public ArrayList<Producto> list;
    public int canDobje;
    //-------------------------------------------------------------------------------------------

    public ListaObjeto() {
        list = new ArrayList();
    }
    //-------------------------------------------------------------------------------------------

    public ListaObjeto(ArrayList x) {
        list = x;
    }

    //-------------------------------------------------------------------------------------------
    public Object[] creaFilallena(Producto e) {
        Object[] filAux = new Object[4];
        filAux[0] = e.getId();
        filAux[1] = e.getTipo()+" "+e.getEspisificacion_de_tipo();
        filAux[2] = e.getPrecio();
        return filAux;
    }

    //-------------------------------------------------------------------------------------------
    public Object[] retornaFila(int i) {
        Object[] filAux = new Object[4];
        if (i < list.size()) {
            Producto e = list.get(i);
            filAux[0] = e.getId();
            filAux[1] = e.getTipo()+" "+e.getEspisificacion_de_tipo();
            filAux[2] = e.getPrecio();
        }
        return filAux;
    }
    
    //-------------------------------------------------------------------------------------------

    //-----------------------------------------------------------------------------------------------
    public int getCantidad() {
        return list.size();
    }

    //-----------------------------------------------------------------------------------------------
    public Producto getElemento(int i) {
        return list.get(i);
    }

    //-------------------------------------------------------------------------------------------
    public void add(Producto e) {
        canDobje=canDobje+1;
        list.add(e);
    }

    //-----------------------------------------------------------------------------------------------
    public ArrayList<Producto> getArrayList() {
        return list;
    }
    //-----------------------------------------------------------------------------------------------
    public void setArrayList(ArrayList<Producto> L) {
         list=L;
    }


    //-------------------------------------------------------------------------------------------       
    public void eliminarElemento(int pos) {
        canDobje=canDobje-1;
        list.remove(pos);
    }
    //-------------------------------------------------------------------------------------------       
    public void eliminarElemento_X_id(int id) {
        canDobje=canDobje-1;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId()==(id)) {
                list.remove(i);
            }
        }
    }

    //-------------------------------------------------------------------------------------------  
    public int getINDEX(Producto e) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId() == e.getId()) {
                return i;
            }
        }
        return -1;
    }

    //-------------------------------------------------------------------------------------------  
    public int getINDEX_X_string(String lookup) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getTipo().equals(lookup)) {
                return i;
            }
        }
        return -1;
    }
    //-------------------------------------------------------------------------------------------  
    public int getINDEX_X_int(int lookup) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId()==(lookup)) {
                return i;
            }
        }
        return -1;
    }
    //-------------------------------------------------------------------------------------------  
    public Producto getObje_X_int(int lookup) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId()==(lookup)) {
                return list.get(i);
            }
        }
        return null;
    }
    //-------------------------------------------------------------------------------------------  

    private void writeObject(java.io.ObjectOutputStream out) throws IOException {
        out.writeInt(canDobje);

        for(Producto x:list){
            out.writeObject(x);
        }
    }

    private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException {
        canDobje = in.readInt();

        if(list==null){
            list=new ArrayList();
        }
        for(int i=0;i<canDobje;i=i+1){
            Producto aux= (Producto) in.readObject();
            list.add(aux);
        }
        
    }

    @Override
    public String toString() {
        for(Producto x:list){
            System.out.println(x.toString());
        }
        return "ListaObjeto{" + "list=" + list + ", canDobje=" + canDobje + '}';
        
    }
    

}
