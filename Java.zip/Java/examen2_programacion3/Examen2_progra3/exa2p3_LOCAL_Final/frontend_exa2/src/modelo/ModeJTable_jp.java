package modelo;

/**
 *
 * @author jpcar
 */
import javax.swing.table.DefaultTableModel;
import entidades.*;
import java.util.ArrayList;
import javax.swing.table.TableRowSorter;

public class ModeJTable_jp {

    private DefaultTableModel modelito;
    private ListaObjeto lis;

//---------------------------------------------------------------------------
    public DefaultTableModel getModelito() {
        return modelito;
    }
    //--------------------------------------------------------------------

    public ModeJTable_jp() {
        this.modelito = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }

        };
        this.lis = new ListaObjeto();
        this.darFormatoModelo();
    }
    //--------------------------------------------------------------------

    public ModeJTable_jp( ListaObjeto x) {
        this.modelito = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }

        };
        this.lis = x;
        this.darFormatoModelo();
    }
    //--------------------------------------------------------------------

    public void darFormatoModelo() {
        modelito.addColumn("Id");
        modelito.addColumn("Nombre ");
        modelito.addColumn("Precio");
    }
    //-----------------------------------------------------------------------------------------

    public void insertarObje(Producto c) {
        lis.add(c);
        this.insertarFilaModelo(lis.retornaFila(lis.getCantidad() - 1));
    }
    //--------------------------------------------------------------------------------------------------------
    public void insertarObje_soloLista(Producto c) {
        lis.add(c);
    }
    //-----------------------------------------------------------------------------------------
    public void insertarFilaModelo(Object[] filaAux) {
        modelito.addRow(filaAux);
    }
    //--------------------------------------------------------------------------------------------------------  

    public void borrarRegistro_X_id(int id) {
        String TipoAux=lis.getObje_X_int(id).getTipo();
        
        for (int i = 0; i < lis.getCantidad(); i++) {
            if (lis.getElemento(i).getId()==id){
                int borra=lis.getINDEX_X_int(id);
                lis.eliminarElemento(borra);
            }   
        }
        inicializarModelo_X_Tipo(TipoAux);
    }
    //--------------------------------------------------------------------------------------------------------  

    public void borrarRegistro_X_id_soloLISTA(int id) {
        
        for (int i = 0; i < lis.getCantidad(); i++) {
            if (lis.getElemento(i).getId()==id){
                int borra=lis.getINDEX_X_int(id);
                lis.eliminarElemento(borra);
            }   
        }
    }
    
    //--------------------------------------------------------------------------------------------------------
    public void inicializarModelo_X_Tipo(String t) {
        for (int i = 0; i < lis.getCantidad(); i++) {
            if (lis.getElemento(i).getTipo().equals(t)){
                Object[] filAux = lis.retornaFila(i);
                modelito.addRow(filAux);
            }   
        }

    }
    //--------------------------------------------------------------
    public void inicializarModelo() {
        for (int i = 0; i < lis.getCantidad(); i++) {
            Object[] filAux = lis.retornaFila(i);
            modelito.addRow(filAux);
        }

    }
    //--------------------------------------------------------------------------------------------------------

    public void UPDATE_JTable() {
        //En este caso no 
        modelito.setRowCount(0);
        for (int i = 0; i < lis.getCantidad(); i++) {
            Object[] filAux = lis.retornaFila(i);
            modelito.addRow(filAux);
        }

    }
   //--------------------------------------------------------------------------------------------------------
    public void UPDATE_JTable_X_Tipo(String tipo) {
        modelito.setRowCount(0);
        for (int i = 0; i < lis.getCantidad(); i++) {
            if( lis.getElemento(i).getTipo().equals(tipo)){
                Object[] filAux = lis.retornaFila(i);
                modelito.addRow(filAux);
            }
        }    
    }
    //--------------------------------------------------------------------------------------------------------
    public void Limpiar_JTable() {
        modelito.setRowCount(0);
    }
    //-----------------------------------------------------------------------
    public ListaObjeto getLista() {
        return lis;
    }
    //-----------------------------------------------------------------------
    public void setLista(ArrayList x) {
        lis.setArrayList(x);
        //this.UPDATE_JTable();
    }

    //--------------------------------------------------------------------  
    public int getIndex_X_string(String s) {
        int j = -1;
        for (int i = 0; i < lis.getCantidad(); i++) {
            if (lis.getElemento(i).getNombre().equals(s)) {
                j = i;
            }
        }
        return j;
    }

    //--------------------------------------------------------------------  
    public Producto getObje_X_string(String s) {
        for (int i = 0; i < lis.getCantidad(); i++) {
            if (lis.getElemento(i).getNombre().equals(s)) {
                return lis.getElemento(i);
            }
        }
        return null;
    }
    //--------------------------------------------------------------------  
    public Producto getObje_X_int(int s) {
        for (int i = 0; i < lis.getCantidad(); i++) {
            if (lis.getElemento(i).getId()==(s)) {
                return lis.getElemento(i);
            }
        }
        return null;
    }

    //--------------------------------------------------------------------  
    public void selectATindex(int i) {
        //Este metodo fue implemtado para selecionar la row que se busco
    }

    //--------------------------------------------------------------------  
    public String info_objeto_X_index(int i) {
        return lis.getElemento(i).toString();
    }

    //--------------------------------------------------------------------  
    public void update(int id, String nombre) {//Le mando el objetio si es que la entidad tiene un objecto
        int x = lis.getINDEX_X_int(id);
        lis.getElemento(x).setNombre(nombre);
        //lis.getElemento(x).setTipDinstrumentos(tipoDinstru);
        this.UPDATE_JTable();
    }
    //--------------------------------------------------------------------  

    public String get_String_X_int(int iinntt) {
        for (int i = 0; i < lis.getCantidad(); i++) {
            if (lis.getElemento(i).getId() == iinntt) {
                return lis.getElemento(i).getNombre();
            }
        }
        return "";
    }

    //--------------------------------------------------------------------  
    public int get_int_X_String(String s) {
        for (int i = 0; i < lis.getCantidad(); i++) {
            if (lis.getElemento(i).getNombre().equals(s)) {
                return lis.getElemento(i).getId();
            }
        }
        return -1;
    }
    //--------------------------------------------------------------------  

    public boolean Buscar_X_String(String s) {
        for (int i = 0; i < lis.getCantidad(); i++) {
            if (lis.getElemento(i).getNombre().equals(s)) {
                return true;
            }
        }
        return false;
    }

    //--------------------------------------------------------------------  
    public boolean Buscar_X_int(int iinntt) {
        for (int i = 0; i < lis.getCantidad(); i++) {
            if (lis.getElemento(i).getId() == iinntt) {
                return true;
            }
        }
        return false;
    }
    //--------------------------------------------------------------------  
    public String getTipo_X_id(int iinntt) {
        for (int i = 0; i < lis.getCantidad(); i++) {
            if (lis.getElemento(i).getId() == iinntt) {
                return lis.getElemento(i).getTipo();
            }
        }
        return "";
    }

    public void UPDATE_JTable_X_Tipo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
