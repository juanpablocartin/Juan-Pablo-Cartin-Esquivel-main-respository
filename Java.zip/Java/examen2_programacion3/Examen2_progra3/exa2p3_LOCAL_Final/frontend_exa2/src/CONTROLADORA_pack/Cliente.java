package CONTROLADORA_pack;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.ListaObjeto;
import modelo.ModeJTable_jp;

public class Cliente implements Runnable,Interfaz {
    private int p;
    private Controladora contro;
    private String hostlocal = "127.0.0.1";
    public DataInputStream Din;
    public DataOutputStream Dout;
    private ObjectOutputStream Oout;
    private ObjectInputStream Oin;
    private Object o;
    Socket me;
    
    public ListaObjeto list;
    
    public Cliente(int port, Controladora controla){
        this.p = port;
        this.contro = controla;
    }
    public void Mandar_mensaje_al_Servidor(String code, Object o) {
        try {
            System.out.println("Cliente manda mensaje");
            this.Dout.writeUTF(code);
            ObjectOutputStream objOutput = new ObjectOutputStream(this.me.getOutputStream());
            objOutput.writeObject(o);
        } catch (IOException iOException) {

        }
    }

    @Override
    public void run() {
        try {
            this.me = new Socket(hostlocal, this.p);
            
            this.Din = new DataInputStream(this.me.getInputStream());
            this.Dout = new DataOutputStream(this.me.getOutputStream());
            //--------------------------------------------------------------
            //String can_de_objectos=Din.readUTF();
            //int INTcan_de_objectos=Integer.parseInt(can_de_objectos);
            this.Oin = new ObjectInputStream(this.me.getInputStream());
            this.o=Oin.readObject();
            list=(ListaObjeto) o;
            contro.modeB.setLista(list.getArrayList());
            //--------------------------------------------------------------
            while (true){
                System.out.println("cliente on");
                System.out.println("Esperando mensaje de server");
                String code=this.Din.readUTF();
                 Oin = new ObjectInputStream(this.me.getInputStream());
                this.o=Oin.readObject();
                this.contro.UPDATE(code, o);
            }
        } catch (IOException ex) {
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public void off() {
        try {
            this.me.close();
        } catch (IOException iOException) {
        }
    }

    @Override
    public void StartProxyCliente() {
        Thread Cthre = new Thread(this);
        Cthre.start();
    }
    
}
