package CONTROLADORA_pack;

import java.io.IOException;
import java.io.ObjectOutputStream;

public class ProxyCliente implements Interfaz {
    private Cliente c;
    public ProxyCliente(int p, Controladora c) throws IOException {
        this.c=new Cliente(p,c);
    }
    public void StartProxyCliente() {
         c.StartProxyCliente();
    }
    public void Mandar_mensaje_al_Servidor(String code, Object o) {
        c.Mandar_mensaje_al_Servidor(code,o);
    }

    @Override
    public void off() {
        c.off();
    }
}
