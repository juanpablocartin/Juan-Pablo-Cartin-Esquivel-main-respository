package CONTROLADORA_pack;

public interface Interfaz {
    public void Mandar_mensaje_al_Servidor(String code, Object o);
    public void StartProxyCliente();
    public void off();
}
