
package CONTROLADORA_pack;

import Vista.cv;
import entidades.Producto;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.RowSorter.SortKey;
import javax.swing.SortOrder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import modelo.ModeJTable_jp;


public class Controladora implements ActionListener {
    private ProxyCliente proxyC;
    ModeJTable_jp modeB;
    public String PBUSCADO;
    ModeJTable_jp modeC;
    public cv v;

    public Controladora(cv parav) throws IOException {
        this.v=parav;
        this.v.setVisible(true);
        v.getTfbuscar().addActionListener(this);
        v.getBbuscar().addActionListener(this);
        v.getBcomprar().addActionListener(this);
        v.getBdevolver().addActionListener(this);
        modeB=new ModeJTable_jp();
        v.getJtb().setModel(modeB.getModelito());
        modeC=new ModeJTable_jp();
        v.getJtc().setModel(modeC.getModelito());
        //start ProxyC
        this.proxyC=new ProxyCliente(5001, this);
        this.proxyC.StartProxyCliente();
        //start ProxyC
        this.PBUSCADO="";

    }
    public void Ordenar_X_colum(){
             //TableRowSorter<DefaultTableModel> sort=new TableRowSorter<>(mode.getModelito());
             //v.getjTable1().setRowSorter(sort);
             //ArrayList<SortKey> skey =new ArrayList<>();
             //skey.add(new SortKey(0,SortOrder.ASCENDING));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //Eventos...............
        //------------------------------------------------------------------------------------------------------------------
        if(e.getSource().equals(v.bbuscar)){
            modeB.Limpiar_JTable();
                if ((v.tfbuscar.getText().equals("")) ) {
                    JOptionPane.showMessageDialog(null, "Debes llenar el espacio de Buscar", "Error", JOptionPane.ERROR_MESSAGE);
                } else if (modeB.getLista().getINDEX_X_string(v.getTfbuscar().getText()) == -1) {
                    JOptionPane.showMessageDialog(null, "Ese tipo de producto no existe", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    String t=v.tfbuscar.getText();
                    PBUSCADO=v.tfbuscar.getText();
                    modeB.inicializarModelo_X_Tipo(t);
                    
                }
                v.tfbuscar.setText("");
        }
        if(e.getSource().equals(v.bcomprar)){
            
                if (modeB.getLista().getINDEX_X_string(PBUSCADO) == -1) {
                    JOptionPane.showMessageDialog(null, "Ese tipo de producto no existe", "Error", JOptionPane.ERROR_MESSAGE);
                } else  if (v.getJtb().getSelectedRow()==-1){
                    JOptionPane.showMessageDialog(null, "Selecione un Producto por favor", "Error", JOptionPane.ERROR_MESSAGE);
                }
                else{

                    int id_COMPRA=(int) v.getJtb().getValueAt(v.getJtb().getSelectedRow(),0);
                    System.out.println(id_COMPRA);
                    Producto aux=modeB.getLista().getObje_X_int(id_COMPRA);
                    modeC.insertarObje(aux);
                    
                    modeB.Limpiar_JTable();
                    modeB.borrarRegistro_X_id(id_COMPRA);


                    /////////////////////////////////////////////////
                    proxyC.Mandar_mensaje_al_Servidor("11", id_COMPRA);
                    /////////////////////////////////////////////////
                }
        }
        if (e.getSource().equals(v.bdevolver)){
             if (v.getJtc().getSelectedRow()==-1){
                    JOptionPane.showMessageDialog(null, "Selecione un Producto por favor", "Error", JOptionPane.ERROR_MESSAGE);
             }
             else{
                    int id_DEVOLVER=(int) v.getJtc().getValueAt(v.getJtc().getSelectedRow(),0);
                    System.out.println(id_DEVOLVER);
                    Producto aux=modeC.getLista().getObje_X_int(id_DEVOLVER);
                    
                    modeC.borrarRegistro_X_id(id_DEVOLVER);
                    modeC.UPDATE_JTable();
                    /////////////////////////////////////////////////
                    proxyC.Mandar_mensaje_al_Servidor("22", aux);
                    /////////////////////////////////////////////////
                                        
                }
             
        }
        
        //------------------------------------------------------------------------------------------------------------------
        
        //------------------------------------------------------------------------------------------------------------------
        
        //------------------------------------------------------------------------------------------------------------------
        
        //------------------------------------------------------------------------------------------------------------------
        
        //------------------------------------------------------------------------------------------------------------------
        
        //------------------------------------------------------------------------------------------------------------------
        
        //------------------------------------------------------------------------------------------------------------------
        
        //------------------------------------------------------------------------------------------------------------------
    }
    public void UPDATE(String x, Object o) {
        if(x.equals("11")){
            int id=(int) o;
            if(modeB.Buscar_X_int(id)==true){
                if(PBUSCADO.equals("")){
                    modeB.borrarRegistro_X_id_soloLISTA(id);
                }
                else if(PBUSCADO.equals(modeB.getTipo_X_id(id))){
                    modeB.Limpiar_JTable();
                    modeB.Limpiar_JTable();
                    modeB.borrarRegistro_X_id(id);
                }
                else{
                    modeB.borrarRegistro_X_id_soloLISTA(id);
                }
            }
        }
        else if (x.equals("22")){
            Producto auxp=(Producto) o;
            System.out.println(auxp.toString());
            if(PBUSCADO.equals(auxp.getTipo())){
                    modeB.insertarObje_soloLista(auxp);
                    modeB.UPDATE_JTable_X_Tipo(auxp.getTipo());
                    
                }
                else{
                    modeB.insertarObje_soloLista(auxp);
                }
        }
    }
    
}
//-----------------NOTAS:---------------------------------------------
//-----------------Integer.toString(DE_INT_A_STRING);-----------------
//-----------------Integer.parseInt(DE_STRING_A_INT);-----------------
