# Práctica de Examen: Manejo de Sockets e Hilos

- **Autor:** Juan Pablo Cartín Esquivel

## Descripción

Este ejemplo tiene como propósito ejemplificar el manejo de Sockets e Hilos para la creación de una pequeña aplicación de compras de Automóviles y Relojes.

## Funcionalidades

1. **Multithreading**: Implementación de hilos para manejar múltiples conexiones de clientes de manera concurrente.

2. **Envío y recepción de mensajes**: Los clientes pueden enviar mensajes al servidor y este los distribuye a todos los clientes conectados.

3. **Manejo de clientes desconectados**: Lógica para manejar clientes que se desconectan de manera inesperada, eliminando su conexión de la lista activa y notificando a los otros clientes.

4. **La actualización constante**: Esto se refiere a que el servidor debe estar al tanto de todos los cambios en la disponibilidad de los productos para los N clientes conectados.

## Instalación y Uso

1. Abrir la carpeta 'exa2p3'.
2. Ejecutar el servidor, lo cual se hace ejecutando el archivo .java llamado 'SrunFram' en 'backend_exa2/src/Vista'.
3. Ejecutar la cantidad de clientes deseados, esto se realiza ejecutando el archivo .java llamado 'cv' en 'frontend_exa2/src/Vista'.

    Nota: La búsqueda responde únicamente a 'Reloj' y 'Automóvil'.