create Database SistemaProveedores; 

use SistemaProveedores; 

create table Proveedores(
nombreP varchar(30), idP varchar(30), aprobado boolean, 
constraint pkProveedor primary key (idP)
);

create table Usuarios(
usern varchar(30), pasw varchar (30), tipo varchar(30), idprov varchar(30),
constraint pkUsuarios primary key (usern), 
constraint tipos check (tipo in ("ADM", "PRO")), 
constraint fkUsuario foreign key(idprov) references Proveedores(idP)
);



create table Clientes(
nombreC varchar(30), idC varchar(30), proveedorid varchar(30), correo varchar(30), telefono int, 
constraint pkCliente primary key (idC), 
constraint fkCliente foreign key (proveedorid) references Proveedores(idP)
);


create table Producto(
nombreP varchar(30), idPr varchar(30), precio float, idProd varchar(30), cant int, 
constraint pkProducto primary key (idPr,idProd),
constraint fkProducto foreign key (idProd) references Proveedores(idP)
); 


create table Facturas(
numFact INT NOT NULL AUTO_INCREMENT,
idCliente varchar(30), idProveedor varchar(30), total int, fecha varchar(30),
constraint pkFactura primary key (numFact),
constraint fk1Facturas foreign key (idCliente) references Clientes(idC), 
constraint fk2Facturas foreign key (idProveedor) references Proveedores(idP)
);

create table Detalle(
numD INT NOT NULL AUTO_INCREMENT,
numFact int, idProd varchar(30), cantidad int, monto int, 
constraint pkDetalle primary key (numD), 
constraint fk1Detalle foreign key (numFact) references Facturas(numFact), 
constraint fk2Detalle foreign key (idProd) references Producto(idPr)
);

INSERT INTO Proveedores (nombreP, idP, aprobado)
VALUES ('000', '000', TRUE);
INSERT INTO Usuarios (usern, pasw, tipo, idprov)
VALUES ('000', '000', 'ADM', '000');