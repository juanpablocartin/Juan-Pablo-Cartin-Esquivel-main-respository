# Sistema de Gestión de Facturas Electrónicas

**Integrantes:**

- Anner Angulo Gutiérrez
- Juan Pablo Cartín Esquivel
- Ignacio Bonilla Rojas

## Descripción

Este proyecto tiene como objetivo desarrollar un sistema web en Java para la gestión de facturas electrónicas, utilizando una base de datos MySQL para el almacenamiento de datos.

## Funcionalidades

1. **CRUD (Crear, Leer, Actualizar, Eliminar)**: Implementación de operaciones básicas para manejar las facturas electrónicas, permitiendo a los usuarios crear nuevas facturas, ver detalles de las existentes.

2. **Autenticación y autorización**: Integración de un sistema de autenticación para que los usuarios puedan iniciar sesión en la aplicación y acceder a las funcionalidades según sus roles. Administradores tendrían acceso completo, mientras que usuarios normales tendrían restricciones en algunas operaciones.

3. **Gestión de usuarios**: Permite a los administradores crear, ver y  actualizar cuentas de usuario, en el contexto de sus clientes productos o factruras 

4. **Validación de formularios**: Implementación de validaciones en los formularios para asegurar que los datos ingresados por los usuarios sean correctos y cumplan con los requisitos establecidos.

5. **Paginación y ordenamiento de datos**: Implementación de paginación para dividir los resultados en varias páginas y facilitar la navegación en caso de tener una gran cantidad de facturas. También permite a los usuarios ordenar los datos según diferentes criterios.

6. **Búsqueda y filtrado de datos**: Agrega funcionalidades de búsqueda y filtrado para que los usuarios puedan encontrar rápidamente las facturas electrónicas que necesitan.


## Instalación y Uso

1. Clona este repositorio.
2. Configura la base de datos MySQL y actualiza la configuración en el archivo de propiedades.
3. Ejecuta la aplicación Spring Boot.
4. Abre un navegador y visita `localhost:8080` para acceder al sistema.

