package org.example.sistemaproveedores;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaProveedoresApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaProveedoresApplication.class, args);
	}

}
