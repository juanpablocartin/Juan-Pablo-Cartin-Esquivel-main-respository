package org.example.sistemaproveedores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaProveedoresApplicationTests {

	@Test
	void contextLoads() {
	}

}
