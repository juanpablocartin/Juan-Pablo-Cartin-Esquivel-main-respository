package Modelo;

import javax.swing.table.DefaultTableModel;
import Entidades.*;

/**
 *
 * @author luare
 */
public class ModelTabCalibraciones {

    private DefaultTableModel modelo;
    private ListaCalibraciones lista;
    private int numC = 1;

    public ModelTabCalibraciones() {
        modelo = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }

        };
        lista = new ListaCalibraciones();
        formatoModelo();
    }

    public ModelTabCalibraciones(ListaCalibraciones lista) {
        this.lista = lista;
        modelo = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }

        };
        formatoModelo();

    }

    public ModelTabCalibraciones(DefaultTableModel modelo, ListaCalibraciones lista) {
        this.modelo = modelo;
        this.lista = lista;
        formatoModelo();

    }

    public DefaultTableModel getModelo() {
        return modelo;
    }

    public void setModelo(DefaultTableModel modelo) {
        this.modelo = modelo;
    }

    public ListaCalibraciones getList() {
        return lista;
    }

    public void setList(ListaCalibraciones list) {
        this.lista = list;
    }

    public void formatoModelo() {
        String[] s = {"Numero", "Fecha", "Mediciones"};
        modelo.setColumnIdentifiers(s);
    }

    public void ingresar(Calibracion c) {
        c.setNum(String.valueOf(numC++));
        lista.ingresar(c);
        modelo.addRow(new Object[]{c.getNum(), c.getFechaCalibracion(), c.getCantMediciones()});
    }

    public void ingresar(Calibracion c, String numCali) {
        if (Integer.parseInt(numCali) >= numC) {
            numC = Integer.parseInt(numCali);
            numC++;
        }
        

        c.setNum(String.valueOf(numCali));
        lista.ingresar(c);
        modelo.addRow(new Object[]{c.getNum(), c.getFechaCalibracion(), c.getCantMediciones()});
    }

    public boolean existe(String s) {
        return false;
    }

    public Calibracion getElementoPorPos(int i) {
        return lista.get(i);

    }

    public void eliminarPorPos(int i) {
        lista.getCalibraciones().remove(i);
        actualizarTabla();
    }

    public void actualizarTabla() {
        modelo.setRowCount(0);
        for (int i = 0; i < lista.tamano(); i++) {
            modelo.addRow(new Object[]{lista.get(i).getNum(), lista.get(i).getFechaCalibracion(), lista.get(i).getCantMediciones()});
        }
    }
    public void eliminarCali(Calibracion c) {
        for (int i = 0; i < this.lista.tamano(); i++) {
            if(this.lista.get(i).getNum().compareTo(c.getNum())==0){
                lista.getCalibraciones().remove(i);
            }
        }

        actualizarTabla();
    }
    public void reSet() {
        this.lista = new ListaCalibraciones();
        this.modelo = new DefaultTableModel();
        modelo = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        actualizarTabla();

    }
}
