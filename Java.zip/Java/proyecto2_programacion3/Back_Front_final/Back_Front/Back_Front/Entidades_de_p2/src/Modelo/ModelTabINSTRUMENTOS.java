package Modelo;
import javax.swing.table.DefaultTableModel;
import Entidades.*;
public class ModelTabINSTRUMENTOS {
    
    private  DefaultTableModel modelito;
    private ListaINSTRUMENTOS lis; 

//---------------------------------------------------------------------------
    public DefaultTableModel getModelito() {
        return modelito;
    }  
  //--------------------------------------------------------------------
        public ModelTabINSTRUMENTOS() {
               this.modelito= new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
               return false;
            }
            
        };
               this.lis= new ListaINSTRUMENTOS();  
               this.darFormatoModelo();
               this.inicializarModelo(); 
        }
   //--------------------------------------------------------------------
        public void  darFormatoModelo() {
        // Se define las columnas
        modelito.addColumn("No.Serie");
        modelito.addColumn("Descripcion");
        modelito.addColumn("Min");
        modelito.addColumn("Max");
        modelito.addColumn("Tolerancia");
  }
//-----------------------------------------------------------------------------------------
     public void  insertarInstru( Instrumento c){
          lis.insertarInstru(c);
         insertarFilaModelo (  lis. retornaFila (lis.getCantidad() -1) );
   }
   //--------------------------------------------------------------------------------------------------------
      public void  insertarFilaModelo ( Object [ ] filaAux){
             modelito.addRow( filaAux);
   }
     //--------------------------------------------------------------------------------------------------------  
   public void borrarRegistro (int linea) {
         modelito.removeRow(linea);
         lis.eliminarElemento(linea);
   }
      //--------------------------------------------------------------------------------------------------------

        //--------------------------------------------------------------
      public  void inicializarModelo(){
            for (int i = 0; i < lis.getCantidad(); i++)      {
                Object [ ] filAux=  lis.retornaFila (i);
                modelito.addRow(filAux);
            }
              
       }
      public  void upDateModel(){
            modelito.setRowCount(0);
            for (int i = 0; i < lis.getCantidad(); i++)      {
                Object [ ] filAux=  lis.retornaFila (i);
                modelito.addRow(filAux);
            }
              
       }
 
//-----------------------------------------------------------------------
    public ListaINSTRUMENTOS getLista() {
        return lis;
    }

       //--------------------------------------------------------------------  
    //--------------------------------------------------------------------  
    public int getIndexDEdescripcion(String s){
        int j=-1;
        for (int i = 0; i < lis.getCantidad(); i++)      {
               if(lis.getElemento(i).getDescripcion().equals(s)){ 
                   j=i;
               }
        }
        return j;
    }
    public  Instrumento getInstruCONserie(String s){
        for (int i = 0; i < lis.getCantidad(); i++)      {
                if(lis.getElemento (i).getSerie().equals(s)){  
                    return lis.getElemento (i);
               }
        }
        return null;
    }
    public void selectATindex(int i){
        //Este metodo fue implemtado para selecionar la row que se busco
    }
    public String infoDobjeto(int i){
        String s;
        s="Serie: "+lis.getElemento(i).getSerie()+"\n Descripcion: "+lis.getElemento(i).getDescripcion();
        return s;
    }
    public void update(String serie, String descrip,int min, int max , int tole,TipoInstrumento tipoDinstru){
        int x=lis.getINDEX_X_serie(serie);
        System.out.println(x);
        lis.getElemento(x).setSerie(serie);
        lis.getElemento(x).setDescripcion(descrip);
        lis.getElemento(x).setMin(min);
        lis.getElemento(x).setMax(max);
        lis.getElemento(x).setTolerancia(tole);
        lis.getElemento(x).setTipDinstrumentos(tipoDinstru);
        this.upDateModel();
    }
    public void updateDOS(String serie, String descrip,int min, int max , int tole,TipoInstrumento tipoDinstru){
        int x=lis.getINDEX_X_serie(serie);
        lis.getElemento(x).setSerie(serie);
        lis.getElemento(x).setDescripcion(descrip);
        lis.getElemento(x).setMin(min);
        lis.getElemento(x).setMax(max);
        lis.getElemento(x).setTolerancia(tole);
        lis.getElemento(x).setTipDinstrumentos(tipoDinstru);
        this.upDateModel();
    }
    public String getSerieDEdecripcionX(String s){
        for (int i = 0; i < lis.getCantidad(); i++)      {
                if(lis.getElemento (i).getDescripcion().equals(s)){  
                    return lis.getElemento (i).getSerie();
               }
        }
        return "";
    }
    public boolean BuscarXserie(String s){
        for (int i = 0; i < lis.getCantidad(); i++) {
            if (lis.getElemento(i).getSerie().equals(s)) {
                return true;
            }
        }
         return false;
    }
    public void reSet(){
        this.lis = new ListaINSTRUMENTOS();
        this.modelito = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }

        };
        this.darFormatoModelo();
        this.inicializarModelo();
    }

    public int getIndex_X_serie(String serie) {
        for (int i = 0; i < lis.getCantidad(); i++)      {
                if(lis.getElemento (i).getDescripcion().equals(serie)){  
                    return i;
               }
        }
        return -1;
    }

    public boolean BuscarXdescrip(String text) {
        for (int i = 0; i < lis.getCantidad(); i++)      {
                if(lis.getElemento (i).getDescripcion().equals(text)){  
                    return true;
               }
        }
        return false;
    }
  
   
}
