package Entidades;

import Modelo.*;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

public class Instrumento implements Serializable {

    private String Serie;
    private String Descripcion;
    private int Tolerancia;
    private int min;
    private int max;
    private TipoInstrumento tipDinstrumentos;
    private ModelTabCalibraciones calibracionesL;

    public Instrumento(String Serie, String Descripcion, int min, int max, int Tolerancia, TipoInstrumento tipDinstrumentos) {
        this.Serie = Serie;
        this.Descripcion = Descripcion;
        this.Tolerancia = Tolerancia;
        this.min = min;
        this.max = max;
        this.tipDinstrumentos = tipDinstrumentos;
        this.calibracionesL = new ModelTabCalibraciones();
    }

    public Instrumento() {
    }

    public ModelTabCalibraciones getCalibracionesL() {
        return calibracionesL;
    }

    public void setCalibracionesL(ModelTabCalibraciones calibracionesL) {
        this.calibracionesL = calibracionesL;
    }

    public String getSerie() {
        return Serie;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public int getTolerancia() {
        return Tolerancia;
    }

    public int getMin() {
        return min;
    }

    public int getMax() {
        return max;
    }

    public TipoInstrumento getTipDinstrumentos() {
        return tipDinstrumentos;
    }

    public void setSerie(String Serie) {
        this.Serie = Serie;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public void setTolerancia(int Tolerancia) {
        this.Tolerancia = Tolerancia;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public void setMax(int max) {
        this.max = max;
    }

    public void setTipDinstrumentos(TipoInstrumento tipDinstrumentos) {
        this.tipDinstrumentos = tipDinstrumentos;
    }

    @Override
    public String toString() {
        return "Serie: " + Serie + " Descripcion: " + Descripcion + " Tolerancia: " + Tolerancia + " max: " + max + " min: " + min + " TipDinstrumentos: " + tipDinstrumentos.getCodigo();
    }
    public Calibracion getCali_X_num(String num){
        return calibracionesL.getList().getCali_X_num(num);
    }

    private void writeObject(java.io.ObjectOutputStream out) throws IOException {
        out.writeUTF(Serie);
        out.writeUTF(Descripcion);
        out.writeInt(Tolerancia);
        out.writeInt(max);
        out.writeInt(min);
        //Tipos de Instrumentos
        out.writeUTF(tipDinstrumentos.getCodigo());
        out.writeUTF(tipDinstrumentos.getNombre());
        out.writeUTF(tipDinstrumentos.getUnidad());

//        ArrayList<Calibracion> listCali = calibracionesL.getList().getCalibraciones();
//        ArrayList<Medicion> listMedi;
//
//        // se hace aqui adentro o individualmente en las clases cali y medi??
//        for (Calibracion c : listCali) {
//            out.writeUTF(c.getNum());
//            out.writeUTF(c.getFechaCalibracion());
//            out.writeInt(c.getCantMediciones());
//            out.writeUTF(c.getNumSerieInstrumento());
//            listMedi = c.getMedicionesL().getMediciones().getMediciones();
//            for (Medicion m : listMedi) {
//                out.writeInt(m.getNumero());
//                out.writeInt(m.getReferencia());
//                out.writeInt(m.getLectura());
//                out.writeUTF(m.getNumCalibracion());
//                out.writeUTF(m.getNumSerieInstrumento());
//            }
//        }
    }

    private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException {
        Serie = in.readUTF();
        Descripcion = in.readUTF();
        Tolerancia = in.readInt();
        max = in.readInt();
        min = in.readInt();

        if (tipDinstrumentos == null) {
            tipDinstrumentos = new TipoInstrumento("--", "--", "--");
        }

        tipDinstrumentos.setCodigo(in.readUTF());
        tipDinstrumentos.setNombre(in.readUTF());
        tipDinstrumentos.setUnidad(in.readUTF());
        
        // read de calibraciones y mediciones!!
    }

}
