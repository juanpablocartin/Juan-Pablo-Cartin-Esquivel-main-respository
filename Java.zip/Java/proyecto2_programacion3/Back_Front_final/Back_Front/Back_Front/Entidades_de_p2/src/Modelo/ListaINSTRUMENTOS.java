package Modelo;
import Entidades.*;
import java.util.ArrayList;


public class ListaINSTRUMENTOS  {
     public   ArrayList<Instrumento>list;
 //-------------------------------------------------------------------------------------------
     ListaINSTRUMENTOS(){
            list = new ArrayList();
     }
    
 //-------------------------------------------------------------------------------------------
   public   Object [ ]  creaFilallena (Instrumento e) {  
           Object [ ] filAux= new Object  [ 6 ] ; 
            filAux[0]= e.getSerie();
            filAux[1]= e.getDescripcion();
            filAux[2]= e.getMin();
            filAux[3]= e.getMax();
            filAux[4]= e.getTolerancia();
            return filAux;
      }     
   
//-------------------------------------------------------------------------------------------
     public   Object [ ]  retornaFila (int i ) {  
           Object [ ] filAux= new Object  [ 5 ] ; 
           if (i < list.size()) {
                    Instrumento e= list.get(i);
                    filAux[0]= e.getSerie();
                    filAux[1]= e.getDescripcion();
                    filAux[2]= e.getMin();
                    filAux[3]= e.getMax();
                    filAux[4]= e.getTolerancia();
           }
            return filAux;
      }      
   
//-----------------------------------------------------------------------------------------------
    public int getCantidad(){
        return list.size();
   }
  //-----------------------------------------------------------------------------------------------
        public Instrumento  getElemento(int i){
        return list.get(i);
   }
    
  //-------------------------------------------------------------------------------------------
    public void insertarInstru(Instrumento e){
        list.add(e);
    }
    //-----------------------------------------------------------------------------------------------
    public ArrayList<Instrumento>  getArrayList(){
             return list;
   }
    //-------------------------------------------------------------------------------------------       
      
      void eliminarElemento(int pos)   {
           list.remove(pos); 
      }
      public int getINDEX(Instrumento e){
           for (int i = 0; i < list.size(); i++)      {
                if(list.get(i).getSerie().equals(e.getSerie())){
                    return i;
               }
        }
           return -1;
      }


    public int getINDEX_X_serie(String sAborrar) {
        for (int i = 0; i < list.size(); i++)      {
                if(list.get(i).getSerie().equals(sAborrar)){
                    return i;
               }
            }
           return -1;
    }


      
}
