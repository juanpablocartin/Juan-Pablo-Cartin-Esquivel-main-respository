/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 *
 * @author luare
 */
public class Medicion implements Serializable {

    private int numero;
    private int referencia;
    private int lectura;
    private String numCalibracion;
    private String numSerieInstrumento;

    public String getNumCalibracion() {
        return numCalibracion;
    }

    public void setNumCalibracion(String numCalibracion) {
        this.numCalibracion = numCalibracion;
    }

    public String getNumSerieInstrumento() {
        return numSerieInstrumento;
    }

    public void setNumSerieInstrumento(String numSerieInstrumento) {
        this.numSerieInstrumento = numSerieInstrumento;
    }

    public Medicion(int numero, int referencia, int lectura) {
        this.numero = numero;
        this.referencia = referencia;
        this.lectura = lectura;
    }

    public Medicion() {
        numero = 0;
        referencia = 0;
        lectura = 0;
    }

    public Medicion(int numero) {
        this.numero = numero;
        numero = 0;
        referencia = 0;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getReferencia() {
        return referencia;
    }

    public void setReferencia(int referencia) {
        this.referencia = referencia;
    }

    public int getLectura() {
        return lectura;
    }

    public void setLectura(int lectura) {
        this.lectura = lectura;
    }
    private void writeObject(ObjectOutputStream out)throws IOException{
        out.writeInt(numero);
        out.writeInt(this.referencia);
        out.writeInt(this.lectura);
        out.writeUTF(numCalibracion);
        out.writeUTF(numSerieInstrumento);
    }
    
    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException{
        this.numero = in.readInt();
        this.referencia = in.readInt();
        this.lectura = in.readInt();
        this.numCalibracion = in.readUTF();
        this.numSerieInstrumento = in.readUTF();
    }

    @Override
    public String toString() {
        return "Medicion{" + "numero=" + numero + ", referencia=" + referencia + ", lectura=" + lectura + ", numCalibracion=" + numCalibracion + ", numSerieInstrumento=" + numSerieInstrumento + '}';
    }
    

}
