package Entidades;


import java.util.ArrayList;
import Modelo.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Calibracion implements Serializable{

    private String num;
    private String numSerieInstrumento;
    private String fechaCalibracion;
    private int cantMediciones;
    private ModeloTabMediciones medicionesL;

   

    public Calibracion() {
        medicionesL = new ModeloTabMediciones();
    }

    public Calibracion(String num, String numSerieInstrumento, String fechaCalibracion, int cantMediciones) {
        this.num = num;
        this.numSerieInstrumento = numSerieInstrumento;
        this.fechaCalibracion = fechaCalibracion;
        this.cantMediciones = cantMediciones;
        medicionesL = new ModeloTabMediciones(cantMediciones);
        medicionesL.getMediciones().setTamano(cantMediciones);
    }
    public Calibracion(String numSerieInstrumento, String fechaCalibracion, int cantMediciones) {
        this.num = "";
        this.numSerieInstrumento = numSerieInstrumento;
        this.fechaCalibracion = fechaCalibracion;
        this.cantMediciones = cantMediciones;
        medicionesL = new ModeloTabMediciones(cantMediciones);
        medicionesL.getMediciones().setTamano(cantMediciones);
    }


    

    public ModeloTabMediciones getMedicionesL() {
        return medicionesL;
    }

    public void setMedicionesL(ModeloTabMediciones medicionesL) {
        this.medicionesL = medicionesL;
    }

    public String getFechaCalibracion() {
        return fechaCalibracion;
    }

    public void setFechaCalibracion(String fechaCalibracion) {
        this.fechaCalibracion = fechaCalibracion;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getNumSerieInstrumento() {
        return numSerieInstrumento;
    }

    public void setNumSerieInstrumento(String numSerieInstrumento) {
        this.numSerieInstrumento = numSerieInstrumento;
    }

    public int getCantMediciones() {
        return cantMediciones;
    }

    public void setCantMediciones(int cantMediciones) {
        this.cantMediciones = cantMediciones;
    }

    public void setNumLecturaMediciones(int min, int max) {
        medicionesL.numeroLectura(min, max);
    }
    public void ingresarMedicion(int pos, Medicion m){
        if (medicionesL.getMediciones().getTamano()<cantMediciones) {
            medicionesL.getMediciones().getMediciones().add(m);
        }
    }
    private void writeObject(ObjectOutputStream out)throws IOException{
        out.writeUTF(this.num);
        out.writeUTF(this.fechaCalibracion);
        out.writeInt(cantMediciones);
        out.writeUTF(this.numSerieInstrumento);
        
        
    }
    private void readObject(ObjectInputStream in)throws IOException, ClassNotFoundException{
        this.num = in.readUTF();
        this.fechaCalibracion = in.readUTF();
        this.cantMediciones = in.readInt();
        this.numSerieInstrumento = in.readUTF();              
    }
    public void ingresaMedicion(Medicion m){
        if(this.medicionesL!=null){
            
        }else{
            this.medicionesL=new ModeloTabMediciones();
            
        }
    }
    

}