package Controldaora_Cliente;

import Entidades.Calibracion;
import Entidades.Instrumento;
import Entidades.Medicion;
import Entidades.TipoInstrumento;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
//Esto se llama desde la controladora con el start, (jsuto en el constructor)

public class Cliente implements Runnable {

    private int p;//Puerto fijo
    private Controladora contro;//Para llamara a sus metodos en el runable de esta clase 
    private String hostlocal = "127.0.0.1";
    public DataInputStream Din;
    public DataOutputStream Dout;
    private ObjectOutputStream Oout;
    private ObjectInputStream Oin;
    private Object o;

    Socket socket;

    public Cliente(int p, Controladora c) {
        this.p = p;
        this.contro = c;
    }

    public void disconnect() {
        try {
            this.socket.close();
        } catch (IOException iOException) {
        }
    }

    public void Mandar_mensaje_al_Servidor(String code, Object o) {
        //Le mado un codigo y un Objecto "Serializable" al servidor 
        try {
            System.out.println("Cliente manda codigo y un Objecto al Servidor... ");
            this.Dout.writeUTF(code);
            ObjectOutputStream objOutput = new ObjectOutputStream(this.socket.getOutputStream());
            objOutput.writeObject(o);
        } catch (IOException iOException) {

        }
    }

    public void run() {
        try {
            this.socket = new Socket(hostlocal, this.p);
            this.Din = new DataInputStream(this.socket.getInputStream());
            this.Dout = new DataOutputStream(this.socket.getOutputStream());
            //-----------------------------------------------------------------------LEER-------------------------------------------------------------------------------
            //Llegan Tipos de Instrumento
            String can_de_TI = this.Din.readUTF();// TI=tipos de instrumentos
            System.out.println(can_de_TI);
            for (int i = 0; i < Integer.parseInt(can_de_TI); i++) {
                Oin = new ObjectInputStream(socket.getInputStream());
                Object obj = Oin.readObject();
                contro.admiTIPOSinstru.insertarTipoInstrumento((TipoInstrumento) obj);
            }
            contro.admiTIPOSinstru.modificaCOMBOBOX(contro.PanInstru.getTxCB_Tipo());//OJO

            //Llegan Instru
            String can_de_I = this.Din.readUTF();// I=instrumentos
            for (int i = 0; i < Integer.parseInt(can_de_I); i++) {
                Oin = new ObjectInputStream(socket.getInputStream());
                Object obj = Oin.readObject();
                Instrumento aux_instr = (Instrumento) obj;
                //Aramando el Tipo de Instruemnto del Instruemnto
                TipoInstrumento aux_TI = contro.admiTIPOSinstru.getTipDinstruXcodigo(aux_instr.getTipDinstrumentos().getCodigo());
                aux_instr.getTipDinstrumentos().setNombre(
                        aux_TI.getNombre()
                );
                aux_instr.getTipDinstrumentos().setUnidad(
                        aux_TI.getUnidad()
                );
                Instrumento aux_instrDOS = new Instrumento(
                        aux_instr.getSerie(),
                        aux_instr.getDescripcion(),
                        aux_instr.getMin(),
                        aux_instr.getMax(),
                        aux_instr.getTolerancia(),
                        aux_TI);
                contro.admiinstru.insertarInstru(aux_instrDOS);
            }
            //Llegan cali
            String can_de_cali = this.Din.readUTF();// #cali
            for (int i = 0; i < Integer.parseInt(can_de_cali); i++) {
                Oin = new ObjectInputStream(socket.getInputStream());
                Object obj = Oin.readObject();
                Calibracion cali = (Calibracion) obj;
                //Aramando la Cali, para ingresarla donde tiene que estar

                Instrumento aux_instr = contro.admiinstru.getInstruCONserie(cali.getNumSerieInstrumento());
                //public Calibracion(String num, String numSerieInstrumento, String fechaCalibracion, int cantMediciones) {
                Calibracion caliDOS = new Calibracion(cali.getNum(), cali.getNumSerieInstrumento(), cali.getFechaCalibracion(), cali.getCantMediciones());
                aux_instr.getCalibracionesL().ingresar(caliDOS, cali.getNum());
            }
            //Llegan Meid
            String can_de_medi = this.Din.readUTF();// #medi
            for (int i = 0; i < Integer.parseInt(can_de_medi); i++) {
                Oin = new ObjectInputStream(socket.getInputStream());
                Object obj = Oin.readObject();
                Medicion medi = (Medicion) obj;
                //Aramando la Medi, para ingresarla donde tiene que estar en su calibracion+en su Instruemnto

                Instrumento aux_instr = contro.admiinstru.getInstruCONserie(medi.getNumSerieInstrumento());

                int num_medi = medi.getNumero();
                aux_instr.getCali_X_num(medi.getNumCalibracion()).getMedicionesL().getMediciones().add_en_posi_x(num_medi, medi);
                //tal vez
                //aux_instr.getCali_X_num(medi.getNumCalibracion()).getMedicionesL().actualizarTabla();
            }

            //-----------------------------------------------------------------------LEER-------------------------------------------------------------------------------
            System.out.println("cliente on");//ON y con toda la info de la base de Datos
            //-----------------------------------------------------------------------Se actualizan todos los clinetse excepto el que hizo el UpDate en primer lugar
            //despues que el clinte manda al servidor, el servidor manda al cliente
            while (true) {
                String s = this.Din.readUTF();
                Oin = new ObjectInputStream(this.socket.getInputStream());
                try {
                    o = Oin.readObject(); //Nos llega X objeto del servidor pero con el codigo ya se puede saber que Objecto es O
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
                }
                //Cliente Recibiendo Objecto+Codigo de PuenteConS
                if (o != null) {
                    this.contro.UpDateDOS(s, o);
                } else {
                    System.out.println("No good");
                }
            }

        } catch (IOException ex) {
            System.out.println("cliente off");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
