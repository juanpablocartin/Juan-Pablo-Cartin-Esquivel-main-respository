package Controldaora_Cliente;

import Controldaora_Cliente.Cliente;
import Entidades.Calibracion;
//import Modelo.Fecha;
import Entidades.*;
import Modelo.*;
import Vista.*;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.WindowConstants;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class Controladora implements ActionListener {

    public VenPri VenPricipal;
    public TipInstruJPanel PanTIPOSInstru;
    public InstruJPanel PanInstru;
    public CalibracionesJPanel PanCali;

    public ModelTabINSTRUMENTOS admiinstru;
    public ModelTabTipeInstrument admiTIPOSinstru;

    //------------------------------------------------
    private ListaTipoInstrumento listaTipos;
    private PDFReportGenerator pdf;

    private Instrumento MANIinstrumrnto = null;
    //Lista global de tipos de instrumentos
    //-------------------------------------------------
    // -------------------------------- Calibraciones y mediciones ----------------------------------------
    ListaCalibraciones listCalib;
    ListaMediciones listMed;
    int contCalibraciones;
    public ModelTabCalibraciones adminCalibraciones;
    public ModeloTabMediciones adminMediciones;
    //------------Cliente
    private Cliente CLIENTE;
    private Socket clien;

    public Controladora(VenPri v, TipInstruJPanel ti, InstruJPanel i, CalibracionesJPanel c) {

        this.VenPricipal = v;
        v.setVisible(true);
        this.PanTIPOSInstru = ti;

        this.PanInstru = i;
        PanInstru.getbEditar().setEnabled(false);
        PanInstru.getbEditarCali().setEnabled(false);

        this.PanCali = c;
        VenPricipal.getTABpri().addTab("Tipos de Instrumentos", PanTIPOSInstru);
        VenPricipal.getTABpri().addTab("Instrumentos", PanInstru);
        VenPricipal.getTABpri().addTab("Calibraciones", PanCali);
        //Creación de la lista de tipos de instrumentos--------------------------------------------------
        this.listaTipos = new ListaTipoInstrumento();
        admiTIPOSinstru = new ModelTabTipeInstrument(this.listaTipos);//Se le ingresa la lista global
        ti.getTablaListTipeInstrument().setModel(admiTIPOSinstru.getModelo());
        this.PanTIPOSInstru.getTablaListTipeInstrument().getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int fila = PanTIPOSInstru.getTablaListTipeInstrument().getSelectedRow();
                    if (fila != -1) {
                        TipoInstrumento t = listaTipos.getLista().get(fila);
                        PanTIPOSInstru.getCodigoTextField().setText(t.getCodigo());
                        PanTIPOSInstru.getCodigoTextField().setEnabled(false);
                        PanTIPOSInstru.getNombreTextField().setText(t.getNombre());
                        PanTIPOSInstru.getUnidadTexttField().setText(t.getUnidad());

                        PanTIPOSInstru.getBotonBorrar().setEnabled(true);

                    }
                }
            }

        });

        admiinstru = new ModelTabINSTRUMENTOS();
        i.getTablaDInstrumentos().setModel(admiinstru.getModelito());
        //En el evento de ADD Tipo de Instrumento se tiene que agregar la siguiente liniea de codigo
        admiTIPOSinstru.modificaCOMBOBOX(PanInstru.getTxCB_Tipo());

        ///////Todo lo que va a escuchar/////////////
        this.PanInstru.getbGuardar().addActionListener(this);
        this.PanInstru.getbLimpiar().addActionListener(this);
        this.PanInstru.getbBorrar().addActionListener(this);
        this.PanInstru.getbBuscar().addActionListener(this);
        this.PanInstru.getbReporte().addActionListener(this);
        this.PanInstru.getbEditar().addActionListener(this);

        this.PanInstru.getbEditarCali().addActionListener(this);
        //this.VenPricipal.getTABpri().(this);

        this.PanTIPOSInstru.getBotonGuardar().addActionListener(this);
        this.PanTIPOSInstru.getBotonLimpiar().addActionListener(this);
        ///////Todo lo que va a escuchar/////////////

        this.PanTIPOSInstru.getBotonGuardar().addActionListener(this);
        this.PanTIPOSInstru.getBotonLimpiar().addActionListener(this);
        this.PanTIPOSInstru.getBotonBorrar().addActionListener(this);
        this.PanTIPOSInstru.getBotonBusqueda().addActionListener(this);
        this.PanTIPOSInstru.getBotonReporte().addActionListener(this);

        // limpiar text fields calibraciones
        this.PanCali.getTFbuscarPorNumero().setText("");
        this.PanCali.getTFfechaCalibracion().setText("");
        this.PanCali.getTFmedicionesCalibracion().setText("");
        this.PanCali.getJBborrar().setEnabled(false);
        this.PanCali.getTFnumeroCalibracion().setEnabled(false);
        this.PanCali.getTFnumMedicion().setEnabled(false);
        this.PanCali.getJBguardar().setEnabled(false);
        this.PanCali.getJBlimpiar().setEnabled(false);
        this.PanCali.getJBReporte().setEnabled(false);
        this.PanCali.getJBbuscar().setEnabled(false);

        // set listeners de botones calibraciones
        this.PanCali.getJBguardar().addActionListener(this);
        this.PanCali.getJBborrar().addActionListener(this);
        this.PanCali.getJBbuscar().addActionListener(this);
        this.PanCali.getJBlimpiar().addActionListener(this);
        this.PanCali.getJBReporte().addActionListener(this);

        contCalibraciones = 0;

        listCalib = new ListaCalibraciones();
        listMed = new ListaMediciones();
        adminCalibraciones = new ModelTabCalibraciones(listCalib);
        this.PanCali.getJTableCalibraciones().setModel(adminCalibraciones.getModelo());
        adminMediciones = new ModeloTabMediciones(listMed);
        this.PanCali.getJTableMediciones().setModel(adminMediciones.getModelo());
        this.PanCali.getJTableMediciones().getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int medSeleccionada = PanCali.getJTableMediciones().getSelectedRow();
                    int calibSeleccionada = PanCali.getJTableCalibraciones().getSelectedRow();
                    if (medSeleccionada > -1) {
                        Medicion m = MANIinstrumrnto.getCalibracionesL().getElementoPorPos(calibSeleccionada).getMedicionesL().getElemento(medSeleccionada);
                        PanCali.getTFnumMedicion().setText(String.valueOf(m.getNumero()));
                        PanCali.getTFnumLectura().setText(String.valueOf(m.getLectura()));
                    }
                }
            }

        });
        //---------------------------------------------------------------------------------------------------------
        //------------------------------Setting up the start of the client ------------------------------------
        this.StartCliente();
        //---------------------------------------------------------------------------------------------------------
        //---------------------------------------------------------------------------------------------------------
        VenPricipal.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                JOptionPane.showMessageDialog(null, "Cliente going OFF :) \nbye...", "Exit", JOptionPane.INFORMATION_MESSAGE);
                System.exit(0);
            }

        });

    }

    public void StartCliente() {
        this.CLIENTE = new Cliente(5000, this);
        Thread Cthre = new Thread(CLIENTE);
        Cthre.start();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //-----------------------------------------Panel Tipo de Instrumento-----------------------------------------------------

        if (e.getSource().equals(this.PanTIPOSInstru.getBotonGuardar())) {
            if (this.PanTIPOSInstru.getCodigoTextField().getText().equals("") || this.PanTIPOSInstru.getNombreTextField().getText().equals("") || this.PanTIPOSInstru.getUnidadTexttField().getText().equals("")) {
                JOptionPane.showMessageDialog(this.VenPricipal, "Debes completar todos los campos", "Error2", JOptionPane.ERROR_MESSAGE);
            } else {
                if (this.PanTIPOSInstru.getCodigoTextField().isEnabled()) {
                    TipoInstrumento t = new TipoInstrumento();
                    t.setCodigo(this.PanTIPOSInstru.getCodigoTextField().getText());
                    t.setNombre(this.PanTIPOSInstru.getNombreTextField().getText());
                    t.setUnidad(this.PanTIPOSInstru.getUnidadTexttField().getText());
                    this.admiTIPOSinstru.insertarTipoInstrumento(t);
                    //------------Cliente manda a guardar Tipo de Instru
                    this.CLIENTE.Mandar_mensaje_al_Servidor("11", t);//=================================================================================================
                    JOptionPane.showMessageDialog(this.VenPricipal, t.getNombre() + " ingresado al sistemas", "Guardar", JOptionPane.INFORMATION_MESSAGE);

                    admiTIPOSinstru.modificaCOMBOBOX(PanInstru.getTxCB_Tipo());
                    this.PanTIPOSInstru.getCodigoTextField().setText("");
                    this.PanTIPOSInstru.getNombreTextField().setText("");
                    this.PanTIPOSInstru.getUnidadTexttField().setText("");
                    admiTIPOSinstru.modificaCOMBOBOX(PanInstru.getTxCB_Tipo());
                    this.PanTIPOSInstru.getCodigoTextField().setText("");
                    this.PanTIPOSInstru.getNombreTextField().setText("");
                    this.PanTIPOSInstru.getUnidadTexttField().setText("");
                    admiTIPOSinstru.modificaCOMBOBOX(PanInstru.getTxCB_Tipo());
                } else {//Editar 

                    int fila = this.admiTIPOSinstru.getLista().getElementoPos(this.PanTIPOSInstru.getCodigoTextField().getText());
                    TipoInstrumento t = this.admiTIPOSinstru.getLista().getLista().get(fila);
                    t.setNombre(this.PanTIPOSInstru.getNombreTextField().getText());
                    t.setUnidad(this.PanTIPOSInstru.getUnidadTexttField().getText());
                    this.admiTIPOSinstru.getModelo().setValueAt(t.getNombre(), fila, 1);
                    this.admiTIPOSinstru.getModelo().setValueAt(t.getUnidad(), fila, 2);
                    this.PanTIPOSInstru.getCodigoTextField().setText("");
                    this.PanTIPOSInstru.getNombreTextField().setText("");
                    this.PanTIPOSInstru.getUnidadTexttField().setText("");
                    admiTIPOSinstru.modificaCOMBOBOX(PanInstru.getTxCB_Tipo());
                    this.PanTIPOSInstru.getCodigoTextField().setEnabled(true);
                    //------------Cliente manda a Editar Tipo de Instru
                    this.CLIENTE.Mandar_mensaje_al_Servidor("12", t);//=================================================================================================
                }

            }
        }
        if (e.getSource().equals(this.PanTIPOSInstru.getBotonLimpiar())) {
            if (this.PanTIPOSInstru.getCodigoTextField().getText().equals("") || this.PanTIPOSInstru.getNombreTextField().getText().equals("") || this.PanTIPOSInstru.getUnidadTexttField().getText().equals("")) {

            } else {
                this.PanTIPOSInstru.getCodigoTextField().setEnabled(true);
                this.PanTIPOSInstru.getCodigoTextField().setText("");
                this.PanTIPOSInstru.getNombreTextField().setText("");
                this.PanTIPOSInstru.getUnidadTexttField().setText("");
                this.PanTIPOSInstru.getBotonBorrar().setEnabled(false);
            }
        }
        if (e.getSource().equals(this.PanTIPOSInstru.getBotonBorrar())) {
            if (this.PanTIPOSInstru.getCodigoTextField().isEnabled() == false) {
                ArrayList<Instrumento> lista = this.admiinstru.getLista().getArrayList();
                Iterator<Instrumento> itr = lista.iterator();
                int cant = 0;
                while (itr.hasNext()) {
                    if (itr.next().getTipDinstrumentos().getCodigo().equals(this.PanTIPOSInstru.getCodigoTextField().getText())) {
                        cant++;
                    }
                }
                if (cant != 0) {
                    JOptionPane.showMessageDialog(this.VenPricipal, "No se puede eliminar el tipo de instrumento. El sistema cuenta con " + cant + this.PanTIPOSInstru.getNombreTextField().getText(), "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    int fila = this.admiTIPOSinstru.getLista().getElementoPos(this.PanTIPOSInstru.getCodigoTextField().getText());
                    String codeTI_Borrar = this.PanTIPOSInstru.getCodigoTextField().getText();
                    this.admiTIPOSinstru.getModelo().removeRow(fila);
                    this.admiTIPOSinstru.getLista().getLista().remove(fila);
                    this.PanTIPOSInstru.getCodigoTextField().setText("");
                    this.PanTIPOSInstru.getNombreTextField().setText("");
                    this.PanTIPOSInstru.getUnidadTexttField().setText("");
                    admiTIPOSinstru.modificaCOMBOBOX(PanInstru.getTxCB_Tipo());
                    this.PanTIPOSInstru.getCodigoTextField().setEnabled(true);
                    JOptionPane.showMessageDialog(this.VenPricipal, "Tipo de instrumento eliminado con éxito", "Borrar", JOptionPane.INFORMATION_MESSAGE);
                    //Manda a borrar X Tipo de Instrumento a la tabla `tipoinstru`
                    this.CLIENTE.Mandar_mensaje_al_Servidor("13", codeTI_Borrar);//=================================================================================================
                }

            } else {
                JOptionPane.showMessageDialog(this.VenPricipal, "Selecciona un Tipo de instrumento ", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        if (e.getSource().equals(this.PanTIPOSInstru.getBotonBusqueda())) {
            if (this.PanTIPOSInstru.getNombreBusquedaTextFiled().getText().equals("")) {
                JOptionPane.showMessageDialog(this.VenPricipal, "Digitar dato para buscar tipo de instrumento", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                TipoInstrumento t = this.admiTIPOSinstru.getLista().buscaTipoInsturmento(this.PanTIPOSInstru.getNombreBusquedaTextFiled().getText());
                if (t != null) {
                    this.PanTIPOSInstru.getCodigoTextField().setEnabled(false);
                    this.PanTIPOSInstru.getCodigoTextField().setText(t.getCodigo());
                    this.PanTIPOSInstru.getNombreTextField().setText(t.getNombre());
                    this.PanTIPOSInstru.getUnidadTexttField().setText(t.getUnidad());
                    this.PanTIPOSInstru.getBotonBorrar().setEnabled(true);
                    this.PanTIPOSInstru.getNombreBusquedaTextFiled().setText("");

                } else {
                    JOptionPane.showMessageDialog(this.VenPricipal, "Tipo de instrumento no resgistrado", "Error", JOptionPane.ERROR_MESSAGE);
                }

            }
        }
        if (e.getSource().equals(this.PanTIPOSInstru.getBotonReporte())) {
            try {
                this.pdf = new PDFReportGenerator(this.admiTIPOSinstru.getLista());
                JOptionPane.showMessageDialog(this.VenPricipal, "Informe generado", "Informe", JOptionPane.INFORMATION_MESSAGE);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(Controladora.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        //------------------------------------------------------Fin panel Tipo de Instrumento--------------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
        if (e.getSource().equals(PanInstru.getbGuardar())) {
            if (PanInstru.getTxSerie().getText().equals("") || PanInstru.getTxTolerancia().getText().equals("") || PanInstru.getTxMin().getText().equals("") || PanInstru.getTxMax().getText().equals("") || PanInstru.getTxDescripcion().getText().equals("") || PanInstru.getTxCB_Tipo().getSelectedIndex() == -1) {
                JOptionPane.showMessageDialog(null, "Debes completar todos los campos", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                Instrumento auxInstru = null;
                try {
                    auxInstru = new Instrumento(
                            PanInstru.getTxSerie().getText(),
                            PanInstru.getTxDescripcion().getText(),
                            Integer.parseInt(PanInstru.getTxMin().getText()),
                            Integer.parseInt(PanInstru.getTxMax().getText()),
                            Integer.parseInt(PanInstru.getTxTolerancia().getText()),
                            this.admiTIPOSinstru.getTipDinstruXcodigo(PanInstru.getTxCB_Tipo().getSelectedItem().toString()));
                } catch (NumberFormatException noint) {
                    JOptionPane.showMessageDialog(null, "Verifique si MIN y MAX son elemtos 100% numericos ", "Error", JOptionPane.ERROR_MESSAGE);
                }
                if (admiinstru.BuscarXserie(PanInstru.getTxSerie().getText()) == true) {
                    JOptionPane.showMessageDialog(null, "Esa serie ya existe por lo que no se puede agregar al sistema", "Error", JOptionPane.ERROR_MESSAGE);
                } else if (admiinstru.BuscarXdescrip(PanInstru.getTxDescripcion().getText()) == true) {
                    JOptionPane.showMessageDialog(null, "Esa descripcion ya existe por lo que no se puede agregar ya que despues no se podria encontarat en el  sistema", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    //proyecto #1
                    admiinstru.insertarInstru(auxInstru);
                    //Linea de Inicio, llamada al Cliente
                    //proyecto #2
                    this.CLIENTE.Mandar_mensaje_al_Servidor("21", auxInstru);//============================================================================================

                    PanInstru.getTxSerie().setText("");
                    PanInstru.getTxTolerancia().setText("");
                    PanInstru.getTxMin().setText("");
                    PanInstru.getTxMax().setText("");
                    PanInstru.getTxDescripcion().setText("");
                    PanInstru.getTxCB_Tipo().setSelectedIndex(-1);
                }

            }
            return;
        }
//--------------------------------------------------------------------------------
        if (e.getSource().equals(PanInstru.getbLimpiar())) {
            PanInstru.getTxSerie().setText("");
            PanInstru.getTxTolerancia().setText("");
            PanInstru.getTxMin().setText("");
            PanInstru.getTxMax().setText("");
            PanInstru.getTxDescripcion().setText("");
            PanInstru.getTxCB_Tipo().setSelectedIndex(-1);

            return;
        }
        if (e.getSource().equals(PanInstru.getbBuscar())) {
            if (PanInstru.getTxDescriAbuscar().getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Debe poner una Descripcion a buscar", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                String aux = "";
                int auxSerieINDEX = -1;
                aux = admiinstru.getSerieDEdecripcionX(PanInstru.getTxDescriAbuscar().getText());
                MANIinstrumrnto = admiinstru.getInstruCONserie(aux);

                if (aux != "") {
                    if (admiinstru.BuscarXserie(aux) == true) {

                        int siOno;
                        siOno = JOptionPane.showConfirmDialog(null, "EXITO SE ENCONTRO"
                                + "\nLe gustaria editar dicho instrumento ? ", "|-Si=Yes-| |-No=No-|", JOptionPane.YES_NO_OPTION);

                        if (siOno == JOptionPane.YES_OPTION) {//ERROR cuando no ahi Cali de Mai instrumento
                            PanInstru.getTxDescripcion().setEditable(false);
                            PanInstru.getTxSerie().setEditable(false);
                            PanInstru.getTxCB_Tipo().setEnabled(false);
                            PanInstru.getTxDescriAbuscar().setEditable(false);
                            PanInstru.getTxSerie().setText(admiinstru.getInstruCONserie(aux).getSerie());
                            PanInstru.getTxDescripcion().setText(admiinstru.getInstruCONserie(aux).getDescripcion());
                            PanInstru.getTxMin().setText(Integer.toString(admiinstru.getInstruCONserie(aux).getMin()));
                            PanInstru.getTxMax().setText(Integer.toString(admiinstru.getInstruCONserie(aux).getMax()));
                            PanInstru.getTxTolerancia().setText(Integer.toString(admiinstru.getInstruCONserie(aux).getTolerancia()));
                            PanInstru.getTxCB_Tipo().setSelectedIndex(
                                    admiTIPOSinstru.getIndexDtipoInstruXcodigo(admiinstru.getInstruCONserie(aux).getTipDinstrumentos().getCodigo())
                            );
                            PanInstru.getbEditar().setEnabled(true);
                            PanInstru.getbEditarCali().setEnabled(true);

                            StringBuilder s = new StringBuilder();
                            s.append(this.MANIinstrumrnto.getSerie() + " - " + this.MANIinstrumrnto.getDescripcion() + "(" + this.MANIinstrumrnto.getMin() + " - " + this.MANIinstrumrnto.getMax() + " Grados celcius)");
                            PanCali.getJLInstrumentoSeleccionado().setText(s.toString());
                            this.PanCali.getJTableCalibraciones().setModel(MANIinstrumrnto.getCalibracionesL().getModelo());

                        } else {
                            PanInstru.getTxSerie().setText("");
                            PanInstru.getTxTolerancia().setText("");
                            PanInstru.getTxMin().setText("");
                            PanInstru.getTxMax().setText("");
                            PanInstru.getTxDescripcion().setText("");
                            PanInstru.getTxCB_Tipo().setSelectedIndex(-1);
                        }

                    }
                    StringBuilder s = new StringBuilder();
                    s.append(this.MANIinstrumrnto.getSerie() + " - " + this.MANIinstrumrnto.getDescripcion() + "(" + this.MANIinstrumrnto.getMin() + " - " + this.MANIinstrumrnto.getMax() + " Grados celcius)");
                    PanCali.getJLInstrumentoSeleccionado().setText(s.toString());
                    this.adminCalibraciones = MANIinstrumrnto.getCalibracionesL();
                    this.adminCalibraciones.actualizarTabla();
                } else {
                    JOptionPane.showMessageDialog(null, "No se encontro", "Error", JOptionPane.ERROR_MESSAGE);
                }

                return;

            }
        }

//--------------------------------------------------------------------------------
//--------------------------------------------------------------------------------
        if (e.getSource().equals(PanInstru.getbEditar())) {
            System.out.println(MANIinstrumrnto.getSerie());
            try {
                admiinstru.update(
                        PanInstru.getTxSerie().getText(),
                        PanInstru.getTxDescripcion().getText(),
                        Integer.parseInt(PanInstru.getTxMin().getText()),
                        Integer.parseInt(PanInstru.getTxMax().getText()),
                        Integer.parseInt(PanInstru.getTxTolerancia().getText()),
                        admiTIPOSinstru.getTipDinstruXnombre(PanInstru.getTxCB_Tipo().getSelectedItem().toString()));
                //Instruemnto para mandar al socket
                Instrumento auxinstu = new Instrumento(
                        PanInstru.getTxSerie().getText(),
                        PanInstru.getTxDescripcion().getText(),
                        Integer.parseInt(PanInstru.getTxMin().getText()),
                        Integer.parseInt(PanInstru.getTxMax().getText()),
                        Integer.parseInt(PanInstru.getTxTolerancia().getText()),
                        admiTIPOSinstru.getTipDinstruXnombre(PanInstru.getTxCB_Tipo().getSelectedItem().toString())
                );
                this.CLIENTE.Mandar_mensaje_al_Servidor("22", auxinstu);//=====================================================================
                //Instruemnto para mandar al socket
            } catch (NumberFormatException noint) {
                JOptionPane.showMessageDialog(null, "Verifique si MIN y MAX son elemtos 100% numericos -NADA - ", "Error", JOptionPane.ERROR_MESSAGE);
            }
            PanInstru.getTxSerie().setText("");
            PanInstru.getTxTolerancia().setText("");
            PanInstru.getTxMin().setText("");
            PanInstru.getTxMax().setText("");
            PanInstru.getTxDescripcion().setText("");
            PanInstru.getTxCB_Tipo().setSelectedIndex(-1);
            PanInstru.getTxDescriAbuscar().setText("");
            PanInstru.getTxDescriAbuscar().setEditable(true);
            PanInstru.getbEditar().setEnabled(false);
            PanInstru.getbEditarCali().setEnabled(false);
            PanInstru.getTxCB_Tipo().setEnabled(true);
            PanInstru.getTxSerie().setEditable(true);
            PanInstru.getTxDescripcion().setEditable(true);

        }

//--------------------------------------------------------------------------------
        if (e.getSource().equals(PanInstru.getbBorrar())) {
            if (PanInstru.getTablaDInstrumentos().getSelectedRow() == -1) {
                JOptionPane.showMessageDialog(null, "Debe selecionar un Instrumento de la tabla para borrar", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                if (admiinstru.getLista().getElemento(PanInstru.getTablaDInstrumentos().getSelectedRow()).getCalibracionesL().getList().tamano() > 0) {
                    JOptionPane.showMessageDialog(null, "No se puede borrar un instrumento con calibracciones", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    //Que Objeto le voy a mandar al Socket en borrar?
                    //Bueno con el mensaje=num que le mando ya sabe en que tabla, le hace falta saber con que ID, bueno eso se obtine de la siguienete manera
                    int row = PanInstru.getTablaDInstrumentos().getSelectedRow();
                    String val = PanInstru.getTablaDInstrumentos().getValueAt(row, 0).toString();
                    this.CLIENTE.Mandar_mensaje_al_Servidor("23", val);//=====================================================================
                    //Colum=0 porque ahi esta la variable asociada a la llave de la tabla de MySQL
                    //System.out.println(val);
                    admiinstru.borrarRegistro(PanInstru.getTablaDInstrumentos().getSelectedRow());
                }
            }
        }
//--------------------------------------------------------------------------------
        if (e.getSource().equals(this.PanInstru.getbReporte())) {
            try {
                this.pdf = new PDFReportGenerator(this.admiinstru.getLista());
                JOptionPane.showMessageDialog(this.VenPricipal, "Informe generado", "Informe", JOptionPane.INFORMATION_MESSAGE);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(Controladora.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
//--------------------------------------------------------------------------------
        if (e.getSource().equals(this.PanInstru.getbEditarCali())) {
            PanInstru.getTxSerie().setEditable(true);
            VenPricipal.getTABpri().setSelectedIndex(2);
            String aux = "";
            aux = admiinstru.getSerieDEdecripcionX(PanInstru.getTxDescriAbuscar().getText());
            this.PanCali.getJBguardar().setEnabled(true);
            this.PanCali.getJBlimpiar().setEnabled(true);
            this.PanCali.getJBReporte().setEnabled(true);
            this.PanCali.getJBbuscar().setEnabled(true);

            PanInstru.getTxSerie().setText("");
            PanInstru.getTxTolerancia().setText("");
            PanInstru.getTxMin().setText("");
            PanInstru.getTxMax().setText("");
            PanInstru.getTxDescripcion().setText("");
            PanInstru.getTxCB_Tipo().setSelectedIndex(-1);
            PanInstru.getTxDescriAbuscar().setText("");
            PanInstru.getTxDescriAbuscar().setEditable(true);
            PanInstru.getbEditar().setEnabled(false);
            PanInstru.getbEditarCali().setEnabled(false);
        }
//-------------------------------Agregagndo una calibracion del Instrumento que se busco previamente-------------------------------------------------

        if (e.getSource().equals(this.PanCali.getJBguardar())) {

            if (!PanCali.getJBborrar().isEnabled()) {
                if (PanCali.getTFfechaCalibracion().getText().compareTo("") != 0 && PanCali.getTFmedicionesCalibracion().getText().compareTo("") != 0) {
                    agregarCalibracion();
                    this.PanCali.getTFnumeroCalibracion().setText("");
                    this.PanCali.getTFmedicionesCalibracion().setText("");
                    this.PanCali.getTFfechaCalibracion().setText("");
                } else {
                    JOptionPane.showMessageDialog(this.VenPricipal, "Debe completar todos los campos", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                String s = this.PanCali.getTFbuscarPorNumero().getText();
                int pos = MANIinstrumrnto.getCalibracionesL().getList().buscarPorNum(s);
                actualizarMediciones(pos);
                adminMediciones.setMediciones(MANIinstrumrnto.getCalibracionesL().getElementoPorPos(pos).getMedicionesL().getMediciones());

            }

        }
        if (e.getSource().equals(this.PanCali.getJBlimpiar())) {
            this.PanCali.getTFnumeroCalibracion().setText("");
            this.PanCali.getTFmedicionesCalibracion().setText("");
            this.PanCali.getTFfechaCalibracion().setText("");
            PanCali.getJBborrar().setEnabled(false);
            this.PanCali.getTFbuscarPorNumero().setText("");
            this.adminMediciones.setMediciones(new ListaMediciones());
            adminMediciones.actualizarTabla();
            this.PanCali.getJTableMediciones().setModel(adminMediciones.getModelo());
            PanCali.getJTableCalibraciones().clearSelection();
            PanCali.getJTableMediciones().clearSelection();
            this.PanCali.getTFnumLectura().setText("");
            this.PanCali.getTFnumMedicion().setText("");
            this.PanCali.getTFfechaCalibracion().setEnabled(true);
            this.PanCali.getTFmedicionesCalibracion().setEnabled(true);
        }

        if (e.getSource().equals(this.PanCali.getJBborrar())) {
            if (PanCali.getTFbuscarPorNumero().getText().compareTo("") != 0) {
                String s = this.PanCali.getTFbuscarPorNumero().getText();

                int filaSeleccionada = MANIinstrumrnto.getCalibracionesL().getList().buscarPorNum(s);
                Calibracion c = MANIinstrumrnto.getCalibracionesL().getElementoPorPos(filaSeleccionada);
                ArrayList<Medicion> list_medi = c.getMedicionesL().getMediciones().getMediciones();
                for (Medicion m : list_medi) {
                    Medicion med = new Medicion();
                    med.setNumero(m.getNumero());
                    med.setLectura(m.getLectura());
                    med.setNumSerieInstrumento(MANIinstrumrnto.getSerie());
                    med.setNumCalibracion(c.getNum());

                    this.CLIENTE.Mandar_mensaje_al_Servidor("43", med);
                }

                MANIinstrumrnto.getCalibracionesL().eliminarPorPos(filaSeleccionada);
                PanCali.getJTableCalibraciones().setModel(MANIinstrumrnto.getCalibracionesL().getModelo());

                this.CLIENTE.Mandar_mensaje_al_Servidor("33", c);
                // limpiar TFs
                this.PanCali.getTFbuscarPorNumero().setText("");
                this.PanCali.getTFnumeroCalibracion().setText("");
                this.PanCali.getTFmedicionesCalibracion().setText("");
                this.PanCali.getTFfechaCalibracion().setText("");
                PanCali.getJBborrar().setEnabled(false);

                this.adminMediciones.setMediciones(new ListaMediciones());
                adminMediciones.actualizarTabla();
            }

        }
        if (e.getSource().equals(this.PanCali.getJBReporte())) {
            try {
                JOptionPane.showMessageDialog(this.VenPricipal, "Informe generado", "Informe", JOptionPane.INFORMATION_MESSAGE);
                this.pdf = new PDFReportGenerator(MANIinstrumrnto.getCalibracionesL().getList());

            } catch (FileNotFoundException ex) {
                Logger.getLogger(Controladora.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        if (e.getSource().equals(this.PanCali.getJBbuscar())) {
            String s = this.PanCali.getTFbuscarPorNumero().getText();
            if (this.MANIinstrumrnto.getCalibracionesL().getList().existe(s)) {
                int pos = MANIinstrumrnto.getCalibracionesL().getList().buscarPorNum(s);
                this.PanCali.getJTableCalibraciones().setRowSelectionInterval(pos, pos);
                PanCali.getJBborrar().setEnabled(true);
                PanCali.getTFnumeroCalibracion().setText(s);
                PanCali.getTFfechaCalibracion().setText(this.MANIinstrumrnto.getCalibracionesL().getElementoPorPos(pos).getFechaCalibracion());
                String cantM = String.valueOf(this.MANIinstrumrnto.getCalibracionesL().getElementoPorPos(pos).getCantMediciones());
                PanCali.getTFmedicionesCalibracion().setText(cantM);
                adminMediciones.setMediciones(MANIinstrumrnto.getCalibracionesL().getElementoPorPos(pos).getMedicionesL().getMediciones());
                adminMediciones.actualizarTabla();
                PanCali.getJTableMediciones().setModel(adminMediciones.getModelo());
                this.PanCali.getTFfechaCalibracion().setEnabled(false);
                this.PanCali.getTFmedicionesCalibracion().setEnabled(false);

            } else {
                JOptionPane.showMessageDialog(null, "No hay coincidencias", "Error", JOptionPane.INFORMATION_MESSAGE);
            }
        }

    }

    public void actualizarMediciones(int pos) {
        try {
            int fila = PanCali.getJTableMediciones().getSelectedRow();
            String s = PanCali.getTFnumLectura().getText();
            MANIinstrumrnto.getCalibracionesL().getElementoPorPos(pos).getMedicionesL().editarMedicion(fila, Integer.parseInt(s));

            Medicion aux = new Medicion();
            aux.setNumero(MANIinstrumrnto.getCalibracionesL().getElementoPorPos(pos).getMedicionesL().getElemento(fila).getNumero());
            aux.setLectura(MANIinstrumrnto.getCalibracionesL().getElementoPorPos(pos).getMedicionesL().getElemento(fila).getLectura());
            aux.setNumCalibracion(MANIinstrumrnto.getCalibracionesL().getElementoPorPos(pos).getNum());
            aux.setNumSerieInstrumento(MANIinstrumrnto.getSerie());
            this.CLIENTE.Mandar_mensaje_al_Servidor("42", aux);

            MANIinstrumrnto.getCalibracionesL().getElementoPorPos(pos).getMedicionesL().actualizarTabla();

            this.PanCali.getJTableMediciones().setModel(MANIinstrumrnto.getCalibracionesL().getElementoPorPos(pos).getMedicionesL().getModelo());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this.PanCali, "Solo puede ingresar valores numéricos", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }

    }

    public void guardaMediciones(ListaMediciones l) {
        ArrayList<Medicion> aux = l.getMediciones();
        for (Medicion m : aux) {
            this.CLIENTE.Mandar_mensaje_al_Servidor("41", m);
        }

    }

    public void agregarCalibracion() {
        try {
            if (this.ValidadorFecha(PanCali.getTFfechaCalibracion().getText())) {
                Calibracion c;
                c = new Calibracion(MANIinstrumrnto.getSerie(), PanCali.getTFfechaCalibracion().getText(),
                        Integer.parseInt(PanCali.getTFmedicionesCalibracion().getText()));
                c.setMedicionesL(new ModeloTabMediciones(c.getCantMediciones()));
                c.setNumLecturaMediciones(this.MANIinstrumrnto.getMin(), this.MANIinstrumrnto.getMax());
                c.setNumSerieInstrumento(MANIinstrumrnto.getSerie());
                this.MANIinstrumrnto.getCalibracionesL().ingresar(c);
                c.getMedicionesL().getMediciones().setearIDs(c.getNum(), MANIinstrumrnto.getSerie());

                this.CLIENTE.Mandar_mensaje_al_Servidor("31", c);
                this.guardaMediciones(c.getMedicionesL().getMediciones());
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this.PanCali, "Solo puede ingresar valores numéricos", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }

    }

    public boolean ValidadorFecha(String fecha) {
        // 0000-00-00
        // 0123456789
        // xxxx-xx-xx

        boolean siono = true;
        char[] cV = fecha.toCharArray();
        StringBuilder sB;

        if (cV.length != 10 || cV[4] != '-' || cV[7] != '-') {
            JOptionPane.showMessageDialog(null, "Formato de fecha debe ser aaaa-mm-dd", "Error en fecha", JOptionPane.ERROR_MESSAGE);
            siono = false;
        } else {
            try {
                //annio
                sB = new StringBuilder();
                sB.append(cV[0]).append(cV[1]).append(cV[2]).append(cV[3]);
                Integer.parseInt(sB.toString());

                // mes
                sB = new StringBuilder();
                sB.append(cV[5]).append(cV[6]);
                if (Integer.parseInt(sB.toString()) > 12) {
                    siono = false;
                    JOptionPane.showMessageDialog(null, "Valor de mes es invalido", "Error en fecha", JOptionPane.ERROR_MESSAGE);

                }
                
                // dia
                sB = new StringBuilder();
                sB.append(cV[8]).append(cV[9]);
                if (Integer.parseInt(sB.toString()) > 31) {
                    siono = false;
                    JOptionPane.showMessageDialog(null, "Valor de dia es invalido", "Error en fecha", JOptionPane.ERROR_MESSAGE);

                }

            } catch (NumberFormatException e) {
                siono = false;
                JOptionPane.showMessageDialog(null, "Debe ingresar valores numericos", "Error en fecha", JOptionPane.ERROR_MESSAGE);

            }

        }

        return siono;
    }

    public void UpDateDOS(String x, Object o) {
        TipoInstrumento tiaux = null;
        Instrumento aux_instr = null;
        switch (x) {
            //Tipos_Instru
            case "11": {
                tiaux = (TipoInstrumento) o;
                if (admiTIPOSinstru.buscarXcodigo(tiaux.getCodigo()) == true) {
                    //No hago Nada 
                } else {
                    this.admiTIPOSinstru.insertarTipoInstrumento(tiaux);
                }
                admiTIPOSinstru.modificaCOMBOBOX(PanInstru.getTxCB_Tipo());
            }
            break;
            case "12": {

                tiaux = (TipoInstrumento) o;
                int fila = this.admiTIPOSinstru.getLista().getElementoPos(tiaux.getCodigo());
                TipoInstrumento t = this.admiTIPOSinstru.getLista().getLista().get(fila);

                if ((tiaux.getNombre().equals(t.getNombre())) && (tiaux.getUnidad().equals(t.getUnidad()))) {
                    //soy el cliente que lo edito
                } else {
                    t.setNombre(tiaux.getNombre());
                    t.setUnidad(tiaux.getUnidad());
                    this.admiTIPOSinstru.getModelo().setValueAt(tiaux.getNombre(), fila, 1);
                    this.admiTIPOSinstru.getModelo().setValueAt(tiaux.getUnidad(), fila, 2);
                    admiTIPOSinstru.modificaCOMBOBOX(PanInstru.getTxCB_Tipo());
                }
            }
            break;
            case "13": {
                String cAborrar = (String) o;
                if (admiTIPOSinstru.getTipDinstruXcodigo(cAborrar) == null) {
                    //Soy el que mando el mensaje 
                } else {
                    int fila = this.admiTIPOSinstru.getLista().getElementoPos(cAborrar);
                    this.admiTIPOSinstru.getModelo().removeRow(fila);
                    this.admiTIPOSinstru.getLista().getLista().remove(fila);
                    admiTIPOSinstru.modificaCOMBOBOX(PanInstru.getTxCB_Tipo());
                }
            }
            break;
            //Instru
            case "21": {
                aux_instr = (Instrumento) o;
                if (admiinstru.BuscarXserie(aux_instr.getSerie()) == true) {
                    //No hago Nada 
                } else {
                    this.admiinstru.insertarInstru(aux_instr);

                }
            }
            break;
            case "22": {
                aux_instr = (Instrumento) o;
                Instrumento i = this.admiinstru.getInstruCONserie(aux_instr.getSerie());

                if ((aux_instr.getDescripcion().equals(i.getDescripcion()))
                        && (aux_instr.getMax() == (i.getMax()))
                        && (aux_instr.getMin() == (i.getMin()))
                        && (aux_instr.getTolerancia() == (i.getTolerancia()))
                        && (aux_instr.getTipDinstrumentos().getCodigo().equals(i.getTipDinstrumentos().getCodigo()))) {
                    //soy el cliente que lo edito , no tengo que hacer nada
                } else {
                    admiinstru.updateDOS(
                            aux_instr.getSerie(),
                            aux_instr.getDescripcion(),
                            aux_instr.getMin(),
                            aux_instr.getMax(),
                            aux_instr.getTolerancia(),
                            admiTIPOSinstru.getTipDinstruXcodigo(aux_instr.getTipDinstrumentos().getCodigo()));
                }
            }
            break;
            case "23": {
                String sAborrar = (String) o;

                if (admiinstru.BuscarXserie(sAborrar) == false) {
                    //Soy el que mando el mensaje 
                } else {
                    int fila = this.admiinstru.getLista().getINDEX_X_serie(sAborrar);
                    admiinstru.borrarRegistro(fila);
                }
            }
            break;
            //Cali
            case "31": {
                Calibracion c = (Calibracion) o;
                Instrumento ins = this.admiinstru.getInstruCONserie(c.getNumSerieInstrumento());

                if (ins.getCali_X_num(c.getNum()) != null) {

                } else {
                    c.setMedicionesL(new ModeloTabMediciones(c.getCantMediciones()));
                    c.setNumLecturaMediciones(ins.getMin(), ins.getMax());
                    ins.getCalibracionesL().ingresar(c, c.getNum());
                    this.PanCali.getJTableCalibraciones().setModel(ins.getCalibracionesL().getModelo());

                }

            }
            break;
            case "32": {

            }
            break;
            case "33": {
                Instrumento ins;
                Calibracion c = (Calibracion) o;
                ins = this.admiinstru.getInstruCONserie(c.getNumSerieInstrumento());
                if (ins.getCali_X_num(c.getNum()) == null) {
                } else {
                    this.admiinstru.getInstruCONserie(c.getNumSerieInstrumento()).getCali_X_num(c.getNum()).getMedicionesL().getMediciones().getMediciones().clear();
                    this.admiinstru.getInstruCONserie(c.getNumSerieInstrumento()).getCalibracionesL().eliminarCali(c);
                    this.admiinstru.getInstruCONserie(c.getNumSerieInstrumento()).getCalibracionesL().actualizarTabla();
                    this.PanCali.getJTableCalibraciones().setModel(this.admiinstru.getInstruCONserie(c.getNumSerieInstrumento()).getCalibracionesL().getModelo());

                }

            }
            break;
            //Medi
            case "41": {

            }
            break;
            case "42": {
                Medicion m_aux = (Medicion) o;
                Medicion aux = this.admiinstru.getInstruCONserie(m_aux.getNumSerieInstrumento()).getCali_X_num(m_aux.getNumCalibracion()).getMedicionesL().getElemento(m_aux.getNumero() - 1);
                if (aux.getLectura() == m_aux.getLectura()) {
                } else {
                    aux.setLectura(m_aux.getLectura());
                }
            }
            break;
            case "43": {

            }
            break;
            default:// nada ;
            }
    }
}

//-----------------NOTAS:---------------------------------------------
//-----------------Integer.toString(DE_INT_A_STRING);-----------------
//-----------------Integer.parseInt(DE_STRING_A_INT);-----------------
