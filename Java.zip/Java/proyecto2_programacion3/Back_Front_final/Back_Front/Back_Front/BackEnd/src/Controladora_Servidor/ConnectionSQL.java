package Controladora_Servidor;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JOptionPane;
// librerias base de datos
import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class ConnectionSQL {
    private static final String URL = "jdbc:mysql://localhost:3306/proyecto2P3?autoReconnect=true&useSSL=false";
    private static final String USERNAME = "root"; 
    private static final String PASSWORD = "root";////////////////Ojo con la contrasena  Profe="123456"
    private static Connection cone = null;
    //            this.cone=this.ObjectForSQLcone.getConection ();
//-------------------------------------------------------------- 
    public static Connection  getConection () {
          try {
            Class.forName("com.mysql.jdbc.Driver");
            cone = (Connection) DriverManager.getConnection(URL, USERNAME, PASSWORD); // aqui realizamos propiamente la conexion
            return cone;
        }
        catch (  ClassNotFoundException | SQLException e)  {
               JOptionPane.showMessageDialog(null, "Error en la Conexion"+e);
        }
          return null;
   }

//-------------------------------------------------------------- 
    public static void closeCone_with_try_catch(){
                try {
                    if (cone != null) {
                        cone.close();
                    }
                } catch (SQLException ex) {
                    System.out.println(ex.toString());
                }
    }
    //-------------------------------------------------------------- 
}
