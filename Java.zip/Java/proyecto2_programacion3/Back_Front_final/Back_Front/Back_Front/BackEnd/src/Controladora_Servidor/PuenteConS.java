package Controladora_Servidor;

import Entidades.Calibracion;
import Entidades.Instrumento;
import Entidades.Medicion;
import Entidades.TipoInstrumento;
import com.mysql.jdbc.Connection;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PuenteConS implements Runnable {
    // -------------------------------- Cone SQL ----------------------------------------
    private Connection cone;
    private ConnectionSQL ObjectForSQLcone;
    //-------------------------------------------------//-------------------------------------------------
    //-------------------------------------------------VARIABLES AUX--------------------------------------
    //--------------------------------Solo para efectos de no estar decalradno estas variables------------
    private String uno, dos, tres, cuatro, cinco;
    private int unoI, dosI, tresI, cuatroI;
    private TipoInstrumento TIaux = null;
    private Instrumento ii=null;
    private Calibracion cali=null;
    private Medicion medi=null;
    //-------------------------------------------------//-------------------------------------------------
    private final Socket clientSocket;
    private ServidorConexion CONEX_S;
    private DataInputStream Din;
    private DataOutputStream Dout;
    private ObjectInputStream Oin;
    private ObjectOutputStream Oout;
    
    private String CODIGO_DE_INSTRUCCION;
    
    public PuenteConS(Socket c, ServidorConexion s) throws IOException{
        this.clientSocket = c;
        this.CONEX_S = s;
        Din = new DataInputStream(clientSocket.getInputStream());
        Dout = new DataOutputStream(clientSocket.getOutputStream());
    }

    @Override
    public void run() {
        try{
        //----------------------------------------------Leer-----------------------------------------------------------------
                //Proceso despues de accepatr (para que todos los clinetes tengan la base de datos):
                //Tipo Instru
                this.Dout.writeUTF(
                Integer.toString(this.can_de_rows_Tabla_tipoinstru())//le paso el numero de tipos de instrumentos que va a leer 
                );
                //ya el cliente recivio el # de objecto que va a leer
                this.manda_Tipos_de_Instrumentos();
                //Instru---------------------------------------------
                this.Dout.writeUTF(
                Integer.toString(this.can_de_rows_Tabla_instru())//le paso el numero de tipos de instrumentos que va a leer 
                );
                //ya el cliente recivio el # de objecto que va a leer
                this.manda_Instrumentos();
                //Cali---------------------------------------------
                this.Dout.writeUTF(
                Integer.toString(this.can_de_rows_Tabla_cali())//le paso el numero de tipos de instrumentos que va a leer 
                );
                //ya el cliente recivio el # de objecto que va a leer
                this.manda_Cali();
                //Medi---------------------------------------------
                this.Dout.writeUTF(
                Integer.toString(this.can_de_rows_Tabla_medi())//le paso el numero de tipos de instrumentos que va a leer 
                );
                //ya el cliente recivio el # de objecto que va a leer
                this.manda_Medi();
            } catch (SQLException ex) {
                Logger.getLogger(PuenteConS.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
            Logger.getLogger(PuenteConS.class.getName()).log(Level.SEVERE, null, ex);
        }
                
       //----------------------------------------------Leer-----------------------------------------------------------------
        while (true) {                
            try {
                //CODIGO_DE_INSTRUCCION= la acion que hizo X cliente
               ///Servidor Esperadno codigo
                CODIGO_DE_INSTRUCCION = Din.readUTF(); 
                //Recibo code del Cliente que viene de ->Controladora
                
                if (CODIGO_DE_INSTRUCCION.equals(null)) {
                    CONEX_S.OutCliente(clientSocket);
                }
                else {
                    //Recibo Objeto del Cliente que viene de ->Controladora
                    Oin = new ObjectInputStream(clientSocket.getInputStream());
                    Object obj = Oin.readObject(); //Nos llega X objeto del Clente
                    ///Servidor recibe mensaje+Objecto en PuenteConS
                    switch(CODIGO_DE_INSTRUCCION){
                        //Tipos_Instru
                        case "11":{
                            //add ele tipoinstru
                            CONEX_S.UpDate_tabla_tipoinstru(CODIGO_DE_INSTRUCCION,obj);//////////////////////////////////////////////////////////////////////
                        }break;

                        case "12":{
                            //edit ele tipoinstru
                            CONEX_S.UpDate_tabla_tipoinstru(CODIGO_DE_INSTRUCCION,obj);//////////////////////////////////////////////////////////////////////
                        }break;

                        case "13":{
                            //borra tipoinstru
                            CONEX_S.UpDate_tabla_tipoinstru(CODIGO_DE_INSTRUCCION,obj);//////////////////////////////////////////////////////////////////////
                        }break;

                        //Instru
                        case "21":{
                            try {
                                //add ele instru
                                CONEX_S.UpDate_tabla_instru(CODIGO_DE_INSTRUCCION,obj);//////////////////////////////////////////////////////////////////////
                            } catch (SQLException ex) {
                                Logger.getLogger(PuenteConS.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }break;
                        case "22":{
                            try {
                                //edit ele tipoinstru
                                CONEX_S.UpDate_tabla_instru(CODIGO_DE_INSTRUCCION,obj);//////////////////////////////////////////////////////////////////////
                            } catch (SQLException ex) {
                                Logger.getLogger(PuenteConS.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }break;
                        case "23":{
                            try {
                                ///borra instru
                                CONEX_S.UpDate_tabla_instru(CODIGO_DE_INSTRUCCION,obj);//////////////////////////////////////////////////////////////////////
                            } catch (SQLException ex) {
                                Logger.getLogger(PuenteConS.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }break;
                        //Cali
                        case "31":{
                            //add cali
                            CONEX_S.UpDate_tabla_cali(CODIGO_DE_INSTRUCCION,obj);//////////////////////////////////////////////////////////////////////
                        }break;

                        case "32":{
                            //edit cali
                            CONEX_S.UpDate_tabla_cali(CODIGO_DE_INSTRUCCION,obj);//////////////////////////////////////////////////////////////////////
                        }break;

                        case "33":{
                            //borra cali
                            CONEX_S.UpDate_tabla_cali(CODIGO_DE_INSTRUCCION,obj);//////////////////////////////////////////////////////////////////////
                        }break;

                        //Medi
                        case "41":{
                            //add medi
                            CONEX_S.UpDate_tabla_medi(CODIGO_DE_INSTRUCCION,obj);//////////////////////////////////////////////////////////////////////
                        }break;

                        case "42":{
                            //edit medi 
                            CONEX_S.UpDate_tabla_medi(CODIGO_DE_INSTRUCCION,obj);//////////////////////////////////////////////////////////////////////
                        }break;

                        case "43":{
                            //borra medi 
                            CONEX_S.UpDate_tabla_medi(CODIGO_DE_INSTRUCCION,obj);//////////////////////////////////////////////////////////////////////
                        }break;

                        default:// nada ;
                    }
                }
            } catch (IOException | ClassNotFoundException ex) {
                
            } catch (SQLException ex) {
                Logger.getLogger(PuenteConS.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    //-------------------------------------------------------------------------------
    public int can_de_rows_Tabla_tipoinstru() throws SQLException{
        String ALLSQL_TipoInstru = "SELECT id_codigo, nombrel, unidad FROM proyecto2p3.tipoinstru";
        int res=0;
        this.cone = this.ObjectForSQLcone.getConection();
        PreparedStatement ps=null;
        ResultSet rs=null;
        ps = cone.prepareStatement(ALLSQL_TipoInstru);
        rs = ps.executeQuery();
        while(rs.next()){
            res=res+1;
        }
        ObjectForSQLcone.closeCone_with_try_catch();
        return res;
    }
    //-------------------------------------------------------------------------------
    public int can_de_rows_Tabla_instru() throws SQLException{
        String ALLSQL_Instru = "SELECT id_serie, decripcion, tolerancia, max, min, tipoinstru_id_codigo FROM instru";
        int res=0;
        this.cone = this.ObjectForSQLcone.getConection();
        PreparedStatement ps=null;
        ResultSet rs=null;
        ps = cone.prepareStatement(ALLSQL_Instru);
        rs = ps.executeQuery();
        while(rs.next()){
            res=res+1;
        }
        ObjectForSQLcone.closeCone_with_try_catch();
        return res;
    }
    //-------------------------------------------------------------------------------
    public int can_de_rows_Tabla_cali() throws SQLException{
        String ALLSQL_Cali = "SELECT id_numDcali, fecha, canDmedi, instru_id_serie FROM cali";
        int res=0;
        this.cone = this.ObjectForSQLcone.getConection();
        PreparedStatement ps=null;
        ResultSet rs=null;
        ps = cone.prepareStatement(ALLSQL_Cali);
        rs = ps.executeQuery();
        while(rs.next()){
            res=res+1;
        }
        ObjectForSQLcone.closeCone_with_try_catch();
        return res;
    }
    //-------------------------------------------------------------------------------
    public int can_de_rows_Tabla_medi() throws SQLException{

        String ALLSQL_Medi = "SELECT id_numDmedi, referencia, lectura, cali_id_numDcali, cali_instru_id_serie FROM medi";
        int res=0;
        this.cone = this.ObjectForSQLcone.getConection();
        PreparedStatement ps=null;
        ResultSet rs=null;
        ps = cone.prepareStatement(ALLSQL_Medi);
        rs = ps.executeQuery();
        while(rs.next()){
            res=res+1;
        }
        ObjectForSQLcone.closeCone_with_try_catch();
        return res;
    }
    public void manda_Tipos_de_Instrumentos() throws SQLException, IOException{
        String ALLSQL_TipoInstru = "SELECT id_codigo, nombrel, unidad FROM tipoinstru";
        this.cone = this.ObjectForSQLcone.getConection();
        PreparedStatement ps=null;
        ResultSet rs=null;
        ps = cone.prepareStatement(ALLSQL_TipoInstru);
        rs = ps.executeQuery();

        while (rs.next()) {//ojo con can y can
            uno = (rs.getString("id_codigo"));
            dos = (rs.getString("nombrel"));
            tres = (rs.getString("unidad"));
            TIaux = new TipoInstrumento(uno, dos, tres);
            Oout= new ObjectOutputStream(clientSocket.getOutputStream());
            Oout.writeObject(TIaux);
        }
    }
    public void manda_Instrumentos() throws SQLException, IOException{
        String ALLSQL_Instru = "SELECT id_serie, decripcion, tolerancia, max, min, tipoinstru_id_codigo FROM instru";
        this.cone = this.ObjectForSQLcone.getConection();
        PreparedStatement ps=null;
        ResultSet rs=null;
        ps = cone.prepareStatement(ALLSQL_Instru);
        rs = ps.executeQuery();
        while (rs.next()) {//ojo con can y can
            uno = (rs.getString("id_serie"));
            dos = (rs.getString("decripcion"));
            unoI = (rs.getInt("tolerancia"));
            dosI = (rs.getInt("max"));
            tresI = (rs.getInt("min"));
            TIaux = new TipoInstrumento(rs.getString("tipoinstru_id_codigo"),"","");//Esos valores los voy a setear en la controladora a la hora de leer
            ii = new Instrumento(uno, dos, tresI, dosI, unoI, TIaux);
            Oout= new ObjectOutputStream(clientSocket.getOutputStream());
            Oout.writeObject(ii);
        }
        ObjectForSQLcone.closeCone_with_try_catch();

    }
    public void manda_Cali() throws SQLException, IOException{
        String ALLSQL_Cali = "SELECT id_numDcali, fecha, canDmedi, instru_id_serie FROM cali";
        this.cone = this.ObjectForSQLcone.getConection();
        PreparedStatement ps=null;
        ResultSet rs=null;
        ps = cone.prepareStatement(ALLSQL_Cali);
        rs = ps.executeQuery();
        while (rs.next()) {//ojo con can y can
            uno = (rs.getString("id_numDcali"));
            dos = (rs.getString("fecha"));
            unoI = (rs.getInt("canDmedi"));
            tres = (rs.getString("instru_id_serie"));
            cali=new Calibracion(uno,tres,dos, unoI);
            
            Oout= new ObjectOutputStream(clientSocket.getOutputStream());
            Oout.writeObject(cali);
        }
        ObjectForSQLcone.closeCone_with_try_catch();
        
        
    }
    public void manda_Medi() throws SQLException, IOException{
        String ALLSQL_Medi = "SELECT id_numDmedi, referencia, lectura, cali_id_numDcali, cali_instru_id_serie FROM medi";
        this.cone = this.ObjectForSQLcone.getConection();
        PreparedStatement ps=null;
        ResultSet rs=null;
        ps = cone.prepareStatement(ALLSQL_Medi);
        rs = ps.executeQuery();
        while (rs.next()) {//ojo con can y can
            unoI = (rs.getInt("id_numDmedi"));
            dosI = (rs.getInt("referencia"));
            tresI = (rs.getInt("lectura"));
            uno = (rs.getString("cali_id_numDcali"));
            dos = (rs.getString("cali_instru_id_serie"));
            medi=new Medicion(unoI,dosI,tresI);
            medi.setNumCalibracion(uno);
            medi.setNumSerieInstrumento(dos);
            Oout= new ObjectOutputStream(clientSocket.getOutputStream());
            Oout.writeObject(medi);
        }
        ObjectForSQLcone.closeCone_with_try_catch();
    }
}

