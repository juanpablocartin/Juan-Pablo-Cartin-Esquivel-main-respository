package Controladora_Servidor;

import Controladora_Servidor.PuenteConS;
import Entidades.Calibracion;
import Entidades.Instrumento;
import Entidades.Medicion;
import Entidades.TipoInstrumento;
import com.mysql.jdbc.Connection;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServidorConexion implements Runnable {

    private ArrayList<Socket> clientes;
    private ArrayList<PuenteConS> AL_ps;
    private int PUERTO;
    private ServerSocket serverSocket;
    private Socket sc;
    private DataInputStream Din;
    private DataOutputStream Dout;
    private ObjectOutputStream Oout;
    private ObjectInputStream Oin;
    // -------------------------------- Cone SQL ----------------------------------------
    private Connection cone;
    private ConnectionSQL ObjectForSQLcone;

    //-------------------------------------------------//-------------------------------------------------
    //--------------------------------------------------------------------------------------
    public ServidorConexion(int puerto) {
        this.PUERTO = puerto;
        this.clientes = new ArrayList();
        this.AL_ps = new ArrayList();

    }
    //-------------------------------------------------------------------------------

    @Override
    public void run() {
        serverSocket = null;
        sc = null;
        try {
            //Apeans Inicial el servido
            serverSocket = new ServerSocket(this.PUERTO);
            System.out.println("SERVER ON, in port: " + this.PUERTO);
            while (true) {
                //Esperando por Cliente 
                sc = serverSocket.accept();

                ///Cliente agregado a la lista de Clientes
                clientes.add(sc);

                PuenteConS ps = new PuenteConS(sc, this);
                AL_ps.add(ps);
                //Cliente en comunicaccion constante con el servidor
                Thread commsThread = new Thread(ps);
                commsThread.start();
                //fin de acciones Cliente->Servidor (Directo)
            }
        } catch (IOException ex) {
        }
    }

    //--------------------------------------------------------------------------------------
    public void OutCliente(Socket client) {
        try {
            if (client.isConnected() == false) {
                client.close();
                AL_ps.remove(clientes.indexOf(client));
                clientes.remove(client);
                System.out.println("Algo salio mal");
            }
        } catch (IOException ex) {

        }
    }
    //--------------------------------------------------------------------------------------

    public void closeServer() throws IOException {
        for (Socket var : this.clientes) {
            var.close();
        }
        try {
            serverSocket.close();
            sc.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    //-------------------------------------------------------------------------------

    public void UpDate_tabla_tipoinstru(String CODIGO_DE_INSTRUCCION, Object o) throws SQLException, IOException {
        TipoInstrumento tiaux = null;
        //=============================================================
        this.cone = this.ObjectForSQLcone.getConection();//Open Conection
        PreparedStatement ps = null;
        ResultSet rs = null;
        //============================================================
        String coidgoDregreso = "";
        switch (CODIGO_DE_INSTRUCCION) {
            case "11": {
                tiaux = (TipoInstrumento) o;
                ps = cone.prepareStatement("INSERT INTO proyecto2p3.tipoinstru (id_codigo, nombrel, unidad) VALUES (?, ?, ?)");
                ps.setString(1, tiaux.getCodigo());
                ps.setString(2, tiaux.getNombre());
                ps.setString(3, tiaux.getUnidad());
                int res = ps.executeUpdate();
                if (res > 0) {
                    System.out.println("Se logro en ingrsar un Tipo de Instrumento con serie= " + tiaux.getCodigo());
                } else {
                    System.out.println("Error while adding into MySQL table 'instru'");
                }
                coidgoDregreso = "11";
            }
            break;
            case "12": {
                tiaux = (TipoInstrumento) o;
                ps = cone.prepareStatement("UPDATE proyecto2p3.tipoinstru SET id_codigo = ?, nombrel = ?, unidad = ? WHERE (id_codigo = ?)");
                ps.setString(1, tiaux.getCodigo());
                ps.setString(2, tiaux.getNombre());
                ps.setString(3, tiaux.getUnidad());
                ps.setString(4, tiaux.getCodigo());
                int res = ps.executeUpdate();
                if (res > 0) {
                    System.out.println("Se logro en editar un Tipo de Instrumento con serie= " + tiaux.getCodigo());
                } else {
                    System.out.println("Error while adding into MySQL table 'instru'");
                }
                coidgoDregreso = "12";
            }
            break;
            case "13": {
                String serieAborrar = (String) o;
                ps = cone.prepareStatement("DELETE FROM proyecto2p3.tipoinstru WHERE (id_codigo = ?)");
                ps.setString(1, serieAborrar);
                int res = ps.executeUpdate();
                if (res > 0) {
                    System.out.println("Se logro en Borrar un Tipo de Instrumento con serie= " + serieAborrar);
                } else {
                    System.out.println("Error while adding into MySQL table 'instru'");
                }
                coidgoDregreso = "13";
            }
            break;//borrar o==string==identificador
            default:// nada ;
        }
        ObjectForSQLcone.closeCone_with_try_catch();
        //Actualizar la JTable + listas de todos los clientes
        for (Socket var : this.clientes) {
            DataOutputStream Dout_de_var = new DataOutputStream(var.getOutputStream());
            if (coidgoDregreso != "") {
                Dout_de_var.writeUTF(coidgoDregreso);
            }
            ObjectOutputStream objOutput = new ObjectOutputStream(var.getOutputStream());
            objOutput.writeObject(o);
        }
    }
    //-------------------------------------------------------------------------------

    public void UpDate_tabla_instru(String CODIGO_DE_INSTRUCCION, Object o) throws SQLException, IOException {
        String coidgoDregreso = "";
        Instrumento aux_instr = null;
        //=============================================================
        this.cone = this.ObjectForSQLcone.getConection();//Open Conection
        PreparedStatement ps = null;
        ResultSet rs = null;
        //============================================================
        switch (CODIGO_DE_INSTRUCCION) {
            case "21": {
                //Casteo del Objecto, como se sabe que es ?? bueno:= CODIGO_DE_INSTRUCCION
                aux_instr = (Instrumento) o;
                ps = cone.prepareStatement("INSERT INTO proyecto2p3.instru (id_serie, decripcion, tolerancia,max,min,tipoinstru_id_codigo)  VALUES (?,?,?,?,?,?)");// ?==modificable
                ps.setString(1, aux_instr.getSerie()); // modificando
                ps.setString(2, aux_instr.getDescripcion());
                ps.setString(3, Integer.toString(aux_instr.getTolerancia()));
                ps.setString(4, Integer.toString(aux_instr.getMax())); // modificando
                ps.setString(5, Integer.toString(aux_instr.getMin()));
                ps.setString(6, aux_instr.getTipDinstrumentos().getCodigo());
                //Devuelve algo res>0, o no devuelve nada res==0
                int res = ps.executeUpdate();//Cantidad de resultados afectados
                if (res > 0) {
                    //Mensajes en Consaola que val un 20% de la nota final
                    System.out.println("Se logro en Ingresar Instrumento con serie= " + aux_instr.getSerie());
                } else {
                    System.out.println("Error while adding into MySQL table 'instru'");
                }
                //Importante para que todos los Clientes subcritos sepan que hacer
                coidgoDregreso = "21";
            }
            break;
            case "22": {
                aux_instr = (Instrumento) o;
                ps = cone.prepareStatement("UPDATE proyecto2p3.instru SET decripcion = ?, tolerancia = ?, max = ?, min = ? WHERE (id_serie = ?) and (tipoinstru_id_codigo = ?)");
                ps.setString(1, aux_instr.getDescripcion());
                ps.setString(2, Integer.toString(aux_instr.getTolerancia()));
                ps.setString(3, Integer.toString(aux_instr.getMax()));
                ps.setString(4, Integer.toString(aux_instr.getMin()));
                ps.setString(5, aux_instr.getSerie());
                ps.setString(6, aux_instr.getTipDinstrumentos().getCodigo());

                int res = ps.executeUpdate();
                if (res > 0) {
                    System.out.println("Se logro en editar un Instrumento con serie= " + aux_instr.getSerie());
                } else {
                    System.out.println("Error while adding into MySQL table 'instru'");
                }
                coidgoDregreso = "22";
            }
            break;
            case "23": {
                String serieAborrar = (String) o;
                ps = cone.prepareStatement("DELETE FROM proyecto2p3.instru WHERE (id_serie = ?)");
                ps.setString(1, serieAborrar);
                int res = ps.executeUpdate();
                if (res > 0) {
                    System.out.println("Se logro en Borrar un Instrumento con serie= " + serieAborrar);
                } else {
                    System.out.println("Error while adding into MySQL table 'instru'");
                }
                coidgoDregreso = "23";
            }
            break;
            default:
                break;
        }
        ObjectForSQLcone.closeCone_with_try_catch();
        //Actualizar la JTable + listas de todos los clientes
        for (Socket var : this.clientes) {
            DataOutputStream Dout_de_var = new DataOutputStream(var.getOutputStream());
            if (coidgoDregreso != "") {
                Dout_de_var.writeUTF(coidgoDregreso);
            }
            ObjectOutputStream objOutput = new ObjectOutputStream(var.getOutputStream());
            objOutput.writeObject(o);
        }
    }
    //-------------------------------------------------------------------------------

    public void UpDate_tabla_cali(String CODIGO_DE_INSTRUCCION, Object o) throws IOException, SQLException {
        //=============================================================
        this.cone = this.ObjectForSQLcone.getConection();//Open Conection
        PreparedStatement ps = null;
        ResultSet rs = null;
        //============================================================
        String coidgoDregreso = "";
        switch (CODIGO_DE_INSTRUCCION) {
            case "31": {
                this.cone = this.ObjectForSQLcone.getConection();
                ps = null;
                rs = null;
                Calibracion c = (Calibracion) o;
                System.out.println("Mandando calibracion num " + c.getNum() + " del instrumento " + c.getNumSerieInstrumento());
                ps = cone.prepareStatement("INSERT INTO cali (id_numDcali, fecha, canDmedi, instru_id_serie) VALUES (?,?,?,?)");
                ps.setString(1, c.getNum());
                ps.setString(2, c.getFechaCalibracion());
                ps.setInt(3, c.getCantMediciones());
                ps.setString(4, c.getNumSerieInstrumento());

                int res = ps.executeUpdate();
                if (res > 0) {
                    System.out.println("se agrego calibracion " + c.getNum() + " del instrumento " + c.getNumSerieInstrumento());
                } else {
                    System.out.println("Error al intentar agregar " + c.getNum() + " del instrumento " + c.getNumSerieInstrumento());

                }
                ObjectForSQLcone.closeCone_with_try_catch();
                coidgoDregreso = "31";

            }
            break;
            case "32": {

            }
            break;
            case "33": {
                this.cone = this.ObjectForSQLcone.getConection();
                ps = cone.prepareStatement("DELETE FROM proyecto2p3.cali WHERE (id_numDcali = ?) and (instru_id_serie = ?)");
                Calibracion c = (Calibracion) o;
                ps.setString(1, c.getNum());
                ps.setString(2, c.getNumSerieInstrumento());
                int res3 = ps.executeUpdate();
                if (res3 > 0) {
                    System.out.println("Se elimino la calibracion #" + c.getNum() + " del instrumento " + c.getNumSerieInstrumento());
                } else {
                    System.out.println("Error al intentar eliminar la calibracion #" + c.getNum() + " del instrumento " + c.getNumSerieInstrumento());

                }
                ObjectForSQLcone.closeCone_with_try_catch();

                coidgoDregreso = "33";
            }
            break;//borrar o==string==identificador
            default:// nada ;
        }
        ObjectForSQLcone.closeCone_with_try_catch();
        //Actualizar la JTable + listas de todos los clientes
        for (Socket var : this.clientes) {
            DataOutputStream Dout_de_var = new DataOutputStream(var.getOutputStream());
            if (coidgoDregreso != "") {
                Dout_de_var.writeUTF(coidgoDregreso);
            }
            ObjectOutputStream objOutput = new ObjectOutputStream(var.getOutputStream());
            objOutput.writeObject(o);
        }
    }
    //-------------------------------------------------------------------------------

    public void UpDate_tabla_medi(String CODIGO_DE_INSTRUCCION, Object o) throws IOException, SQLException {
        //=============================================================
        this.cone = this.ObjectForSQLcone.getConection();//Open Conection
        PreparedStatement ps = null;
        ResultSet rs = null;
        //============================================================
        String coidgoDregreso = "";
        switch (CODIGO_DE_INSTRUCCION) {
            case "41": {
                this.cone = this.ObjectForSQLcone.getConection();
                ps = null;
                rs = null;
                Medicion aux_med = (Medicion) o;
                System.out.println("Mandando medición" + aux_med.getNumero() + "de la calibración" + aux_med.getNumSerieInstrumento());
                ps = cone.prepareStatement("INSERT INTO medi (id_numDmedi, referencia, lectura, cali_id_numDcali, cali_instru_id_serie) VALUES (?,?,?,?,?)");
                ps.setString(1, String.valueOf(aux_med.getNumero()));
                ps.setString(2, String.valueOf(aux_med.getReferencia()));
                ps.setString(3, Integer.toString(aux_med.getLectura()));
                ps.setString(4, aux_med.getNumCalibracion());
                ps.setString(5, aux_med.getNumSerieInstrumento());
                int res = ps.executeUpdate();
                if (res > 0) {
                    System.out.println("Se agrego la medición " + aux_med.getNumero() + " a la calibración " + aux_med.getNumCalibracion() + " del instrumento " + aux_med.getNumSerieInstrumento());
                } else {
                    System.out.println("Error while adding into MySQL table 'instru'");
                }
                ObjectForSQLcone.closeCone_with_try_catch();
                //Importante para que todos los Clientes subcritos sepan que hacer
                coidgoDregreso = "41";

            }
            break;
            case "42": {
                this.cone = this.ObjectForSQLcone.getConection();
                ps = null;
                rs = null;
                Medicion aux_med = (Medicion) o;
                System.out.println("Editando medicion" + aux_med.getNumero() + "de la calibración" + aux_med.getNumSerieInstrumento());
                ps = cone.prepareStatement("UPDATE medi SET lectura = ? WHERE id_numDmedi = ? and cali_id_numDcali = ? and cali_instru_id_serie = ?");
                ps.setString(1, String.valueOf(aux_med.getLectura()));
                ps.setString(2, String.valueOf(aux_med.getNumero()));
                ps.setString(3, aux_med.getNumCalibracion());
                ps.setString(4, aux_med.getNumSerieInstrumento());
                int res = ps.executeUpdate();
                if (res > 0) {
                    System.out.println("Se edito la lectura de la medición " + aux_med.getNumero() + " a la calibración " + aux_med.getNumCalibracion() + " del instrumento " + aux_med.getNumSerieInstrumento());
                } else {
                    System.out.println("Error while adding into MySQL table 'medi'");
                }
                ObjectForSQLcone.closeCone_with_try_catch();
                //Importante para que todos los Clientes subcritos sepan que hacer
                coidgoDregreso = "42";

            }
            break;
            case "43": {
                {//Eliminación de las mediciones 
                    //DELETE FROM `proyecto2p3`.`medi` WHERE (`id_numDmedi` = '3') and (`cali_id_numDcali` = '1') and (`cali_instru_id_serie` = 'i1');

                    this.cone = this.ObjectForSQLcone.getConection();
                    ps = null;
                    rs = null;
                    Medicion aux_med = (Medicion) o;

                    ps = cone.prepareStatement("DELETE FROM proyecto2p3.medi WHERE (id_numDmedi = ?) and (cali_id_numDcali = ?) and (cali_instru_id_serie = ?)");
                    ps.setString(1, String.valueOf(aux_med.getNumero()));
                    ps.setString(2, aux_med.getNumCalibracion());
                    ps.setString(3, aux_med.getNumSerieInstrumento());
                    int res = ps.executeUpdate();
                    if (res > 0) {
                        System.out.println("Se edito la lectura de la medicion " + aux_med.getNumero() + " a la calibracion " + aux_med.getNumCalibracion() + " del instrumento " + aux_med.getNumSerieInstrumento());
                    } else {
                        System.out.println("Error while adding into MySQL table 'medi'");
                    }
                    ObjectForSQLcone.closeCone_with_try_catch();
                    //Importante para que todos los Clientes subcritos sepan que hacer
                    coidgoDregreso = "43";
                }
            }
            break;//borrar o==string==identificador
            default:// nada ;
        }
        ObjectForSQLcone.closeCone_with_try_catch();
        //Actualizar la JTable + listas de todos los clientes
        for (Socket var : this.clientes) {
            DataOutputStream Dout_de_var = new DataOutputStream(var.getOutputStream());
            if (coidgoDregreso != "") {
                Dout_de_var.writeUTF(coidgoDregreso);
            }
            ObjectOutputStream objOutput = new ObjectOutputStream(var.getOutputStream());
            objOutput.writeObject(o);
        }
    }

}
