-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema proyecto2p3
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `proyecto2p3` ;

-- -----------------------------------------------------
-- Schema proyecto2p3
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `proyecto2p3` DEFAULT CHARACTER SET utf8mb3 ;
USE `proyecto2p3` ;

-- -----------------------------------------------------
-- Table `proyecto2p3`.`tipoinstru`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `proyecto2p3`.`tipoinstru` ;

CREATE TABLE IF NOT EXISTS `proyecto2p3`.`tipoinstru` (
  `id_codigo` VARCHAR(45) NOT NULL,
  `nombrel` VARCHAR(45) NOT NULL,
  `unidad` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id_codigo`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb3;


-- -----------------------------------------------------
-- Table `proyecto2p3`.`instru`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `proyecto2p3`.`instru` ;

CREATE TABLE IF NOT EXISTS `proyecto2p3`.`instru` (
  `id_serie` VARCHAR(45) NOT NULL,
  `decripcion` VARCHAR(45) NOT NULL,
  `tolerancia` INT NOT NULL,
  `max` INT NOT NULL,
  `min` INT NOT NULL,
  `tipoinstru_id_codigo` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id_serie`, `tipoinstru_id_codigo`),
  INDEX `fk_instru_tipoinstru_idx` (`tipoinstru_id_codigo` ASC) VISIBLE,
  CONSTRAINT `fk_instru_tipoinstru`
    FOREIGN KEY (`tipoinstru_id_codigo`)
    REFERENCES `proyecto2p3`.`tipoinstru` (`id_codigo`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb3;


-- -----------------------------------------------------
-- Table `proyecto2p3`.`cali`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `proyecto2p3`.`cali` ;

CREATE TABLE IF NOT EXISTS `proyecto2p3`.`cali` (
  `id_numDcali` VARCHAR(45) NOT NULL,
  `fecha` DATE NOT NULL,
  `canDmedi` INT NOT NULL,
  `instru_id_serie` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id_numDcali`, `instru_id_serie`),
  INDEX `fk_cali_instru1_idx` (`instru_id_serie` ASC) VISIBLE,
  CONSTRAINT `fk_cali_instru1`
    FOREIGN KEY (`instru_id_serie`)
    REFERENCES `proyecto2p3`.`instru` (`id_serie`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb3;


-- -----------------------------------------------------
-- Table `proyecto2p3`.`medi`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `proyecto2p3`.`medi` ;

CREATE TABLE IF NOT EXISTS `proyecto2p3`.`medi` (
  `id_numDmedi` INT NOT NULL,
  `referencia` INT NOT NULL,
  `lectura` INT NOT NULL,
  `cali_id_numDcali` VARCHAR(45) NOT NULL,
  `cali_instru_id_serie` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id_numDmedi`, `cali_id_numDcali`, `cali_instru_id_serie`),
  INDEX `fk_medi_cali1_idx` (`cali_id_numDcali` ASC, `cali_instru_id_serie` ASC) VISIBLE,
  CONSTRAINT `fk_medi_cali1`
    FOREIGN KEY (`cali_id_numDcali` , `cali_instru_id_serie`)
    REFERENCES `proyecto2p3`.`cali` (`id_numDcali` , `instru_id_serie`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb3;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
