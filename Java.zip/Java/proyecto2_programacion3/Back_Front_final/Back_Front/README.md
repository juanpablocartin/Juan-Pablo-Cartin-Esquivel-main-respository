# Proyecto #2 Programación 3 Dispositivos Medicos

- **Integrantes:** 
Juan Pablo Cartín Esquivel
Lua Bonilla Jiménez
Carlos Bonilla Jiménez

## Descripción

Este proyecto tiene como propósito ejemplificar el manejo de Sockets e Hilos para la creación de una aplicación de manejo de dispositivos médicos (instrumentos), los cuales cuentan con el siguiente desglose: cada instrumento tiene un tipo, calibraciones y mediciones (las cuales se resumen en detalles del mismo, sin funcionalidad alguna).

## Funcionalidades

1. **Multithreading**: Implementación de hilos para manejar múltiples conexiones de clientes de manera concurrente.

2. **Envío y recepción de mensajes**: Los clientes pueden enviar mensajes al servidor y este los distribuye a todos los clientes conectados.

3. **Manejo de clientes desconectados**: Lógica para manejar clientes que se desconectan de manera inesperada, eliminando su conexión de la lista activa y notificando a los otros clientes.

4. **La actualización constante**: Esto se refiere a que el servidor debe estar al tanto de todos los cambios en la información de los instrumentos para los N clientes conectados.

## Instalación y Uso
1. Configura la base de datos MySQL y actualiza la configuración en el archivo de propiedades.
2. Seguir la siguiente ruta: 'proyecto2_programacion3\Back_Front_final\Back_Front'.
3. Ejecutar el servidor, lo cual se hace ejecutando el archivo .java llamado 'Servidor' en 'BackEnd/src/Vista_Servidor'.
4. Ejecutar la cantidad de clientes deseados, esto se realiza ejecutando el archivo .java llamado 'VenPri' en 'FrontEnd/src/Vista'.