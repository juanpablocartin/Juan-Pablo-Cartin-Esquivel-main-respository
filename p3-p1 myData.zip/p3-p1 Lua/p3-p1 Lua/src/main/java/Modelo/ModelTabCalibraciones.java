/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import javax.swing.table.DefaultTableModel;

/**
 *
 * @author luare
 */
public class ModelTabCalibraciones {

    private DefaultTableModel modelo;
    private ListaCalibraciones lista;
    private int numCalib;

    public ModelTabCalibraciones() {
        modelo = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
               return false;
            }
            
        };
        lista = new ListaCalibraciones();
        formatoModelo();
        numCalib = 1;
    }

    public ModelTabCalibraciones(ListaCalibraciones lista) {
        this.lista = lista;
        modelo = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
               return false;
            }
            
        };
        formatoModelo();

    }

    public ModelTabCalibraciones(DefaultTableModel modelo, ListaCalibraciones lista) {
        this.modelo = modelo;
        this.lista = lista;
        formatoModelo();

    }

    public DefaultTableModel getModelo() {
        return modelo;
    }

    public void setModelo(DefaultTableModel modelo) {
        this.modelo = modelo;
    }

    public ListaCalibraciones getList() {
        return lista;
    }

    public void setList(ListaCalibraciones list) {
        this.lista = list;
    }

    public void formatoModelo() {
        String[] s = {"Numero", "Fecha", "Mediciones"};
        modelo.setColumnIdentifiers(s);
    }

    public void ingresar(Calibracion c) {
        c.setNum(String.valueOf(numCalib++));
        lista.ingresar(c);
        modelo.addRow(new Object[]{"# "+c.getNum(), c.getFechaCalibracion(), c.getCantMediciones()});
    }

    public boolean existe(String s) {
        return false;
    }
    public Calibracion getElementoPorPos(int i) {
        return lista.get(i);

    }
    public void eliminarPorPos(int i){
        lista.getCalibraciones().remove(i);
        actualizarTabla();
    }
    
    public void actualizarTabla() {
        modelo.setRowCount(0);
        for (int i = 0; i < lista.tamano(); i++) {
            modelo.addRow(new Object[]{lista.get(i).getNum(), lista.get(i).getFechaCalibracion(), lista.get(i).getCantMediciones()});
        }
    }

    
}
