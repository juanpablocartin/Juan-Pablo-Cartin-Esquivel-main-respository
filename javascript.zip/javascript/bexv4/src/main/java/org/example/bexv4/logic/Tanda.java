package org.example.bexv4.logic;

public class Tanda {
    private String idtanda;
    private Pelicula peliculaTanda;
    private String fecha;
    private String hora;
    private int numSala;

    public String getIdtanda() {
        return idtanda;
    }

    public void setIdtanda(String idtanda) {
        this.idtanda = idtanda;
    }

    public Pelicula getPeliculaTanda() {
        return peliculaTanda;
    }

    public void setPeliculaTanda(Pelicula peliculaTanda) {
        this.peliculaTanda = peliculaTanda;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public int getNumSala() {
        return numSala;
    }

    public void setNumSala(int numSala) {
        this.numSala = numSala;
    }

    public Tanda(String idtanda, Pelicula peliculaTanda, String fecha, String hora, int numSala) {
        this.idtanda = idtanda;
        this.peliculaTanda = peliculaTanda;
        this.fecha = fecha;
        this.hora = hora;
        this.numSala = numSala;
    }

    public Tanda clone(){
        return new Tanda(this.idtanda,this.peliculaTanda,this.fecha,hora,this.numSala);

    }

}
