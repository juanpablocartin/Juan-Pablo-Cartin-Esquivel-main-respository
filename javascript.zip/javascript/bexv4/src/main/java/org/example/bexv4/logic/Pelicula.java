package org.example.bexv4.logic;

import java.util.ArrayList;
import java.util.List;

public class Pelicula {
    private String id;
    private String nombre  ;
    private String lenguaje;
    private String hora;
    private String genero;
    private String categoria;
    private int padulto;
    private int pnino;
    private List<Tanda> tandas;

    public List<Tanda> getTandas() {
        return tandas;
    }

    public void setTandas(List<Tanda> tandas) {
        this.tandas = tandas;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getLenguaje() {
        return lenguaje;
    }

    public void setLenguaje(String lenguaje) {
        this.lenguaje = lenguaje;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getPadulto() {
        return padulto;
    }

    public void setPadulto(int padulto) {
        this.padulto = padulto;
    }

    public int getPnino() {
        return pnino;
    }

    public void setPnino(int pnino) {
        this.pnino = pnino;
    }
    public Pelicula() {
        this.id ="";
        this.nombre = "";
        this.lenguaje = "";
        this.hora = "";
        this.genero = "";
        this.categoria = "";
        this.padulto = 0;
        this.pnino = 0;
        this.tandas= new ArrayList<>();
    }
    public Pelicula(String id, String nombre, String lenguaje, String hora, String genero, String categoria, int padulto, int pnino) {
        this.id = id;
        this.nombre = nombre;
        this.lenguaje = lenguaje;
        this.hora = hora;
        this.genero = genero;
        this.categoria = categoria;
        this.padulto = padulto;
        this.pnino = pnino;
        this.tandas= new ArrayList<Tanda>();
    }
    public Pelicula clone(){
        return new Pelicula(this.id,this.nombre,this.lenguaje,this.hora,this.genero,this.categoria,this.padulto,this.pnino);
    }
}
