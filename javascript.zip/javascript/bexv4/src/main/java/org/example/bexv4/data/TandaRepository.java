package org.example.bexv4.data;

import org.example.bexv4.data.PeliculaRepository;
import org.example.bexv4.logic.Tanda;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component("tandaRepository")
public class TandaRepository {

    List<Tanda> list;

    public Tanda findById(String id) throws Exception{
        Tanda r = list.stream()
                .filter( e->e.getIdtanda().equals(id))
                .findFirst().get();
        return r.clone();
    }
    public List<Tanda> findAll(){
        return list;
    }

    public List<Tanda> findByFecha(String fecha){
        return list.stream()
                .filter( e->e.getFecha().equals(fecha))
                .sorted((o1, o2) -> o1.getPeliculaTanda().getId().compareTo(o2.getPeliculaTanda().getId()))
                .toList();
    }
    public List<Tanda> findByPeliculaANDfecha(String nombre,String fecha){
        List<Tanda> aux=list.stream()
                .filter( e->e.getPeliculaTanda().getNombre().equals(nombre))
                .toList();

        aux=aux.stream()
                .filter( e->e.getFecha().equals(fecha))
                .toList();
        return aux;
    }

    public TandaRepository() {
        PeliculaRepository peliculaRepository=new PeliculaRepository();
        list = new ArrayList<Tanda>();
        try{
            list.add(new Tanda("1",peliculaRepository.findById("batman"), "2024-06-13","02:30 p. m.",6));
            list.add(new Tanda("2",peliculaRepository.findById("batman"),"2024-06-14","06:00 p. m.",4));
            list.add(new Tanda("3",peliculaRepository.findById("morbius"),"2024-06-15","12:20 p. m.",5));
            list.add(new Tanda("4",peliculaRepository.findById("morbius"),"2024-06-13","02:35 p. m.",5));
            list.add(new Tanda("5",peliculaRepository.findById("morbius"),"2024-06-14","04:45 p. m.",5));
            list.add(new Tanda("6",peliculaRepository.findById("jujutsu"),"2024-06-15","11:00 a. m.",3));
            list.add(new Tanda("7",peliculaRepository.findById("jujutsu"),"2024-06-13","02:30 p. m.",3));
            list.add(new Tanda("8",peliculaRepository.findById("jujutsu"),"2024-06-14","04:40 p. m.",3));
            list.add(new Tanda("9",peliculaRepository.findById("jujutsu"),"2024-06-15","06:55 p. m.",3));
            list.add(new Tanda("10",peliculaRepository.findById("batman"),"2024-06-13","01:00 p. m.",4));
            list.add(new Tanda("11",peliculaRepository.findById("tiposmalos"),"2024-06-14","11:30 a. m.",5));
            list.add(new Tanda("12",peliculaRepository.findById("tiposmalos"),"2024-06-15","05:30 p. m.",5));
            list.add(new Tanda("13",peliculaRepository.findById("sonic2"),"2024-06-13","01:30 a. m.",6));
            list.add(new Tanda("14",peliculaRepository.findById("sonic2"),"2024-06-14","04:00 p. m.",6));
            list.add(new Tanda("15",peliculaRepository.findById("sonic2"),"2024-06-15","02:00 p. m.",6));
            list.add(new Tanda("16",peliculaRepository.findById("animales3"),"2024-06-13","01:00 p. m.",5));
            list.add(new Tanda("17",peliculaRepository.findById("animales3"),"2024-06-14","03:30 p. m.",5));
        }
        catch(Exception e){
            System.out.println(e);
        }
    }



}
