package org.example.bexv4.presntation;

import org.example.bexv4.data.PeliculaRepository;
import org.example.bexv4.data.TandaRepository;
import org.example.bexv4.logic.Pelicula;
import org.example.bexv4.logic.Tanda;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@RestController
@RequestMapping("/peliculas")
public class PeliculasRC {

    @Autowired
    PeliculaRepository pelirepo;
    @Autowired
    private TandaRepository tandaRepository;

    @GetMapping
    public List<Pelicula> read() {
        return pelirepo.findAll();
    }

    @GetMapping("find/{id}")
    public Pelicula read(@PathVariable String id) {
        try {
            return pelirepo.findById(id);
        } catch (Exception ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
    }
    @GetMapping("/fechas")
    public List<String> fechas() {
        Date fecha= new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        List<String> fechas = new ArrayList<String>();
        for(int i=0;i<4;i++){
            fechas.add(sdf.format(fecha));
            fecha.setDate(fecha.getDate()+1);
        }
        return fechas;
    }

    @GetMapping("findbyfecha/{id}/{fecha}")
    public List<Tanda> findfecha(@PathVariable String id ,@PathVariable String fecha ) {
        try {
            List<Tanda> aux;
            aux=tandaRepository.findByFecha(fecha);

            aux= aux.stream()
                    .filter( e->e.getPeliculaTanda().getId().equals(id))
                    .toList();
            return aux;
        } catch (Exception ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
    }
}
