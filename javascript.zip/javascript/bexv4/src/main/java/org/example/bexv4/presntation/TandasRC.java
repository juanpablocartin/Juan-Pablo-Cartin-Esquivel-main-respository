package org.example.bexv4.presntation;

import org.example.bexv4.data.TandaRepository;
import org.example.bexv4.logic.Pelicula;
import org.example.bexv4.logic.Tanda;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/tandas")
public class TandasRC {

    @Autowired
    private TandaRepository tandaRepository;

    @GetMapping
    public List<Tanda> getList(){
        return tandaRepository.findAll();
    }
    @GetMapping("/find/{fecha}")
    public List<Tanda> findfecha(@PathVariable String fecha ) {
        try {
            return tandaRepository.findByFecha(fecha);
        } catch (Exception ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
    }
    @PostMapping("/findBYnombrePeli/{nombre}")
    public List<Tanda> findBYnombrePeli(@PathVariable String nombre ,@RequestBody String fecha) {
        fecha = fecha.replaceAll("\"", "");
        try {
            List<Tanda> AUX =tandaRepository.findByPeliculaANDfecha(nombre,fecha);
            return AUX;
        } catch (Exception ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
    }



}