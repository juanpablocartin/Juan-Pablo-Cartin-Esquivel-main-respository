package org.example.bexv4.logic;

public class Compra {

    private String Tiquete;

    private int boletosGenerales;

    private int boletosAdultoMayor;

    private String tanda;

    private String cedula;

    private String nombre;

    private String tarjeta;

    public String getTiquete() {
        return Tiquete;
    }

    public int getBoletosGenerales() {
        return boletosGenerales;
    }

    public int getBoletosAdultoMayor() {
        return boletosAdultoMayor;
    }

    public String getTanda() {
        return tanda;
    }

    public String getCedula() {
        return cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTarjeta() {
        return tarjeta;
    }

    public Compra(String tiquete, int boletosGenerales, int boletosAdultoMayor, String tanda, String cedula, String nombre, String tarjeta){
        this.Tiquete=tiquete;
        this.boletosGenerales=boletosGenerales;
        this.boletosAdultoMayor=boletosAdultoMayor;
        this.tanda=tanda;
        this.cedula = cedula;
        this.nombre = nombre;
        this.tarjeta = tarjeta;

    }
    public Compra(){
        this.Tiquete="";
        this.boletosGenerales=0;
        this.boletosAdultoMayor=0;
        this.tanda="";
        this.cedula = "";
        this.nombre = "";
        this.tarjeta="";
    }

    public Compra clone(){
        return new Compra(Tiquete,boletosGenerales,boletosAdultoMayor,tanda,cedula,nombre,tarjeta);
    }

}