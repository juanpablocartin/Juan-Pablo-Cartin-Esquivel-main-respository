document.addEventListener("DOMContentLoaded",LoginMAINRENDER);

var Tandasstate ={
    PeliculaAUX:{id :"", nombre : "", lenguaje : "", hora : "", genero : "", categoria : "", padulto : 0, pnino : 0},
    TabdaAux:{idtanda:"",peliculaTanda:"",fecha:"",hora:"",numSala:""},
    FechaAux:""
}
async function LoginMAINRENDER(event) {
    try{ await mainrender();} catch(error){return;}
    var item=sessionStorage.getItem("tandaAcomprar");
    if(JSON.parse(item)!="") {
        await seeINFOtanda(item);

    }
}
function seeINFOtanda(item){
    var listado=document.getElementById("container");
    Tandasstate.TabdaAux=JSON.parse(item);
    console.log(Tandasstate.TabdaAux.peliculaTanda.nombre);
    listado.innerHTML=`
    <div id="infopeli" class="infopeli">
            <div style="background-color: lightblue; padding: 10px;">ID tanda: ${Tandasstate.TabdaAux.idtanda}</div>
            <div style="background-color: lightgreen; padding: 10px;">Nombre de pelicula: ${Tandasstate.TabdaAux.peliculaTanda.nombre}</div>
            <div style="background-color: lightcoral; padding: 10px;">Fecha tanda: ${Tandasstate.TabdaAux.fecha}</div>
            <div style="background-color: lightsalmon; padding: 10px;">Hora tanda: ${Tandasstate.TabdaAux.hora}</div>
            <div style="background-color: lightblue; padding: 10px;">Numero de sala de tanda: ${Tandasstate.TabdaAux.numSala}</div>
        </div>
    `;
}