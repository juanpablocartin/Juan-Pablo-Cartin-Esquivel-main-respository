document.addEventListener("DOMContentLoaded",LoginMAINRENDER);

var backend="http://localhost:8080";http://localhost:8080/tandas/findBYnombrePeli/
var cPeliculas=backend+'/peliculas';

var Peliculasstate ={
    list: new Array(),
    listTandas: new Array(),
    listFechs: new Array(),
    PeliculaAUX:{id :"", nombre : "", lenguaje : "", hora : "", genero : "", categoria : "", padulto : 0, pnino : 0},
    TabdaAux:{idtanda:"",peliculaTanda:"",fecha:"",hora:"",numSala:""},
    FechaAux:""
}
async function LoginMAINRENDER(event) {
    try{ await mainrender();} catch(error){return;}

    var fechaACTUAL=sessionStorage.getItem("fecha");
    if(JSON.parse(fechaACTUAL)!="") {
        await remderFechas();

    }

}
async function remderFechas(){
    const request = new Request(cPeliculas+"/fechas", {method: 'GET', headers: { }});
    await (async ()=>{
        const response = await fetch(request);
        if (!response.ok) {errorMessage(response.status);return;}
        Peliculasstate.listFechs = await response.json();
        render_listFechas();
    })();
}
function render_listFechas(){
    var listado=document.getElementById("flexPAfechas");
    listado.innerHTML="";
    Peliculasstate.listFechs.forEach( item=>render_each_fechas(listado,item));

}
function render_each_fechas(listado,item){
    var div = document.createElement("div");
    div.className  = "eachfecha";
    div.innerHTML = `
    <input  id="fecha" class="fecha" type="button" value=${item}>
    `;
    div.querySelector("#fecha").addEventListener("click",()=>{setSession(item)});

    listado.append(div);
}
function setSession(item){
    sessionStorage.setItem("fecha",JSON.stringify(item));
    renderfechaActual();
}
function renderfechaActual(){
    var fechaACTUAL=sessionStorage.getItem("fecha");
    if(fechaACTUAL!=""){
        var Space4date=document.getElementById("Space4date");
        var h1 = document.createElement("h1");
        h1.textContent=JSON.parse(fechaACTUAL);
        Space4date.innerHTML="";
        Space4date.append(h1);
        renderPeliculas();
    }

}

async function renderPeliculas(){
    const request = new Request(cPeliculas, {method: 'GET', headers: { }});
    await (async ()=>{
        const response = await fetch(request);
        if (!response.ok) {errorMessage(response.status);return;}
        Peliculasstate.list = await response.json();
        render_listPeliculas();
    })();
}
function render_listPeliculas(){
    var listado=document.getElementById("containerPeliculas");
    listado.innerHTML="";
    Peliculasstate.list.forEach( item=>render_list_itemPeliculas(listado,item));

}

async function render_list_itemPeliculas(listado,item) {
    var tr = document.createElement("tr");
    tr.innerHTML = `
    <td id="imagePLUZtrailer" class="imagePLUZtrailer">
        <img src="/images/img.png">
        <input id="trailer" type="button" value="trailer">
    </td>
    <td id="innereachPelicula" class="innereachPelicula">
        
        <div id="infopeli" class="infopeli">
            <div style="background-color: lightblue; padding: 10px;">${item.nombre}</div>
            <div style="background-color: lightgreen; padding: 10px;">${item.padulto}</div>
            <div style="background-color: lightcoral; padding: 10px;">${item.genero}</div>
            <div style="background-color: lightsalmon; padding: 10px;">${item.categoria}</div>
        </div>
        <div id="lineDOS"></div>
        <div id="pelitandas" class="pelitandas">
            <div>${item.lenguaje}</div>
            
        </div>
    </td>
    `;

    var tandasDIV= tr.querySelector("#pelitandas");
    await peticion_Tandas(tandasDIV,item);



    tr.className  = "eachPelicula";
    listado.append(tr);
}
async function peticion_Tandas(tandasDIV,item){
    var fechaACTUAL=sessionStorage.getItem("fecha");
    fechaACTUAL=JSON.parse(fechaACTUAL);
    const request = new Request("http://localhost:8080/tandas/"+`findBYnombrePeli/${item.nombre}`,
        {method: 'POST',
            headers: { 'Content-Type': 'application/json'},
            body: JSON.stringify(fechaACTUAL)});

    await (async ()=>{
        const response = await fetch(request);
        if (!response.ok) {errorMessage(response.status);return;}

        Peliculasstate.listTandas=await response.json();

        await Peliculasstate.listTandas.forEach( item=>renderTandas(tandasDIV,item));

    })();
}
function renderTandas(tandasDIV,item){
    var bruno =document.createElement("br");
    tandasDIV.append(bruno);

    var div = document.createElement("div");
    div.textContent=item.fecha;
    tandasDIV.append(div);

    var br =document.createElement("br");
    tandasDIV.append(br);
    var ghostDIV=document.createElement("div");

    var inputhora = document.createElement("input");
    inputhora.type = "button";
    inputhora.value = item.hora;
    inputhora.className  = "reservar";
    inputhora.id="reservar";
    ghostDIV.append(inputhora);

    tandasDIV.append(ghostDIV);
    ghostDIV.querySelector("#reservar").addEventListener("click",()=>{reservar(item)});
}
function reservar(item){
    sessionStorage.setItem("tandaAcomprar",JSON.stringify(item));
    goTiquetes();
}
// async function filtrarXfecha(){
//     var fechaACTUAL=sessionStorage.getItem("fecha");
//     fechaACTUAL=JSON.parse(fechaACTUAL);
//     if(fechaACTUAL!="") {
//         const request = new Request("http://localhost:8080/tandas", {method: 'GET', headers: {}});
//         await (async () => {
//             const response = await fetch(request);
//             if (!response.ok) {
//                 errorMessage(response.status);
//                 return;
//             }
//             var aux = new Array();
//             aux = await response.json();
//             aux.forEach(function (element) {
//                 if(element.fecha!=(fechaACTUAL)){
//                     var elementDOS;
//                     for (var i = 0; i < Peliculasstate.list.length; i++) {
//                         elementDOS=Peliculasstate.list[i];
//                         if(elementDOS.id==(element.peliculaTanda.id)){
//                             Peliculasstate.list.splice(i, 1);
//                             break;
//                         }
//                     }
//
//                 }
//             });
//
//         })();
//     }
// }


function errorMessage(status,place){
    switch(status){
        case 404: error= "Registro no encontrado"; break;
        case 409: error="Registro duplicado"; break;
        case 401: error="Usuario no autorizado"; break;
        case 403: error="Usuario no tiene derechos"; break;
    }
    window.alert(error);
}