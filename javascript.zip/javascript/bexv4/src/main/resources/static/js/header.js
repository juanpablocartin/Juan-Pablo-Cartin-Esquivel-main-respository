async function mainrender(){
    try{
        await renderheader();
        //await renderfoot();
    } catch(error){
        return;
    }

}

function renderheader(){
        html = `
            <div class="logo">
            <img src="/images/img.png">
            </div>
            <div class="centermenu">
                <ul class="Menu">
                    <li id="Cartelera">
                        <a href="#"> Cartelera</a>
                    </li>
                    <li id="Tiquetes">
                        <a href="#"> Tiquetes</a>
                    </li>
                </ul>
            </div>
        `;
        document.querySelector('#menu').innerHTML = html;
        document.querySelector("#menu #Cartelera").addEventListener('click', goCartelera);
        document.querySelector("#menu #Tiquetes").addEventListener('click', goTiquetes);

}
function renderfoot(){
    html=`
         <footer>
            Bruno.Diaz.Batman@una.ac.cr
        </footer>
        `;
    document.getElementById('footer').innerHTML = html;
}
function goCartelera(){
    document.location="/pages/cartelera/cartelera.html";
}
function goTiquetes(){
    document.location="/pages/tiquetes/tiquetes.html";
}