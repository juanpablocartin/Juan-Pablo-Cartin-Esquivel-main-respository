package org.example.bexv4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bexv4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
