var backend="http://localhost:8080";

var state ={
    listacategroias:new Array(),
    listaplatillos:new Array(),
    Categoria:{id:"", nombre: ""},
    Platillo:{categoria:null,id:"",nombre:"",descripcion:"",precio:0},
    PlatillosCompra:{categoria:null,id:"",nombre:"",descripcion:"",precio:0,cantidad:0, tamano:""},
    listaPlatillosCompra:new Array(),
    SUM:0
}




document.addEventListener("DOMContentLoaded",start);
async function start(){
    try{ await mainrender();} catch(error){return;}
    render_fullgrayR();
    render_formsM();
    render_cate();
    addEVENTcompra();

}
async function addEVENTcompra(){

    document.querySelector("#COMPRAR").addEventListener("click", function() {
        sendCompra();
    });
}
async function sendCompra(){
    const request = new Request("http://localhost:8080/platillo/send", {
        method: 'POST',
        headers: { 'Content-Type': 'application/json'},
        body: JSON.stringify(state.listaPlatillosCompra)});

    await (async ()=>{
        const response = await fetch(request);
        if (!response.ok) {errorMessage(response.status);return;}

        console.log("Se mando la compara ");

    })();
    sessionStorage.clear();
    var listado=document.getElementById("preciototal");
    listado.innerHTML="";
    listado=document.getElementById("Ordenadding");
    listado.innerHTML="";
    state.listaPlatillosCompra=new Array();
}



async function render_cate(){
    const request = new Request(backend+"/categoria", {method: 'GET', headers: { }});
    await (async ()=>{
        const response = await fetch(request);
        if (!response.ok) {errorMessage(response.status);return;}

        state.listacategroias=await response.json();

        render_cate_dos();
    })();
}

 function render_cate_dos(){
    var listado=document.getElementById("Categoriaadding");
    listado.innerHTML="";
    state.listacategroias.forEach( item=>render_cate_tres(listado,item));

}

function render_cate_tres(listado,item){
    var div = document.createElement("div");
    div.innerHTML = `
            <a id="onecategoria">${item.nombre}</a>   
     `;


    div.className  = "eachCategoria";
    listado.append(div);

    div.querySelector("#onecategoria").addEventListener("click", function() {
        render_MENU(item);
    });
}
async function render_MENU(item){

    const request = new Request(backend+"/platillo/find/"+`${item.id}`, {method: 'GET', headers: { }});
    await (async ()=>{
        const response = await fetch(request);
        if (!response.ok) {errorMessage(response.status);return;}
        state.listaplatillos = await response.json();
        render_MENU_dos(item);
    })();

}
function render_MENU_dos(catego){
    var listado=document.getElementById("Menuadding");
    listado.innerHTML="";
    var h3 = document.createElement("h3");
    h3.textContent=catego.nombre;
    listado.append(h3);
    state.listaplatillos.forEach( item=>render_MENU_tres(listado,item,catego));
}
async function render_MENU_tres(listado,item){
    var div = document.createElement("div");
    div.innerHTML = `
            <div id="eimblock" class="eimblock"> 
                ${item.nombre}
                ${item.descripcion}
            </div> 
            <div>
                ${item.precio}
            </div>
            <div>
                <input id="test" class="boton" type="button" value="+">
            </div>
     `;
    div.className  = "eachITEMdeMENU";
    listado.append(div);
    div.querySelector("#test").addEventListener("click", function() {
        popup(item);
    });
}

function render_fullgrayR() {
    html = `
        <div id="fullgray" class="fullgray"></div>
    `;
    overlay=document.createElement('div');
    overlay.innerHTML=html;
    document.body.appendChild(overlay);
    document.querySelector("#fullgray").addEventListener("click",toggle_meetingM);
}
async function render_formsM() {
    //---------------------------------------------------------------
    html = `

    <div id="newplate" class='newplate'>
        <div id="fromsPLUZcontacts" class="fromsPLUZcontacts">
                            <div id='Title' class='Title'> ggg</div>
                        <div class="leftALI">
                            <div class='row'>
                                <label for="descripcion">Descripcion</label>
                                <p name="descripcion" id="descripcion"> vaff</p>
                            </div>
                            <div class='row'>
                                <label for="tamano">Tamaño </label>
                                        <label>Grande</label>
                                        <input name="tamano"  type="radio" id="granRadio"  value="g" > 
<!--                                        hojo aqui va un 20 % mas-->
                                        <label>Pequeño</label>
                                        <input name="tamano" type="radio" id="pequeRadio" value="p" checked >
                            </div>
                            <div class='row'>
                                
                                    <label for="Cantidad">Cantidad</label>
                                         <select id="Cantidad" name="Cantidad">
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                         </select>
                                    
                            </div>
                    
                        </div>
                        <div class='row'>
                            <div >
                                <input id="addTOcompra" class="boton" type="button" value="Agregar">
                                &nbsp
                                <input id="cancelar" class="boton" type="button" value="Cancelar">
                            </div>
                        </div>
        </div>

    </div> 

    `;
    //---------------------------------------------------------------

    view = document.createElement('div');
    view.innerHTML = html;
    document.body.appendChild(view);


    document.querySelector("#newplate #cancelar").addEventListener("click",toggle_meetingM);

    document.querySelector("#newplate #addTOcompra").addEventListener("click", function() {
        addTOcompra(state.Platillo);
    });
}
function addTOcompra(item) {
    toggle_meetingM();

    var can = parseInt(document.querySelector("#Cantidad").value, 10);

    var precio = parseInt(item.precio, 10);

    var tamanoValue = document.querySelector('input[name="tamano"]:checked').value;
    var tama="NONE";
    if(tamanoValue === "g") {
        tama="Grande";
    }
    else{
        tama="Pequeño";
    }


    var listado = document.getElementById("Ordenadding");
    var div = document.createElement("div");
    div.innerHTML = `
        <p>Si el platillo es grande se le agregará un 20% adicional al precio establecido.</p>

        <div id="oneeachOrder"> 
            ${can}X 
            <br>
            ${item.nombre}
            <br>
            ${tama} 
        </div> 
        <div id="twoeachOrder">
            ${precio}
            
        </div>
    `;
    div.className = "eachOrder";
    listado.append(div);

    // Assuming state.SUM is already initialized elsewhere
    if(tamanoValue === "g"){
        state.SUM = state.SUM +( (precio * can) *1.20);
    }
    else{
        state.SUM = state.SUM + (precio * can);
    }

    document.querySelector('#preciototal').textContent=state.SUM;

    state.PlatillosCompra.cantidad=can;
    state.PlatillosCompra.tamano=tama;

    state.PlatillosCompra.precio=item.precio;
    state.PlatillosCompra.nombre=item.nombre;
    state.PlatillosCompra.descripcion=item.descripcion;
    state.PlatillosCompra.categoria=item.categoria;
    state.PlatillosCompra.id=item.id;

    state.listaPlatillosCompra.push(state.PlatillosCompra);
    cleanPlatillo();
}
function popup(item){
    event.preventDefault();
    toggle_meetingM();
    document.querySelectorAll('#newplate input').forEach( (i)=> {i.classList.remove("invalid");});

    document.querySelector("#Title").textContent = item.nombre;
    document.querySelector("#newplate #descripcion").textContent = item.descripcion;


    state.Platillo.id=item.id;
    state.Platillo.nombre=item.nombre;
    state.Platillo.descripcion=item.descripcion;
    state.Platillo.precio=item.precio;
    state.Platillo.categoria=item.categoria;
}
function toggle_meetingM(){
    document.getElementById("fullgray").classList.toggle("active");
    document.getElementById("newplate").classList.toggle("active");
}
function errorMessage(status,place){
    switch(status){
        case 404: error= "Registro no encontrado"; break;
        case 409: error="Registro duplicado"; break;
        case 401: error="Usuario no autorizado"; break;
        case 403: error="Usuario no tiene derechos"; break;
    }
    window.alert(error);
}

function cleanPlatillo(){
    state.Platillo.categoria=null;
    state.Platillo.id="";
    state.Platillo.nombre="";
    state.Platillo.descripcion="";
    state.Platillo.precio=0;
}