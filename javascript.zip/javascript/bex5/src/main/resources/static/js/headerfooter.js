

async function mainrender(){

    try{
        await renderheader();
    } catch(error){
        return;
    }

}

function renderheader(){
        html = `
            <div class="logo">
            <img src="/img/logo.png"">
                <h2>El Restaurante</h2>
            </div>
        `;
        document.querySelector('#header').innerHTML = html;

}
