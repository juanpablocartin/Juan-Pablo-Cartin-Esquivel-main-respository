package org.example.bex5.data;

import org.example.bex5.logic.Categoria;
import org.example.bex5.logic.Platillo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;

@Component("platilloRepository")
public class PlatilloRepository {
    List<Platillo> list;

    public Platillo findById(String id) throws Exception{
        Platillo r = list.stream()
                .filter( e-> e.getId().equals(id))
                .findFirst().get();
        return r.clone();
    }

    public List<Platillo> findAll(){
        return list.stream()
                .map(Platillo::clone)
                .toList();
    }

    public List<Platillo> findByCategoria(String id){
        return list.stream()
                .filter( e->e.getCategoria().getId().equals(id))
                .map(Platillo::clone)
                .toList();
    }

    CategoriaRepository categoriaRepository;
    @Autowired
    public PlatilloRepository(CategoriaRepository categoriaRepository) {
        this.categoriaRepository = categoriaRepository;

        list = new ArrayList<Platillo>();
        try {
            Categoria entradas = categoriaRepository.findById("111");
            list.add(new Platillo(entradas, "111", "Ensalada Capresse","Tomate, mozzarella y hojas de albahaca fresca", 5000));
            list.add(new Platillo(entradas,"222", "Crema Espinaca", "Crema a base caldo de pollo, leche, queso parmesano y abundante espinaca", 4000));
            list.add(new Platillo(entradas,"333", "Patacones", "Plátanos verdes fritos y majados, con guacamole dip a elección", 3500));
            list.add(new Platillo(entradas,"444", "Papas al Romero", "Papas horneadas con una mezcla de romero fresco orgánico y sal himalaya", 3000));

            Categoria carnes = categoriaRepository.findById("222");
            list.add(new Platillo(carnes, "555", "Lomito a la Parrilla", "Lomito prime con papas baby, chipotle y cebolla chalota", 15000));
            list.add(new Platillo(carnes, "666", "Picaña", "Picaña al horno con papas y pimientos", 17000));
            list.add(new Platillo(carnes,"777", "Fajitas de Pollo", "Tiras de pollo a la parrilla mezcladas con verduras y tortillas", 14000));
            list.add(new Platillo(carnes,"888", "Filete de Pescado", "Filete empanizado, con guarnición de arroz y ensalada", 16500));


            Categoria Sopas = categoriaRepository.findById("333");
            list.add(new Platillo(Sopas, "111", "Sopa 1","Sopa 1", 5000));
            list.add(new Platillo(Sopas,"222", "Sopa 2", "Sopa 2", 4000));
            list.add(new Platillo(Sopas,"333", "Sopa 3", "Sopa 3", 3500));
            list.add(new Platillo(Sopas,"444", "Sopa 4", "Sopa 4", 3000));

            Categoria Arroces = categoriaRepository.findById("444");
            list.add(new Platillo(Arroces, "555", "Arroce 1", " Arroce 1", 15000));
            list.add(new Platillo(Arroces, "666", "Arroce 2", "Arroce 2 ", 17000));
            list.add(new Platillo(Arroces,"777", "Arroce 3 ", " Arroce 3", 14000));
            list.add(new Platillo(Arroces,"888", "Arroce 4", " Arroce 4", 16500));

        } catch (Exception ex) {}
    }
}


