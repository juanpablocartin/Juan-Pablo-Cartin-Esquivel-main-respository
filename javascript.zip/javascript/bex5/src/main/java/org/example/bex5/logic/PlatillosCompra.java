package org.example.bex5.logic;

public class PlatillosCompra {
    private Categoria categoria;
    private String id;
    private String nombre;
    private String descripcion;
    private int precio;
    private int cantidad;
    private String tamano;
    public PlatillosCompra(Categoria categoria, String id, String nombre, String descripcion, int precio, int cantidad, String tamano) {
        this.categoria = categoria;
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.cantidad = cantidad;
        this.tamano = tamano;
    }

    // Getters
    public Categoria getCategoria() {
        return categoria;
    }

    public String getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public int getPrecio() {
        return precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public String getTamano() {
        return tamano;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public void setTamano(String tamano) {
        this.tamano = tamano;
    }

    @Override
    public String toString() {
        return this.cantidad+" X "+this.nombre+" - "+ this.tamano;
    }
}
