package org.example.bex5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bex5Application {

	public static void main(String[] args) {
		SpringApplication.run(Bex5Application.class, args);
	}

}
