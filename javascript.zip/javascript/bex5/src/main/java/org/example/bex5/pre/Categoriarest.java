package org.example.bex5.pre;

import org.example.bex5.data.CategoriaRepository;
import org.example.bex5.logic.Categoria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/categoria")
public class Categoriarest {
    @Autowired
    CategoriaRepository categoriaRepository;

    @GetMapping
    public List<Categoria> read() {
        return categoriaRepository.findAll();
    }

}
