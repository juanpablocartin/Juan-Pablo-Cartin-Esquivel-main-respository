package org.example.bex5.pre;

import org.example.bex5.data.PlatilloRepository;
import org.example.bex5.logic.Platillo;
import org.example.bex5.logic.PlatillosCompra;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/platillo")
public class Platillorest  {
    private int id=0;


    @Autowired
    PlatilloRepository platilloRepository;

    @GetMapping("/find/{id}")
    public List<Platillo> read(@PathVariable String id) {

                return platilloRepository.findByCategoria(id);

    }
    @PostMapping("/send")
    public void read(@RequestBody  List<PlatillosCompra> list) {
        id=id+1;
        System.out.printf("ID: ");
        for (PlatillosCompra platillo : list) {
            System.out.printf(String.valueOf(id));
            System.out.println('\n');
            System.out.printf(platillo.toString());
            System.out.println('\n');
        }


    }
}
