package org.example.bexv2.pre;


import org.example.bexv2.data.ContactRepository;
import org.example.bexv2.data.MeetingRepository;
import org.example.bexv2.data.UserRepo;
import org.example.bexv2.logic.Contact;
import org.example.bexv2.logic.Meeting;
import org.example.bexv2.logic.User;
import org.example.bexv2.sec.UserDimp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/contacts")
public class Contacts {
    @Autowired
    ContactRepository contactRepository;
    @Autowired
    UserRepo userRepo;

    @PostMapping("/find/bymeeting")
    public List<Contact> readbymeeting(@RequestBody Meeting metting) {

        try {
            return contactRepository.findByMeeting(metting);
        } catch (Exception ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }

    }

    @GetMapping("/find/byUser")
    public List<Contact> readbyuser(@AuthenticationPrincipal UserDimp user) {

        try {
            return contactRepository.findByUser(user.getUser());
        } catch (Exception ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }

    }
}
