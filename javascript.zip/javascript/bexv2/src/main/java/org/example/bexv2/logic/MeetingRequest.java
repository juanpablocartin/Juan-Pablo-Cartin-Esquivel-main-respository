package org.example.bexv2.logic;


import java.util.ArrayList;

public class MeetingRequest {
    private Meeting meeting;
    private ArrayList<Contact> contacts;

    public ArrayList<Contact> getContacts() {
        return contacts;
    }

    public void setContacts(ArrayList<Contact> contacts) {
        this.contacts = contacts;
    }

    public Meeting getMeeting() {
        return meeting;
    }

    public void setMeeting(Meeting meeting) {
        this.meeting = meeting;
    }

    public void setMeetingForAll() {
        for (Contact c : this.contacts) {
            c.setMeeting(this.meeting);
        }
    }
}
