package org.example.bexv2.pre;


import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import org.example.bexv2.logic.User;
import org.example.bexv2.sec.UserDimp;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;


import org.springframework.web.bind.annotation.GetMapping;

@RestController
@RequestMapping("/login")
public class Login {

    @PostMapping("/login")
    public User login(@RequestBody User form, HttpServletRequest request) {
        try {
            request.login(form.getid(), form.getPasw());
        } catch (ServletException e) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED);
        }
        Authentication auth = (Authentication) request.getUserPrincipal();
        User user = ((UserDimp) auth.getPrincipal()).getUser();
        return new User(user.getid(), null, user.getTipo(),user.getMail());
    }

    @PostMapping("/logout")
    public void logout(HttpServletRequest request) {
        try {
            request.logout();
        } catch (ServletException e) {
        }
    }

    @GetMapping("/current-user")
    public User getCurrentUser(@AuthenticationPrincipal UserDimp user) {
        if (user == null) {
            throw new UserNotAuthenticatedException("User is not authenticated");
        }

            return new User(user.getUser().getid(), null, user.getUser().getTipo(),user.getEmail());
    }
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public class UserNotAuthenticatedException extends RuntimeException {
        public UserNotAuthenticatedException(String message) {
            super(message);
        }
    }
}
