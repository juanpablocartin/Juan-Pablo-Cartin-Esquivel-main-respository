package org.example.bexv2.logic;

public class User {
    private String id;
    private String pasw;
    private String tipo;

    private String mail;
    public User(String id,String pasw,String tipo,String mail) {
        this.id = id;
        this.pasw = pasw;
        this.tipo = tipo;
        this.mail = mail;
    }

    public User() {
        this.id = "";
        this.pasw = "";
        this.tipo = "";
        this.mail = "";
    }

    public String getid() {
        return id;
    }

    public void setid(String id) {
        this.id = id;
    }

    public String getPasw() {
        return pasw;
    }

    public void setPasw(String pasw) {
        this.pasw = pasw;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }


    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public User clone(){
        return new User(id,pasw,tipo,mail);
    }
}
