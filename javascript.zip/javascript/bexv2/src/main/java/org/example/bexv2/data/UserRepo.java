package org.example.bexv2.data;

import org.example.bexv2.logic.User;
import org.springframework.stereotype.Component;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.ArrayList;
import java.util.List;

@Component("userRepo")
public class UserRepo {
    List<User> list;

    public User findById(String id) throws Exception{
        User r = list.stream()
                .filter( e-> e.getid().equals(id))
                .findFirst().get();
        return r.clone();
    }

    public UserRepo() {
        list = new ArrayList<User>();
        var encoder = new BCryptPasswordEncoder();
        list.add(new User("juan","{bcrypt}"+encoder.encode("1"),"A","juan@gmail.com"));
        list.add(new User("pablo","{bcrypt}"+encoder.encode("1"),"A","pablo@gmail.com"));
    }
}