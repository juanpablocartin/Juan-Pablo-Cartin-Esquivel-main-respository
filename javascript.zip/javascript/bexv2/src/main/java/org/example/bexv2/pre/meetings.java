package org.example.bexv2.pre;

import org.example.bexv2.data.ContactRepository;
import org.example.bexv2.data.MeetingRepository;
import org.example.bexv2.data.UserRepo;
import org.example.bexv2.logic.Contact;
import org.example.bexv2.logic.Meeting;
import org.example.bexv2.logic.MeetingRequest;
import org.example.bexv2.logic.User;
import org.example.bexv2.sec.UserDimp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.parameters.P;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/meeting")
public class meetings {

    @Autowired
    MeetingRepository meetings;
    @Autowired
    ContactRepository contactRepository;
    @Autowired
    UserRepo userRepo;


    @GetMapping
    public List<Meeting> read() {
        return meetings.findAll();
    }

    @GetMapping("/find/{id}")
    public List<Meeting> read(@PathVariable String id) {
        User u=null;
        try {
            u=userRepo.findById(id);
        } catch (Exception ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }

        if(u!=null) {
            try {
                return meetings.findByUser(u);
            } catch (Exception ex) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND);
            }
        }
        return null;
    }
    @PostMapping("/add")
    public void addMeeting(@AuthenticationPrincipal UserDimp userDimp,@RequestBody MeetingRequest meetingMeetingRequest){
        try {
            meetingMeetingRequest.getMeeting().setOwner(userDimp.getUser());

            Meeting aux=meetings.save(meetingMeetingRequest.getMeeting());
            meetingMeetingRequest.setMeeting(aux);

            meetingMeetingRequest.setMeetingForAll();

            for (Contact c:meetingMeetingRequest.getContacts()){
                contactRepository.save(c);
            }



        } catch (Exception ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }


    }

}
