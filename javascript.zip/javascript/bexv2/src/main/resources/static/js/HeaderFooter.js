

async function mainrender(){
    await checkuser();
    if (!loginstate.logged
        && document.location.pathname != "/pages/welcome/view.html") {
        document.location = "/pages/welcome/view.html";
        throw new Error("Usuario no autorizado");
    }
    try{
        await renderheader();
        await renderfoot();
    } catch(error){
        return;
    }

}

function renderheader(){
    if (!loginstate.logged){
        html = `
            <div class="logo">
            <img src="/img/img.png"">
                <h2>μάτι</h2>
            </div>
            <div>
                <ul class="Menu">
                    <li id="loginlink"><a href="#"> Login</a></li>
                    <li>
                        <a href="#">List</a>
                        <ul>
                            <li><a href="#">A</a></li>
                            <li><a href="#">B</a></li>
                            <li><a href="#">C</a></li>
                            <li><a href="#">D</a></li>
                            <li><a href="#">E</a></li>
                            <li><a href="#">F</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        `;
        document.querySelector('#menu').innerHTML = html;
        document.querySelector("#menu #loginlink").addEventListener('click', popuplogin);

        render_fullgray();
        render_forms();
    }
    else{
        html = `
            <div class="logo">
                <img src="/img/img.png"">
                <h2>μάτι</h2>
            </div>
            <div>
                <ul class="Menu">
                    <li id="A"><a href="#"> A</a></li>
                    <li id="B"><a href="#"> B</a></li>
                    <li id="logoutlink"><a href="#"> Logout</a></li>
                </ul>
            </div>
            <div class="user">&nbsp &nbsp ${loginstate.user.id}</div>
        `;
        document.querySelector('#menu').innerHTML = html;
        document.querySelector("#menu #logoutlink").addEventListener('click', logout);
        document.querySelector("#menu #A").addEventListener('click', e => {
            document.location = "/pages/A/view.html";
        });
        document.querySelector("#menu #B").addEventListener('click', e => {
            document.location = "/pages/B/view.html";
        });
    }
}
function renderfoot(){
    html=`
         <footer>
            Meetings 
        </footer>
        `;
    document.getElementById('footer').innerHTML = html;
}

