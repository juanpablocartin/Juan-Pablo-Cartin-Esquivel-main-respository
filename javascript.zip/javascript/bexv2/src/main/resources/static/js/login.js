var backend="http://localhost:8080";
var clogin=backend+'/login';

var loginstate ={
    logged: false,
    user : {id:"", tipo:"",mail:""},
    listmeeting:new Array(),
    Meeting: {id:"", owner:null ,title:"",date:"",status:""},
    listcontacts:new Array(),
    Contact:{meeting:null,id:"",email:"", name:""},
    ADDEDcontacts:new Array()
}

function login(){
    let User={id:document.getElementById("id").value,
        pasw:document.getElementById("pasw").value,
        tipo:"A"
    };

    let request = new Request(clogin+'/login', {method: 'POST',
        headers: { 'Content-Type': 'application/json'},
        body: JSON.stringify(User)});


    (async ()=>{
        const response = await fetch(request);
        if (!response.ok) {errorMessage(response.status);return;}
        await checkuser();
        if(loginstate.logged){
            if(loginstate.user.tipo=="A"){
                document.location="/pages/A/view.html";
            }
            else if (loginstate.user.tipo=="B"){
                document.location="/pages/B/view.html";
            }
            else if(loginstate.user.tipo=="C"){
                await logout();
                errorMessage(401);
            }

        }
    })();

}

function logout(event){
    if(event!=null) {
        event.preventDefault();
    }

    let request = new Request(clogin+'/logout', {method: 'POST'});
    (async ()=>{
        const response = await fetch(request);
        if (!response.ok) {errorMessage(response.status);return;}
        sessionStorage.clear();
        loginstate.logged=false;
        document.location="/pages/welcome/view.html";
    })();
}
async function checkuser(){
    let request = new Request(clogin+'/current-user', {method: 'GET'}); //llama al metodo del current-user del login que es un RestController
    const response = await fetch(request);
    if (response.ok) {
        loginstate.logged = true;
        loginstate.user = await response.json();
    }
    else {
        loginstate.logged = false;
    }
}
function render_fullgray() {
    html = `
        <div id="fullgray" class="fullgray"></div>
    `;
    overlay=document.createElement('div');
    overlay.innerHTML=html; //modifica el html del div creado en el dom
    document.body.appendChild(overlay);//lo mete en el dom
    document.querySelector("#fullgray").addEventListener("click",toggle_loginview);
}

function render_forms() { //aqui creamos el html necesario para el login

    htmlDOS = `
    <div id="loginview" class='loginview'>
    <div class="row">
        <div class="Title">Login</div>
    </div>
    <div class='row'>
        <label for="id">Username</label>
            <input type="text" name="id" id="id" value="">
    </div>
    <div class='row'>
        <label for="pasw">Password</label>
            <input type="password" name="pasw" id="pasw" value="">
    </div>
    <div class='row'>
        &nbsp
        <input id="login" class="boton" type="button" value="Login">
        &nbsp
        <input id="cancelar" class="boton" type="button" value="Cancelar">
    </div>
    </div> 
    `;
    view=document.createElement('div');
    view.innerHTML=htmlDOS;
    document.body.appendChild(view);
    document.querySelector("#loginview #login").addEventListener("click",login);
    document.querySelector("#loginview #cancelar").addEventListener("click",toggle_loginview);
}
function popuplogin(event){
    event.preventDefault(); //no actualiza por defecto la pagina
    toggle_loginview();//para que se vea por primera ves
    document.querySelectorAll('#loginview input').forEach( (i)=> {i.classList.remove("invalid");}); //a cada elemento de la clase loginview y sea un input lo invalida
    document.querySelector("#loginview #id").value = ""; //limpia valores para el login
    document.querySelector("#loginview #pasw").value = "";//limpia valores para el login
}
function toggle_loginview(){
    document.getElementById("fullgray").classList.toggle("active");
    document.getElementById("loginview").classList.toggle("active");
}
function errorMessage(status,place){
    switch(status){
        case 404: error= "Registro no encontrado"; break;
        case 409: error="Registro duplicado"; break;
        case 401: error="Usuario no autorizado"; break;
        case 403: error="Usuario no tiene derechos"; break;
    }
    window.alert(error);
}