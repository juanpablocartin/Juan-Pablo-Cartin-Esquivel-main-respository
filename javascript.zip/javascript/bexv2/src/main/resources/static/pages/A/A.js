document.addEventListener("DOMContentLoaded",LoginMAINRENDER);
async function LoginMAINRENDER(event) {
    try{ await mainrender();} catch(error){return;}

    render_fullgrayM();
    render_formsM();
    addpopupevent();
    render_Details();
    render_table();
}
function addpopupevent(){
    document.querySelector("table #add").addEventListener("click",eventADD);
}
function render_Details(){
    html = `
    <div id="meetingD" class='meetingD'>
                        <div class='row'>
                            <div class='Title'>Meeting Details</div>
                        </div>
                        <div class="leftALI">
                            <div class='row'>
                                <label for="title">Title</label>
                                <input distype="text" name="title" id="title" value="" disabled>
                            </div>
                            <div class='row'>
                                <label for="state">State</label>
                                     <input type="text" name="state" id="state" value="" disabled>
                            </div>
                            <div class='row'>
                                <label for="date">Date</label>
                                <input type="text" name="date" id="date" value="" disabled>
                            </div>
                    
                            <div class='row' id="addALLcontacts">
                                <label>Contactos</label>
                            </div>
                        </div>
                       
    </div>   
    `;

    var div = document.createElement("div");
    div.innerHTML=html;


    document.body.querySelector("#detallesdiv").appendChild(div);


}


async function render_table(){

    const request = new Request("http://localhost:8080/meeting/find/"+`${loginstate.user.id}`, {method: 'GET', headers: { }});
    await (async ()=>{
        const response = await fetch(request);
        if (!response.ok) {errorMessage(response.status);return;}
        loginstate.listmeeting = await response.json();
        rendermeetingOFuser();
    })();
}

function rendermeetingOFuser(){
    var listado=document.getElementById("containermetting");
    listado.innerHTML="";
    loginstate.listmeeting.forEach( item=>renderONEmetting(listado,item));
}
function renderONEmetting(listado,item){
    var tr = document.createElement("tr");
    tr.innerHTML = `
    <td>
        <div>${item.title}</div>
    </td>
    <td>
        <div>${item.status}</div>
    </td>
    <td>
        <div>${item.date}</div>
    </td>
    `;
    tr.addEventListener("click", function() {
        render_Details_fromAmeeting(item);
    });

    tr.className  = "eachmeeting";
    listado.append(tr);

}
async function render_Details_fromAmeeting(item){
    document.body.querySelector("#detallesdiv #title").value=item.title;
    document.body.querySelector("#detallesdiv #date").value=item.date;
    document.body.querySelector("#detallesdiv #state").value=item.status;
    var contactsDIV=document.body.querySelector("#detallesdiv #meetingD #addALLcontacts");
    await render_my_contacts(contactsDIV,item);
}
async function render_my_contacts(contactsDIV,item){

    const request = new Request("http://localhost:8080/contacts/find/"+"bymeeting", {
        method: 'POST',
        headers: { 'Content-Type': 'application/json'},
        body: JSON.stringify(item)});

    await (async ()=>{
        const response = await fetch(request);
        if (!response.ok) {errorMessage(response.status);return;}

        loginstate.listcontacts=await response.json();
            contactsDIV.innerHTML=``;
            await loginstate.listcontacts.forEach( item=>renderONEcontact(contactsDIV,item));

    })();
}
function renderONEcontact(contactsDIV,item){
    html=`
            <div>
                ${item.email}
            </div>
    `;
    var div = document.createElement("div");
    div.innerHTML=html;
    div.className  = "eachcontact";
    contactsDIV.append(div);
}
function eventADD(event){
    event.preventDefault(); //no actualiza por defecto la pagina
    toggle_meetingM();//para que se vea por primera ves
    document.querySelectorAll('#newmeet input').forEach( (i)=> {i.classList.remove("invalid");}); //a cada elemento de la clase loginview y sea un input lo invalida
    document.querySelector("#newmeet #title").value = ""; //limpia valores para el login
    document.querySelector("#newmeet #date").value = "";//limpia valores para el login

}

function render_fullgrayM() {
    html = `
        <div id="fullgray" class="fullgray"></div>
    `;
    overlay=document.createElement('div');
    overlay.innerHTML=html; //modifica el html del div creado en el dom
    document.body.appendChild(overlay);//lo mete en el dom
    document.querySelector("#fullgray").addEventListener("click",toggle_meetingM);
}

async function render_formsM() {
    //---------------------------------------------------------------
    html = `

    <div id="newmeet" class='newmeet'>
        <div id="fromsPLUZcontacts" class="fromsPLUZcontacts">
                        <div class='row'>
                            <div class='Title'>New Meeting</div>
                        </div>
                        <div class="leftALI">
                            <div class='row'>
                                <label for="title">Title</label>
                                <input type="text" name="title" id="title" value="">
                            </div>
                            <div class='row'>
                                <label for="state">State</label>
                                     <select id="state" name="state">
                                         <option value="Published">Published</option>
                                         <option value="Overdue">Overdue</option>
                                         <option value="Upcoming">Upcoming</option>
                                     </select>
                            </div>
                            <div class='row'>
                                <label for="date">Date</label>
                                <input type="text" name="date" id="date" value="">
                            </div>
                    
                            <div class='row' id="addALLcontacts">
                                <label>Contactos:</label>
                                <div class='row' id="DIVFORaddALLcontacts">
                                    

                                </div>
                               
                            </div>
                        </div>
                        <div class='row'>
                            <div >
                                <input id="addMeeting" class="boton" type="button" value="+Meeting">
                                &nbsp
                                <input id="cancelar" class="boton" type="button" value="Cancelar">
                            </div>
                        </div>
        </div>
        <div>
                <label>Contacts of this new meeting:</label> 
               <div> <br> </div>
                <div id="fromADDEDcontacts" class="fromADDEDcontacts"></div>
        </div>

    </div> 

    `;
    //---------------------------------------------------------------

    view=document.createElement('div');
    view.innerHTML=html;
    document.body.appendChild(view);
    document.querySelector("#newmeet #addMeeting").addEventListener("click",ADDmetting);
    document.querySelector("#newmeet #cancelar").addEventListener("click",toggle_meetingM);
    //ya que ya esta en el body
    var div_my_contacts=document.body.querySelector("#newmeet #DIVFORaddALLcontacts");
    await render_allmy_contacts(div_my_contacts);
}
async function render_allmy_contacts(div_my_contacts){
    const request = new Request("http://localhost:8080/contacts/find/"+"byUser", {method: 'GET', headers: { }});

    await (async ()=>{
        const response = await fetch(request);
        if (!response.ok) {errorMessage(response.status);return;}

        loginstate.listcontacts=await response.json();

        div_my_contacts.innerHTML=``;

        await loginstate.listcontacts.forEach( item=>renderONEcontact_ADDmeeting(div_my_contacts,item));

    })();
}
function renderONEcontact_ADDmeeting(div_my_contacts,item){
    html=`
            <div>
                ${item.email}
                <a href="#" class="smalladd" id="smalladd"><img id="agregueAreu" src="/img/addContact.png"></a>

            </div>
    `;
    var div = document.createElement("div");
    div.innerHTML=html;
    div.className  = "eachcontact";
    div.querySelector("#agregueAreu").addEventListener("click",function() { addtooREUN(item) }    );


    div_my_contacts.append(div);
}

function addtooREUN (item){
    loginstate.ADDEDcontacts.push(item);
    html=`
            <div>
                ${item.email}
                <a href="#" class="smalladd" id="smalladd"><img id="removerAreu" src="/img/remove.png"></a>
            </div>
    `;
    var div = document.createElement("div");
    div.innerHTML=html;
    div.className  = "eachcontact";
    div.querySelector("#removerAreu").addEventListener("click",function() { DELETETOfromADDEDcontacts(item) }    );

    document.body.querySelector("#newmeet #fromADDEDcontacts").appendChild(div);

}

function DELETETOfromADDEDcontacts(item){
    const index = loginstate.ADDEDcontacts.findIndex(contact => contact === item);

    if (index !== -1) {
        loginstate.ADDEDcontacts.splice(index, 1);
    } else {
        console.warn("Item not found in loginstate.ADDEDcontacts");
    }
    refreshContacts();
}
function refreshContacts(){
    var div_myPRESENT_contacts=document.getElementById("fromADDEDcontacts");
    div_myPRESENT_contacts.innerHTML=``;
    loginstate.ADDEDcontacts.forEach( item=>addtoPRESENTcontacts(div_myPRESENT_contacts,item));
}
function addtoPRESENTcontacts(div_myPRESENT_contacts,item){
    html=`
            <div>
                ${item.email}
                <a href="#" class="smalladd" id="smalladd"><img id="removerAreu" src="/img/remove.png"></a>
            </div>
    `;
    var div = document.createElement("div");
    div.innerHTML=html;
    div.className  = "eachcontact";
    div.querySelector("#removerAreu").addEventListener("click",function() { DELETETOfromADDEDcontacts(item) }    );
    div_myPRESENT_contacts.appendChild(div);
}
function toggle_meetingM(){
    document.getElementById("fromADDEDcontacts").innerHTML=``;

    document.getElementById("fullgray").classList.toggle("active");
    document.getElementById("newmeet").classList.toggle("active");
}
async function ADDmetting(){

    var a=document.body.querySelector("#newmeet #date").value;
    var b=document.body.querySelector("#newmeet #title").value;
    var c=document.body.querySelector("#newmeet #state").value;
    loginstate.Meeting.id=null;
        loginstate.Meeting.owner=null;
            loginstate.Meeting.date=a;
                loginstate.Meeting.title=b;
                    loginstate.Meeting.status=c;
    if(validarVacios()){
        return;
    }

    //-----------------------------------------------Objecto en Logic con lo que nececito-----------------
    const requestBody = {
        meeting: loginstate.Meeting,
        contacts: loginstate.ADDEDcontacts
    };
    const request = new Request("http://localhost:8080/meeting/add", {
        method: 'POST',
        headers: { 'Content-Type': 'application/json'},
        body: JSON.stringify(requestBody)});

    await (async ()=>{
        const response = await fetch(request);
        if (!response.ok) {errorMessage(response.status);return;}
    })();
    limpiar();
    toggle_meetingM();
    render_table();
}
function validarVacios(){
    var error=false;
    document.querySelectorAll('input[type="text"]').forEach( (i)=> {i.classList.remove("invalid");});
    if(loginstate.Meeting.date.length==0){
        error=true;
        document.querySelector("#newmeet #date").classList.add("invalid");
        alert("missing date.");
        console.log("Error en el Forms New Meeting !!!!!");
    }
    if(loginstate.Meeting.title.length==0){
        error=true;
        console.log("Error en el Forms New Meeting !!!!!");
    }
    if(loginstate.Meeting.status.length==0){
        error=true;
        console.log("Error en el Forms New Meeting !!!!!");
    }
    return error;
}

function limpiar(){
    document.body.querySelector("#newmeet #date").value= "";
    document.body.querySelector("#newmeet #title").value= "";
    document.body.querySelector("#newmeet #state").value= "";
    loginstate.ADDEDcontacts=new Array();
}