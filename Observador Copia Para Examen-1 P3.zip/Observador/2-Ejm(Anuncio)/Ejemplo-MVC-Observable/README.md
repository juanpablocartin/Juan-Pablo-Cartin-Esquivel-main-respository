# Ejemplo-MVC-Observable
Ejemplo en Java de patrones de diseño MVC-Observable para que se aprenda, a modo educativo, cómo funciona. 
Incorporamos javadoc con documentación del proyecto. Está todo super comentado. Empleamos SWING para la vista. 
El programa en sí solo incrementa o decrementa un valor, que se muestra en un JLabel, y es modificado por dos botones (sumar, restar).
