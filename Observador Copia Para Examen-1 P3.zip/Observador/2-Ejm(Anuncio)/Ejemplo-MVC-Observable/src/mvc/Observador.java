package mvc;

/**
  Interfaz MiObservador contendrá los metodos 
  para que el observador se actualice según lo que reciba del modelo.
 */
public interface Observador {
    
    /**
      Metodo valorCambiado es el unico metodo de la interfaz pues solo nos interesa 
      * como observadores el valor "valor" para modificar nuestra vista.
      
      @param valor : Notificación del nuevo valor que nos llega del modelo.
      El modelo notificará con este metodo a cada observador, 
     */
    public void update(int valor); // conocido tambien como metodo update()

}
