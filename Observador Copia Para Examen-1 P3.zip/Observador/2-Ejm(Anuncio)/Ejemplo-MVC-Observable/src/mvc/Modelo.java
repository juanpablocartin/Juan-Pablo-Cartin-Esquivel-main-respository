package mvc;

import java.util.ArrayList;


/**
 * Modelo de mi programa, aquí estará toda la lógica y el funcionamiento interno de este.
 * Lo hacemos Observable sobre los observadores del modelo, para que sean notificados con lo que les interese.
 * @author fon
 */
public class Modelo implements Observable<Observador>{
    private ArrayList<Observador> observadores;   
    //Aquí añadiremos la liste de nuestros observadores
    private int valor; 
    
    //-----------------------------------------------------------------------------------------------------
    public Modelo(int x) {
            valor =x;
          observadores = new ArrayList<Observador>();   
    }
    //---------------------------------------------------------------------------------------
        /**
     * addObservador: Añade observadores a nuestro modelo
     * @param t : observador de tipo ModeloObserver
     */
    @Override
    public void addObservador(Observador t) {
        observadores.add(t);    //Añadimos el observador a nuestro arraylist.
        notificarObservadores();// hacemos una actualizacion, mandando el valor para que
        //incluso el nuevo observador tenga el valor
    }
    //-----------------------------------------------------------------------------------------------------D
         // removeObservador: Borra observadores a nuestro modelo
    @Override
    public void removeObservador(Observador t) {
        observadores.remove(t);
    }  

//-----------------------------------------------------------------------------------------
    public void sumar(){

        valor++;
        //Al modificarse el valor, notificamos a los observadores ya que les interesa ese cambio de estado.
        notificarObservadores();
    }
//-----------------------------------------------------------------------------------------
    public void restar(){
        valor--;
        //Al modificarse el valor, notificamos a los observadores ya que les interesa ese cambio de estado.
        notificarObservadores();
    }
    
    //-----------------------------------------------------------------------------------------------------------------------------------
    /**
     * Método que notifica a nuestros observadores los cambios que nos interese que sepan.
     * @param t : estado del valor del numero.
     */
    private void notificarObservadores() {
        for(Observador o : observadores){        //Nos recorremos el arraylist de los observadores
            o.update(valor);
        }
    }
    //-----------------------------------------------------------------------------------------------------------------------------------
    public int getValor() {
        return valor;
    }
    //-----------------------------------------------------------------------------------------------------------------------------------
    public void setValor(int valor) {
        this.valor = valor;
         for(Observador o : observadores){        //Nos recorremos el arraylist de los observadores
            o.update(valor);
        }
    }
    //-----------------------------------------------------------------------------------------------------------------------------------    
    
}
