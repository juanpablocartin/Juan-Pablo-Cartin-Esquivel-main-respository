package mvc;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;

/**
  El Controlador  es llamado por  la vista para controlar a la lógica.
  El controlador contiene un modelo, el cual es la logica de nuestro programa, y se encarga de llamar a este modelo para que realice las acciones necesarias sobre el programa.
  @author fon
 */
public class Controlador implements ActionListener {
    Modelo m; //Nuestra lógica del programa
    VentanaOrigen v;
    
//-------------------------------------------------------------------------------------------------------------------------
    public Controlador(Modelo m,  VentanaOrigen  v){
        this.m = m;
         this.v = v;
         this.v.getBtnRestar().addActionListener(this);
         this.v.getBtnSumar().addActionListener(this);
    }
    //-------------------------------------------------------------------------------
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(  this.v.getBtnRestar())){
           m.restar();
        }
        
         if (e.getSource().equals(  this.v.getBtnSumar())){
           m.sumar();
        }

    }// fin metodo
        //-------------------------------------------------------------------------------
}// fin clase
