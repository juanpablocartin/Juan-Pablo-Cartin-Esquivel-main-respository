/**
 * Ejemplo patrones de diseño MVC y Observer
 * Realizado por Alfonso Soria Muñoz
 * Para el canal de experimentando y aprendiendo.
 */
package mvc;

/**
 * Clase Main, desde aqui cargaremos el modelo, la vista y el controlador, y añadiremos observadores sobre el modelo.
 * @author fon
 */
public class Principal {


    public static void main(String args[]){
                Modelo m = new Modelo(500);
                VentanaOrigen v1 = new VentanaOrigen();
                Controlador c = new Controlador(m, v1);
                VentanaCarro v2 = new VentanaCarro();
                VentanaCasa v3 = new VentanaCasa();
                //añadimos observadores al modelo. En este caso, dos vistas.
                m.addObservador(v1);
                m.addObservador(v2);
                m.addObservador(v3);

                v1.setLocation(10, 100);
                v2.setLocation(500, 0);
                v3.setLocation(500, 350);
                v2.setVisible(true);
                v3.setVisible(true);
                v1.setVisible(true);
    }
}
