
package Control;

import Modelo.TablaDatos;
import Vista.Ventana;


public class ObserverNotificado implements Observer {
    //A este se le notivica porque este TIENE EL PANEL para no ponerlo en la controladora
                private Ventana v;
                private TablaDatos m;
                private int ban=0;

   
   //-----------------------------------------------------------
  
   public  ObserverNotificado (Ventana vAux, TablaDatos mAux){
      v= vAux;
      m= mAux;
   }
   //----------------------------------------------------------------------------------
    public void notifyChange( ) {
            int edadMax= buscarEdadMayor();
            int edadMenor =buscarEdadMenor();
            System.out.println("mayor:  " +edadMax);
            System.out.println("menor: "  + edadMenor);

              if (ban== 0) { // si es la primera vez que se ejecuta 
                        v.getPanel1().edadMenor2.setText(String.valueOf(edadMenor));
                       v.getPanel1().edadMayor2.setText(String.valueOf(edadMax));
                        ban=1 ;  
              }

              else{
                  if (m.getNuevaEdad() == edadMenor   ||   m.getNuevaEdad() == edadMax) {
                         v.getPanel1().edadMayor2.setText(String.valueOf(edadMax));
                         v.getPanel1().edadMenor2.setText(String.valueOf(edadMenor));
                  } // fin else
              }// fin else
    }// fin metodo

//-------------------------------------------------------------------------------------------------------------------
    public int  buscarEdadMenor( ) {
                   int aux;
              String s = String.valueOf(m.getTablaDatos().getValueAt(0, 1));
              int menor= Integer.parseInt(s);

              for (int i = 0; i < m.getTablaDatos().getRowCount(); i++) {
                          s = String.valueOf(m.getTablaDatos().getValueAt(i, 1));
                          aux= Integer.parseInt(s);
                          if (aux < menor)     {
                             menor= aux;
                          }
              }
             return menor;
      }  


    //---------------------------------------------------------------------------------------

   public int  buscarEdadMayor( )  {
                 
      String s = String.valueOf(m.getTablaDatos().getValueAt(0, 1));
      int aux= Integer.parseInt(s);
      int mayor= Integer.parseInt(s);

      for (int i = 1; i < m.getTablaDatos().getRowCount(); i++) {
              s = String.valueOf(m.getTablaDatos().getValueAt(i, 1));
              aux= Integer.parseInt(s);
 
              if (aux > mayor)     {
                mayor= aux;
             }
      }
      return mayor;
   }
    //------------------------------------------------------------------------------------
    

}
