/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Modelo.*;
import Vista.*;


public class Principal {
   public static void main(String args[]){//EL OBJETIVO DE ESTA CLASE ES QUE EL MANEJADOR DE LAS NOTIFICACCIONES Y LA CONTROLADORA TENGA LA MISMA TABLA Y VENTANA 
                TablaDatos elModelo = new TablaDatos();
                Ventana laVentana = new Ventana();// idealmente que la vista no conoce a otras clases
                
                ObserverNotificado ob= new ObserverNotificado(laVentana, elModelo); // observa al modelo, pero necesita a la ventana
                // para informarle lo que pasó
                
                Control c = new Control(laVentana,elModelo);
                elModelo.attach(ob);
                elModelo.notificarObservadores();
    }
    
}
