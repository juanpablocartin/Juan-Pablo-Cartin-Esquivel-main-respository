
package Control;
import Vista.*;
import Modelo.*;
import Modelo.TablaDatos;

public interface Observer {
     void notifyChange( );// recibe la notificacion del modelo

}




