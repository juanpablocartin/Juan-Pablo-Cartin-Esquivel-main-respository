package Control;

import Vista.*;
import Control.*;

import Modelo.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Control implements ActionListener  {
    private TablaDatos elModelo;
    private Ventana laVista;
    //----------------------------------------------------------------------------------------------
    public Control(Ventana v, TablaDatos m) {
            elModelo= m; 
            laVista= v;
            v.setVisible(true);
            v.setTitle("Ingreso de datos");
  
            this.laVista.btnAceptar.addActionListener(this);
            this.laVista.btnBorrar.addActionListener(this);
            v.getjTable1().setModel(m.getTablaDatos());
    }
    
//-----------------------------------------------------------------------------
    @Override
    public void actionPerformed(ActionEvent e) {
         if (e.getSource().equals(laVista.btnAceptar)) {
                     if (laVista.txtNombre.getText().equals ("")  ||  laVista.txtEdad.getText().equals ("") )   {
                         JOptionPane.showMessageDialog(null, "Debes completar todos los campos", "Error", JOptionPane.ERROR_MESSAGE);
                     } 
                    else {  
                         String edad= laVista.txtEdad.getText();
                         String nombre= laVista.txtNombre.getText();
                         String sexo="-";
                                if ( laVista.rdSexo1.isSelected() ){  sexo= (String) laVista.rdSexo1.getActionCommand();  }
                                if ( laVista.rdSexo2.isSelected() ){  sexo= (String) laVista.rdSexo2.getActionCommand();   }
                                if ( laVista.rdSexo3.isSelected() ){  sexo= (String) laVista.rdSexo3.getActionCommand();   }
                         String estado="-";
                                if ( laVista.rbEstado1.isSelected() ){  estado= (String) laVista.rbEstado1.getActionCommand();  }
                                if ( laVista.rbEstado2.isSelected() ){ estado= (String) laVista.rbEstado2.getActionCommand();   }
                                if ( laVista.rbEstado3.isSelected() ){  estado= (String) laVista.rbEstado3.getActionCommand();   }

                          String grado="-";
                     
                                 if ( laVista.ck4.isSelected() ){  grado= (String) laVista.ck4.getActionCommand();  }     // doctorado
                                 else{
                                      if ( laVista.ck3.isSelected() ){       // maestria
                                          grado= (String) laVista.ck3.getActionCommand();   
                                      }
                                      else{
                                             if ( laVista.ck2.isSelected() ){  grado= (String) laVista.ck2.getActionCommand();   }// licenciatura
                                                 else// Bachillerato
                                                 if ( laVista.ck1.isSelected() ){  grado= (String) laVista.ck1.getActionCommand();   
                                            }
                                      }
                                 }
                                 elModelo.insertarRegistro (nombre, edad,  sexo, estado,  grado);
                    }
                  
          }
         
//----------------------------------------------------------------------------------------
       if (e.getSource().equals( laVista.btnBorrar)) {

             if (laVista.getjTable1().getSelectedRow() == -1)    {
                 JOptionPane.showMessageDialog(null, "Debes elegir la fila a eliminar", "Error", JOptionPane.ERROR_MESSAGE);
              }
              else  {
               elModelo.borrarRegistro( laVista.getjTable1().getSelectedRow());
              }
    
       }// fin id

    }// Fin metodo
    
}// Fin clase
