/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Control.Observer;
import Modelo.TablaDatos;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class panelEdad  extends JPanel {
            public  JLabel edadMayor1= new JLabel ("Edad Mayor:");
            public  JLabel edadMayor2= new JLabel (" 0 ");

            public  JLabel edadMenor1= new JLabel ("Edad Menor:");
            public  JLabel edadMenor2= new JLabel (" 0 ");    
    
    //----------------------------------------------------
            public JLabel getEdadMayor2() {
            return edadMayor2;
            }

            public JLabel getEdadMenor2() {
            return edadMenor2;
            }
    //-----------------------------------------------------------
    public panelEdad() {
                this.setBackground(Color.LIGHT_GRAY);
                this.setLayout(null);
                edadMayor1.setFont(new Font ("Consolas", Font.BOLD, 20));
                edadMayor2.setFont(new Font ("Consolas", Font.BOLD, 20));
                edadMenor1.setFont(new Font ("Consolas", Font.BOLD, 20));
                edadMenor2.setFont(new Font ("Consolas", Font.BOLD, 20));

                edadMayor1.setBounds(10,10,220,20);  
                edadMayor2.setBounds(130,10,220,20); 
                edadMenor1.setBounds(10,50,220,20);  
                edadMenor2.setBounds(130,50,220,20);  
                this.add (edadMayor1);
                this.add (edadMayor2);
                this.add (edadMenor1);
                this.add (edadMenor2);

    }
       
}
