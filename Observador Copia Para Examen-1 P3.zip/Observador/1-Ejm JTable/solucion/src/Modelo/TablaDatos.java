/*
 * Esta capa tiene como funcion obtener la conexion al motor de base de Datos
 * donde obtendremos los datos o bien enviaremos solicitudes de insercion, entre otras.
 * Por el nivel en el que estan del curso se simulara una tabla donde estara los datos de los estudiantes.
 * Mas que todo esta capa es donde donde se da el paso de mensajes entre la aplicacion y la base de datos
 * o si estamos trabajando en un sistema de ficheros (Archivos) sería la comunicacion entre el archivo y la
 * aplicación.
 */
package Modelo;
import Control.Observer;
import Vista.*;
import Control.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;


public class TablaDatos {
   private DefaultTableModel tablaDatos;
   private ArrayList<Observer> listaObservadores;
   private int nuevaEdad;
  //---------------------------------------------------------------
   
  public void attach(Observer ob) {
    this.listaObservadores.add(ob);
  }
    //---------------------------------------------------------------
 public void notificarObservadores() {
 for (int i = 0; i <= listaObservadores.size() - 1; i++) {
            listaObservadores.get(i).notifyChange( );

        } // fin for
  }// fin metodo
//-------------------------------------------------------------------

    public TablaDatos() {
                    tablaDatos = new DefaultTableModel();
                    tablaDatos.addColumn("Nombre");
                    tablaDatos.addColumn("Edad");
                    tablaDatos.addColumn("Sexo");
                    tablaDatos.addColumn("Estado");
                    tablaDatos.addColumn("Grado MAYOR");
                    tablaDatos.addRow(new Object[]{"Rigo","20","M", "Nuevo Ingreso", "Bachillerado" });
                    tablaDatos.addRow(new Object[]{"Maria","24", "F" , "Regular", "Licenciatura" });
                    tablaDatos.addRow(new Object[]{"Raquel","34", "F","Regular", "Bachillerado" });
                    tablaDatos.addRow(new Object[]{"Esperzan","45", "F", "Regular", "Bachillerado" });
                    tablaDatos.addRow(new Object[]{"Luis","35","M", "Pasante", "Maestria" });
                    this.listaObservadores = new ArrayList<Observer>();
       
    }
   //------------------------------------------------------------------- 
    public DefaultTableModel getTablaDatos() {
        return tablaDatos;
    }
    
//-------------------------------------------------------------------

   public void  insertarRegistro (String nom, String edad, String sexo, String esta, String grado)   {
        nuevaEdad= Integer.parseInt(edad) ;
        tablaDatos.addRow(new Object[]{ nom, edad, sexo, esta,grado});
         this.notificarObservadores();
   }
  //-----------------------------------------------------------------------------------   
   public void borrarRegistro (int linea)  {
       tablaDatos.removeRow(linea);
         this.notificarObservadores();
   }
   
  //-----------------------------------------------------------------------------------   
   
    public int getNuevaEdad() {
        return nuevaEdad;
    }
    //-----------------------------------------------------------------------------------

}// fin clase














