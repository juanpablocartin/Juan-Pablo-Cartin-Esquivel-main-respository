# Análisador Semantico

**Integrantes:**

- Juan Pablo Cartín Esquivel
- Anner Andrés Angulo Gutiérrez
- Marcos Emilio Vásquez Díaz

## Descripción

Este proyecto tiene como objetivo desarrollar un script en Python que analiza un segmento de código en busca de errores comunes y los reporta junto con la línea en la que se produjeron. El script utiliza un diccionario para mapear los tipos de errores a sus descripciones correspondientes, usando pricipalmente diccionarios.

## Funcionalidades

El script realiza las siguientes funciones:

1. **Detección de Errores**: Analiza el segmento de código en busca de errores comunes, como asignaciones de valor inválidas, comparaciones incorrectas de tipos de variables y variables no declaradas.

2. **Reporte de Errores**: Genera un informe detallado que indica el tipo de error encontrado y la línea en la que ocurrió.

3. **Adaptación con respecto al código**: El código tiene la capacidad de reportar los errores presentes no solo en el archivo .txt proporcionado, sino en cualquier archivo .txt que contenga la estructura de este lenguaje de programación ficticio.

## Uso

Para utilizar el script, sigue estos pasos:

1. Abre una terminal y navega hasta el directorio donde se encuentra el archivo Python.
2. Ejecuta el script Python en cualquier IDE o en la terminal de Visual Studio Code de la siguiente manera:
   python .\project.py
