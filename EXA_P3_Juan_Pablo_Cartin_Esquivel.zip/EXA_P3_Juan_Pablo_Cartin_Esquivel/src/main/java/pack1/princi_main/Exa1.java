/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package pack1.princi_main;

/**
 *
 * @author jpcar
 */
public class Exa1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
