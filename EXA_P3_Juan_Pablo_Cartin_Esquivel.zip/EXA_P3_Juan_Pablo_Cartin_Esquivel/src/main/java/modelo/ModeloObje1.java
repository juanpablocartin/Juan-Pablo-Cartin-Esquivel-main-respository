/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import javax.swing.table.DefaultTableModel;
/**
 *
 * @author jpcar
 */
public class ModeloObje1 {
     private  DefaultTableModel modelito;
    private listaDobje lis; 

    public DefaultTableModel getMODELITO() {
        return modelito;
    }  
        public ModeloObje1() {
               this.modelito= new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
               return false;
            }
            
        };
               this.lis= new listaDobje();  
               this.OrgaAtri();
               this.MeteFilaDobjDlista(); 
        }
        public void  OrgaAtri() {
        // Se define las columnas
        modelito.addColumn("No.Serie");
        modelito.addColumn("Descripcion");
        modelito.addColumn("Min");
        modelito.addColumn("Max");
        modelito.addColumn("Tolerancia");
  }
     public void  add( Instrumento c){
          lis.add(c);
         this.addFilaAmodelo(  lis.retornaFila(lis.getcan()-1) );
   }
      public void  addFilaAmodelo ( Object [ ] filaAux){
             modelito.addRow( filaAux);
   }
   public void borrarTODOLADO (int linea) {
         modelito.removeRow(linea);
         lis.borrarObje(linea);
   }

      public  void MeteFilaDobjDlista(){
            for (int i = 0; i < lis.getcan(); i++)      {
                Object [ ] filAux=  lis.retornaFila (i);
                modelito.addRow(filAux);
            }
              
       }
 
    public listaDobje getLista() {
        return lis;
    }


    public int getIndexDEidenet(String s){
        int R=-1;
        for (int i = 0; i < lis.getcan(); i++)      {
               if(lis.getObje(i).getDescripcion().equals(s)){ 
                   R=i;
               }
        }
        return R;
    }
    public  Instrumento getObjeConIdent(String s){
        for (int i = 0; i < lis.getcan(); i++)      {
                if(lis.getObje (i).getSerie().equals(s)){  
                    return lis.getObje (i);
               }
        }
        return null;
    }
    public void selectATindex(int i){
        //No puedo seleccionar algo desde cogio asi
    }
    public String infoDobjeto(int i){
        String s;
        s="Serie: "+lis.getObje(i).getSerie()+"\n Descripcion: "+lis.getObje(i).getDescripcion();
        return s;
    }
    public void update(int index,String serie, String descrip,int min, int max , int tole,TipoInstrumento tipoDinstru){
        lis.getObje(index).setSerie(serie);
        lis.getObje(index).setDescripcion(descrip);
        lis.getObje(index).setMin(min);
        lis.getObje(index).setMax(max);
        lis.getObje(index).setTolerancia(tole);
        lis.getObje(index).setTipDinstrumentos(tipoDinstru);
        modelito.removeRow(index);
        addFilaAmodelo(  lis. retornaFila (lis.getINDEX(lis.getObje(index))) );
    }
    public String getAtributo_x_DEidentX(String s){
        for (int i = 0; i < lis.getcan(); i++)      {
                if(lis.getObje (i).getDescripcion().equals(s)){  
                    return lis.getObje (i).getSerie();
               }
        }
        return "";
    }
    public boolean ExisteObjeCON_x_Ident(String s){
        for (int i = 0; i < lis.getcan(); i++) {
            if (lis.getObje(i).getSerie().equals(s)) {
                return true;
            }
        }
         return false;
    }
}
